<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=0,maximum-scale=10,user-scalable=yes">
<meta name="HandheldFriendly" content="true">
<meta name="format-detection" content="telephone=no">
<meta http-equiv="imagetoolbar" content="no">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<link rel="canonical" href="http://miwonsc.com/">
<link rel="shortcut icon" href="/img/miwon.ico">
<meta name="author" content="Miwon Specialty Chemical Co., Ltd.">
<meta name="subject" content="Miwon Specialty Chemical Co., Ltd.">
<meta name="title" content="engMiwon Specialty Chemical Co., Ltd.">
<meta name="Keywords" content="Miwon, MSC, Miwon Specialty Chemical, Miwon North America, Miwon Europe, Miwon USA, Miwon Nantong, Miwon Guangzhou, Miwon Spain, Miwon Austria, MNA, MEU, MUS, MSP, MSI, MNT, MGU, MAU, miramer, photocryl, tmpta, hdda, tpgda, dpgda, monomer, oligomer, energy curing">
<meta name="description" content="Miwon Specialty Chemical Co., Ltd. is a global leading chemical company in Energy Curing industry, mainly producing monomers and oligomers.">
<meta name="copyright" content="Miwon Specialty Chemical Co., Ltd.">
<meta name="robots" content="Miwon Specialty Chemical Co., Ltd." />
<meta name="naver-site-verification" content="73a82b379de82e02877878959ddf039c01e388c0" />
<meta property="og:type" content="website">
<meta property="og:url" content="http://miwonsc.com/" />
<meta property="og:title" content="Miwon Specialty Chemical Co., Ltd.">
<meta property="og:description" content="Miwon Specialty Chemical Co., Ltd. is a global leading chemical company in Energy Curing industry, mainly producing monomers and oligomers.">

<title>Miwon Specialty Chemical Co., Ltd.</title>
<link rel="stylesheet" href="https://miwonsc.com/theme/basic/css/default.css?ver=210618&date=20250807202121">
<link rel="stylesheet" href="https://miwonsc.com/theme/basic/css/design.css?date=20250807202121">
<link rel="stylesheet" href="https://miwonsc.com/theme/basic/css/animations.css?ver=210618&date=20250807202121">
<link rel="stylesheet" href="https://miwonsc.com/theme/basic/css/responsive.css?ver=210618&date=20250807202121">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link rel="stylesheet" href="https://miwonsc.com/theme/basic/css/animate.css?date=20250807202121">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />
<!--[if lte IE 8]>
<script src="https://miwonsc.com/js/html5.js"></script>
<![endif]-->
<style>

.fcolbg1 { padding-top:10px; }
.colbg1 { padding-bottom:20px; }
.colbg2 { background:#FCF7F2;padding-bottom:20px;padding-top:1px; }
.bg_sky { background:#F2F6FC; }
</style>
<script>
// 자바스크립트에서 사용하는 전역변수 선언
var g5_url       = "https://miwonsc.com";
var g5_bbs_url   = "https://miwonsc.com/bbs";
var g5_is_member = "";
var g5_is_admin  = "";
var g5_is_mobile = "";
var g5_bo_table  = "";
var g5_sca       = "";
var g5_editor    = "";
var g5_cookie_domain = "";
</script>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/jquery-migrate-1.4.1.min.js"></script>
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-MHG6HZJ9');</script>
<!-- End Google Tag Manager -->
<script src="https://miwonsc.com/js/jquery.menu.js?ver=210618"></script>
<script src="https://miwonsc.com/js/common.js?ver=210618"></script>
<script src="https://miwonsc.com/js/wrest.js?ver=210618"></script>
<script src="https://miwonsc.com/js/placeholders.min.js?ver=210618"></script>
<script src="https://miwonsc.com/js/jquery.bxslider.js?ver=210618"></script>
<script src="https://miwonsc.com/theme/basic/js/jquery.touchSlider.js?ver=210618"></script>
</head>
<body>
<script>
 $(function() {
	$("#search_mmth").on("click", function() {
        if($("#search_stx").val()=="") {

         alert("A search term is required.");
        } else {
         location.href='/bbs/search.php?lng=eng&stx='+$("#search_stx").val();
        }
		return false;
	});
	$("#search_mmth2").on("click", function() {
        if($("#search_stx2").val()=="") {
         alert("A search term is required.");
        } else {
         location.href='/bbs/search.php?lng=eng&stx='+$("#search_stx2").val();
        }
		return false;
	});
	$("#search_mmth3").on("click", function() {
        if($("#search_stx3").val()=="") {
         alert("A search term is required.");
        } else {
         location.href='/bbs/search.php?lng=eng&stx='+$("#search_stx3").val();
        }
		return false;
	});
	$("#search_mmth4").on("click", function() {
        if($("#search_stx4").val()=="") {
         alert("A search term is required.");
        } else {
         location.href='/bbs/search.php?lng=eng&stx='+$("#search_stx4").val();
        }
		return false;
	});
	$("#search_mmth5").on("click", function() {
        if($("#search_stx5").val()=="") {
         alert("A search term is required.");
        } else {
         location.href='/bbs/search.php?lng=eng&stx='+$("#search_stx5").val();
        }
		return false;
	});
    $('#search_stx').on("keydown", function(e) {
     if (e.keyCode == 13) {
        if($("#search_stx").val()=="") {
         alert("A search term is required.");
        } else {
         location.href='/bbs/search.php?lng=eng&stx='+$("#search_stx").val();
        }
     }
	});

    $('#search_stx2').on("keydown", function(e) {
     if (e.keyCode == 13) {
        if($("#search_stx2").val()=="") {
         alert("A search term is required.");
        } else {
         location.href='/bbs/search.php?lng=eng&stx='+$("#search_stx2").val();
        }
     }
	});

    $('#search_stx3').on("keydown", function(e) {
     if (e.keyCode == 13) {
        if($("#search_stx3").val()=="") {
         alert("A search term is required.");
        } else {
         location.href='/bbs/search.php?lng=eng&stx='+$("#search_stx3").val();
        }
     }
	});

    $('#search_stx4').on("keydown", function(e) {
     if (e.keyCode == 13) {
        if($("#search_stx4").val()=="") {
         alert("A search term is required.");
        } else {
         location.href='/bbs/search.php?lng=eng&stx='+$("#search_stx4").val();
        }
     }
	});


    $('#search_stx5').on("keydown", function(e) {
     if (e.keyCode == 13) {
        if($("#search_stx5").val()=="") {
         alert("A search term is required.");
        } else {
         location.href='/bbs/search.php?lng=eng&stx='+$("#search_stx5").val();
        }
     }
	});
});

</script>
<style>
.fulleshow { display:none;width:100%;max-width:1200px;top:100px;left:calc(50% - 590px);background:#fff;border:5px solid #f7f7f7;position:fixed;z-index:100000000000000 }
.fulleshow > .main { display:table;width:100%;max-width:1080px;margin:50px auto; }
.fulleshow > .main > .sli{ display:table;width:20%;vertical-align: middle;text-align:center;float:left; }
.fulleshow > .main > .sli > a { height:55px;display:table;text-align:center;font-size:1.2em;font-weight:600;width:calc(100% - 5px);color:#ffff;background:navy;padding-top:15px }
.fulleshow > .main > .sli > .head { width:100%;display:table; }
.fulleshow > .main > .sli > .head > li{ width:100%;font-size:1em;font-weight:normal;display:table;height:40px;text-align:left;padding:10px 0px 0px 5px }
.fulleshow > .main > .sli > .head > li > a:hover{ color:#2ab0b1 }


.search-box{
  transition: 0.4s;
  padding: 0px;
  width: 225px;
  height: 30px;
  margin-top:-5px;
  border: 1px solid rgba(255, 255, 255, 0);
}
.search-box:hover{
  border: 1px solid #dedede;
  height: 30px;
  border-radius: 30px;
  box-shadow: 0px 0px .5px 1px #dedede;
  width: 242px;
  margin-top:-5px;
}
.search-txt{
  display: none;
  padding: 0;
  width: 0px;
  height:0px
  border:0px;
  background: none;
  float: left;
  font-size: 1rem;
  line-height: 30px;
  transition: .4s;
  margin-left:20px;
}
.search-btn{
  text-decoration: none;
  float: right;
  width: 20px;
  height: 20px;
  border-radius: 50%;
  display: flex;
  justify-content: center;
  align-items: center;
  margin-right:5px;
  margin-top:2px;
}
.search-box:hover > .search-txt{
  display: flex;
  width: 175px;
  height: 30px;
  padding: 0 6px 3px;
  border:0px;
}


.search-txt2{
  display: none;
  padding: 0;
  width: 0px;
  height:0 px
  border:none;
  background: none;
  outline: none;
  float: left;
  font-size: 1rem;
  line-height: 30px;
  transition: .4s;
}
.search-box2:hover > .search-txt2{
  display: flex;
  width: 240px;
  height: 30px;
  padding: 0 6px;
}
.search-box3{
  transition: 0.4s;
  padding: 0px;
  width: 230px;
  height: 30px;
  margin-top:-5px;
  border: 1px solid rgba(255, 255, 255, 0);
}
.search-box3:hover{
  border: 1px solid #dedede;
  height: 30px;
  border-radius: 30px;
  box-shadow: 0px 0px .5px 1px #dedede;
  width: 242px;
  margin-top:-5px;
}
.search-txt3{
  display: none;
  padding: 0;
  width: 0px;
  height:0px
  border:0px;
  background: none;
  float: left;
  font-size: 1rem;
  line-height: 30px;
  transition: .4s;
  margin-left:20px;
}
.search-btn3{
  text-decoration: none;
  float: right;
  width: 20px;
  height: 20px;
  border-radius: 50%;
  display: flex;
  justify-content: center;
  align-items: center;
  margin-right:5px;
  margin-top:2px;
}
.search-box3:hover > .search-txt3{
  display: flex;
  width: 175px;
  height: 30px;
  padding: 0 6px 3px;
  border:0px;
}
.search-box5{
  transition: 0.4s;
  padding: 0px;
  width: 230px;
  height: 30px;
  margin-top:-5px;
  border: 1px solid rgba(255, 255, 255, 0);
}
.search-box5:hover{
  border: 1px solid #dedede;
  height: 30px;
  border-radius: 30px;
  box-shadow: 0px 0px .5px 1px #dedede;
  width: 242px;
  margin-top:-5px;
}
.search-txt5{
  display: none;
  padding: 0;
  width: 0px;
  height:0px
  border:0px;
  background: none;
  float: left;
  font-size: 1rem;
  line-height: 30px;
  transition: .4s;
  margin-left:20px;
}
.search-btn5{
  text-decoration: none;
  float: right;
  width: 20px;
  height: 20px;
  border-radius: 50%;
  display: flex;
  justify-content: center;
  align-items: center;
  margin-right:5px;
  margin-top:2px;
}
.search-box5:hover > .search-txt5{
  display: flex;
  width: 175px;
  height: 30px;
  padding: 0 6px 3px;
  border:0px;
}
#header #top_tnb {
    border-bottom: 0px;
}
#top_tnb { width:100%;height:30px;position:absolute;z-index:1000000 }
#top_tnb > ul { max-width:1200px;margin:0 auto;height:30px }
#top_tnb > ul > li { float:right;margin:5px; }

.dropdown {
  position: relative;
  display: inline-block;
}
.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 100px;
  color:#000;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}
.wait_content { width:100%;margin-top:100px;margin-bottom:200px;text-align:center;font-size:2em}
.wait_content .material-icons { font-size:3em }
.dropdown-content a {
  color: black;
  padding: 5px 5px;
  text-decoration: none;
  display: block;

}
.dropdown-content a:hover {background-color: #ddd;color:#000;}
.dropdown:hover .dropdown-content {display: block;}
.bload { color:#000 } 
#top_tnb > ul > li { margin-right:10px;}

@media (max-width:1080px) {
#header .subs_tab { display:none }
#header #top_tnb { display:none }
#footer { display:none }
.tl_latest_box_warp { display:none }
}

#top_tnb .material-icons { margin-top:4px;font-size:1rem }
.dropbtn .go_title { margin-left:5px;float:right }
.a4 .go_title { margin-left:5px;margin-top:1px;float:right }
    .small_title {
      border-bottom:2px solid #113387;
	  margin:0 auto;
	  width:150px;
	  font-weight:bold;
	}
    #event_ban  {
      width:100%;;
    }
    #event_ban .event_hip_pop {
      max-width:1180px;margin:0 auto;
    }
	#event_ban.event_ban_show{
	  transition: 0.4s;
	  width:100%;height:70px;
	}
	.event_ban_hide{
	  background:blue;width:100%;height:0px;
	}
    #event_close {
      background:blue;
    }
@media (max-width:1380px) {
    #event_ban {
      display:none;
    }
}

.onmobile_menu1 { width:250px;color:#000;float:left;padding-top:15px }
.onmobile_menu2 { width:calc(100% - 500px);float:left;padding-top:10px;text-align:center }
.onmobile_menu3 { width:250px;color:#000;float:left;padding-top:18px }
.onmobile_menu4 { display:none; }

@media (max-width:960px) {
 #event_ban  {
   display:none;
 }
.fulleshow { display:none;width:calc(100% - 40px);top:100px;left:20px;position:fixed;z-index:100000000000000 }
.fulleshow > .main > .sli{ display:table;width:50%;vertical-align: middle;text-align:center;float:left;padding:5px; }
.fulleshow > .main > .sli > a { height:55px;display:table;text-align:center;font-size:1.2em;font-weight:600;width:100%;color:#ffff;background:navy;padding-top:15px;margin-bottom:10px; }


}


@media (max-width:760px) {

.fulleshow { display:none;width:calc(100% - 40px);top:100px;left:20px;position:fixed;z-index:100000000000000 }
.fulleshow > .main > .sli{ display:table;width:100%;vertical-align: middle;text-align:center;float:normal; }
.fulleshow > .main > .sli > a { height:55px;display:table;text-align:center;font-size:1.2em;font-weight:600;width:100%;color:#ffff;background:navy;padding-top:15px;margin-bottom:10px; }
.fulleshow > .main > .sli > .head { display:none; }
.onmobile_menu3 { display:none; }

.onmobile_menu1 { width:100px;color:#000;float:left;padding-top:15px;cursor:normal }
.onmobile_menu2 { width:calc(100% - 200px);float:left;padding-top:10px;text-align:center }
.onmobile_menu4 { display:block;width:100px;color:#000;float:right;padding-top:15px;text-align:right }


.search-box{
  transition: 0.4s;
  padding: 0px;
  width: 185px;
  height: 30px;
  margin-top:-5px;
  border: 1px solid rgba(255, 255, 255, 0);
}
.search-box:hover{
  border: 1px solid #dedede;
  height: 30px;
  border-radius: 30px;
  box-shadow: 0px 0px .5px 1px #dedede;
  width: 202px;
  margin-top:-5px;
}
.search-txt{
  display: none;
  padding: 0;
  width: 0px;
  height:0px
  border:0px;
  background: none;
  float: left;
  font-size: 1rem;
  line-height: 30px;
  transition: .4s;
  margin-left:20px;
}
.search-btn{
  text-decoration: none;
  float: right;
  width: 20px;
  height: 20px;
  border-radius: 50%;
  display: flex;
  justify-content: center;
  align-items: center;
  margin-right:5px;
  margin-top:2px;
}
.search-box:hover > .search-txt{
  display: flex;
  width: 135px;
  height: 30px;
  padding: 0 6px 3px;
  border:0px;
}

.search-box3{
  transition: 0.4s;
  padding: 0px;
  width: 230px;
  height: 30px;
  margin-top:-5px;
  border: 1px solid rgba(255, 255, 255, 0);
}
.search-box3:hover{
  border: 1px solid #dedede;
  height: 30px;
  border-radius: 30px;
  box-shadow: 0px 0px .5px 1px #dedede;
  width: 242px;
  margin-top:-5px;
}
.search-txt3{
  display: none;
  padding: 0;
  width: 0px;
  height:0px
  border:0px;
  background: none;
  float: left;
  font-size: 1rem;
  line-height: 30px;
  transition: .4s;
  margin-left:20px;
}
.search-btn3{
  text-decoration: none;
  float: right;
  width: 20px;
  height: 20px;
  border-radius: 50%;
  display: flex;
  justify-content: center;
  align-items: center;
  margin-right:5px;
  margin-top:2px;
}
.search-box3:hover > .search-txt3{
  display: flex;
  width: 105px;
  height: 30px;
  padding: 0 6px 3px;
  border:0px;
}


.search-box5{
  transition: 0.4s;
  padding: 0px;
  width: 230px;
  height: 30px;
  margin-top:-5px;
  border: 1px solid rgba(255, 255, 255, 0);
}
.search-box5:hover{
  border: 1px solid #dedede;
  height: 30px;
  border-radius: 30px;
  box-shadow: 0px 0px .5px 1px #dedede;
  width: 242px;
  margin-top:-5px;
}
.search-txt5{
  display: none;
  padding: 0;
  width: 0px;
  height:0px
  border:0px;
  background: none;
  float: left;
  font-size: 1rem;
  line-height: 30px;
  transition: .4s;
  margin-left:20px;
}
.search-btn5{
  text-decoration: none;
  float: right;
  width: 20px;
  height: 20px;
  border-radius: 50%;
  display: flex;
  justify-content: center;
  align-items: center;
  margin-right:5px;
  margin-top:2px;
}
.search-box5:hover > .search-txt5{
  display: flex;
  width: 105px;
  height: 30px;
  padding: 0 6px 3px;
  border:0px;
}

}

</style>
<!-- 상단 시작 { -->
<header id="header">
    <div id="top_tnb">
        <ul>

            <li class='a4' style='margin-top:7px;'><a href="/eng/Bookmark.php"><span class="material-icons">star_border</span> <div class="go_title">Bookmark (0)</div></a></li>
            <li class='a' style='margin-top:7px;'><a>|</a></li>
            <li class='a3' style='margin-top:7px;'>
			    <div class="dropdown">
				  <a class="dropbtn"><span class="material-icons">language</span> <div class="go_title">ENG</div></a>
				  <div class="dropdown-content">
					<a href="/kor" style="color:#000">KOR</a>
					<a href="/chn" style="color:#000">CHN</a>
				  </div>
				</div>
			</li>
            <li class='a' style='margin-top:7px;'><a>|</a></li>
            <li class='a2' style='margin-top:7px;'><a href="/eng/Company/company.html">ABOUT US</a></li>
            <li class='a' style='margin-top:7px;'><a>|</a></li>
		    <li class="a1 search-box">
			  <input type="text" class="search-txt" name="search_stx" id="search_stx" placeholder="Search for a keyword">
			  <a id="search_mmth" class="search-btn" href="#">
				<span class="material-icons">search</span>
			  </a>
			</li>


        </ul>
     </div>
     <div class="ho_line"></div>
	 <div class="wrap gnb_down">
				<h1><a href="/eng" title="메인으로">Miwon Specialty Chemical Co, Ltd.</a></h1>
                <style>
		#header .gnb .depth1 { float:left; padding:0px; position:relative;  }
        		#header .gnb .depth1 a{ padding-left:23px;padding-right:23px; }
		#header .gnb .depth1:last-child a{ padding-left:23px;padding-right:8px; }
                .ho_line { position: absolute;top:100px;display:none;clear:both;width:100%;height:1px;background:silver; }
        @media (max-width:760px) {
        .ho_line { height:0px; }
        #myTopnav #first_nav { display:none; }
        #myTopnav .dropdown_share { display:none; }
        #myTopnav ul li { width:100%;height:30px;text-align:right }
		#header .gnb { max-height:860px;position: fixed;overflow-y:auto; }
        }

        .ulo { animation: fadein 1s !important; }
		@keyframes fadein {
			from {
				opacity: 0;
			}
			to {
				opacity: 1;
			}
		}
		@-moz-keyframes fadein { /* Firefox */
			from {
				opacity: 0;
			}
			to {
				opacity: 1;
			}
		}
		@-webkit-keyframes fadein { /* Safari and Chrome */
			from {
				opacity: 0;
			}
			to {
				opacity: 1;
			}
		}
		@-o-keyframes fadein { /* Opera */
			from {
				opacity: 0;
			}
			to {
				opacity: 1;
			}
		}
        </style>
				<div id="" class="header_view mobile_only">
		  <div class="wrap" style="width:100%;max-width:1200px;margin:0 auto;">
			<div class='onmobile_menu1' id="onfull" onclick="javascript:load_mobile();"><span class="material-icons btn_gnbs">menu</span></div>
			<div class='onmobile_menu2'><A href='/eng'><img src="/img/mi_1.png?"></a></div>
			<div class='onmobile_menu3'><div class='search-box5' style="float:right"><input type="text" class="search-txt5" name="search_stx" id="search_stx5" placeholder="search for keyword"><a id="search_mmth5" class="search-btn5" href="#"><span class="material-icons" style="margin-top:2px;color:#000">search</span></a></div></div>
            <div class='onmobile_menu4'><span class="material-icons btn_gnbs" style="margin-top:2px">search</span></div>
		  </div>
		</div>



   	    <nav class="gnb">
			<ul>
                <li class="gnb_al_a_mobile" style="background:#f7f7f7;height:80px"><div><input type="text" name="search_stx" id="search_stx4" placeholder="Search for a keyword" style='border:1px solid silver;width:calc(100% - 60px);margin-right:10px;float:left'><a id="search_mmth4" style="border-radius: 30px;text-align:center;width:38px;height:30px;padding-top:5px;display:table;float:left;background:gray;color:#fff" href="#"><span class="material-icons" style="margin-top:2px;color:#000">search</span></a></div></li>
   
                <li class="depth1  case" id="tab1">
					<a href="/eng/Market/electronics.html" target="_self" class="gnb_al_a">Market & Application</a>             
					<div class='gnb_al_a_mobile' >Market & Application                                         <span class="material-symbols-outlined hipdown" style="float:right">expand_more</span>
                     <span class="material-symbols-outlined hipup" style="float:right">expand_less</span>
                                         <div class="ulo_hide">
			  <ol>
			   <dd class='head'><A style='color:#000' href='/eng/Market/electronics.html'>Electronics
</a></dd>
			   <!--A href='/eng/Market/electronics.html?#1'><dd>Display</dd></a>
			   <A href='/eng/Market/electronics.html?#2'><dd>PCB</dd></a-->
			  </ol>
			  <ol>
			   <dd class='head'><A style='color:#000' href='/eng/Market/graphic_arts.html'>Graphic arts
</a></dd>
			   <!--A href='/eng/Market/graphic_arts.html?#1'><dd>Flexible Packaging</dd></a>
			   <A href='/eng/Market/graphic_arts.html?#2'><dd>Inks</dd></a>
			   <A href='/eng/Market/graphic_arts.html?#3'><dd>OPV</dd></a-->
			  </ol>
			  <ol>
			   <dd class='head'><A style='color:#000' href='/eng/Market/Industrial_coating.html'>Industrial coating
</a></dd>
			   <!--a href='/eng/Market/Industrial_coating.html?#1'><dd>Automotive</dd></a>
			   <a href='/eng/Market/Industrial_coating.html?#2'><dd>Consumer Electronics</dd></a>
			   <a href='/eng/Market/Industrial_coating.html?#3'><dd>Flooring & Furniture</dd></a>
			   <a href='/eng/Market/Industrial_coating.html?#4'><dd>Industrial Metal</dd></a>
			   <a href='/eng/Market/Industrial_coating.html?#5'><dd>Mobile & Cosmetic Case</dd></a-->
			  </ol>
			  <ol>
			   <dd class='head'><A style='color:#000' href='/eng/Market/specialty.html'>Specialty
</a></dd>
			   <!--A href='/eng/Market/specialty.html?#1'><dd>3D Printing Resins</dd></a>
			   <A href='/eng/Market/specialty.html?#2'><dd>Adhesive</dd></a>
			   <A href='/eng/Market/specialty.html?#3'><dd>Cross-linking</dd></a>
			   <A href='/eng/Market/specialty.html?#4'><dd>Polymerization</dd></a-->
			  </ol>
		  

</div>
                    </div>             
                    
                                    </li>
                                <li class="depth1  case" id="tab2">
					<a href="/eng/Products/search.php" target="_self" class="gnb_al_a">Products</a>             
					<div class='gnb_al_a_mobile' >Products                                         <span class="material-symbols-outlined hipdown" style="float:right">expand_more</span>
                     <span class="material-symbols-outlined hipup" style="float:right">expand_less</span>
                                         <div class="ulo_hide">
		  <ol>
		   <dd class='head'><A style='color:#000' href='/eng/Products/search.php'>Product Finder</a></dd>
		   <!--A href='/eng/Products/search.php'><dd>By classification
</dd></a-->

		   <dd class='head'><A style='color:#000' href='/eng/Products/Monomer_1.html'>Monomer
</a></dd>
		   <!--A href='/eng/Products/Monomer_1.html'><dd>Acrylates</dd></a>
		   <A href='/eng/Products/Monomer_2.html'><dd>Methacrylates</dd></a-->
		  </ol>
          <ol>
		   <dd class='head'><A style='color:#000' href='/eng/Products/Oligomer_1.html'>Oligomer
</a></dd>
		   <!--A href='/eng/Products/Oligomer_1.html'><dd>Amine Acrylates</dd></a>
		   <A href='/eng/Products/Oligomer_2.html'><dd>Epoxy Acrylates</dd></a>
		   <A href='/eng/Products/Oligomer_3.html'><dd>Polyester Acrylates</dd></a>
		   <A href='/eng/Products/Oligomer_5.html'><dd>Specialty Acrylates</dd></a>
		   <A href='/eng/Products/Oligomer_4.html'><dd>Urethane Acrylates</dd></a-->
		  </ol>
          <ol>
		   <dd class='head'><A style='color:#000' href='/eng/Products/Others_1.html'>Others
</a></dd>
		   <!--A href='/eng/Products/Others_1.html'><dd>Benzoin</dd></a>
		   <A href='/eng/Products/Others_2.html'><dd>Epoxy Diluents</dd></a-->
		  </ol>
		 
</div>
                    </div>             
                    
                                    </li>
                                <li class="depth1  case" id="tab3">
					<a href="/bbs/board.php?bo_table=eng_news" target="_self" class="gnb_al_a">Info Center</a>             
					<div class='gnb_al_a_mobile' >Info Center                                         <span class="material-symbols-outlined hipdown" style="float:right">expand_more</span>
                     <span class="material-symbols-outlined hipup" style="float:right">expand_less</span>
                                         <div class="ulo_hide">	 
		  <ol>
		   <dd class='head'><A style='color:#000' href='/bbs/board.php?bo_table=eng_news'>Newsroom</a></dd>
		   <!--li><A href='/bbs/board.php?bo_table=eng_news'>News</a></dd>
		   <dd><A href='/bbs/board.php?bo_table=eng_event'>Events</a></li-->
		  </ol>
          <ol>
		   <dd class='head'>
<A style='color:#000' href='/bbs/board.php?bo_table=eng_Brochures&#topnav_go'>Resources</a></dd>
		   <!--li><A href='/bbs/board.php?bo_table=eng_Brochures&#topnav_go'>E-catalog/Certificates</a></dd>
		   <dd><A href='/bbs/board.php?bo_table=eng_Technical&#topnav_go'>Technical Literatures
</a></dd>
		   <dd><A href='/eng/Products/search.php'>Technical Data Sheets</a></dd>
		   <dd><A href='/eng/service/contact.html'>Safety Data Sheets</a></li-->
		  </ol>
          <ol>
		   <dd class='head'>
<A style='color:#000' href='/eng/Company/locations.html?#topnav_go'>Customer Experience</a></dd>
		   <!--li><A href='/eng/Company/locations.html?#topnav_go'>Global Locations
</a></dd>
		   <dd><A href='/eng/service/contact.html'>Contact Us</a></li-->
		  </ol>
		  
</div>
                    </div>             
                    
                                    </li>
                                <li class="depth1  case" id="tab4">
					<a href="/eng/Sustainability/Sustainability.html" target="_self" class="gnb_al_a">Sustainability</a>             
					<div class='gnb_al_a_mobile' >Sustainability                                         <span class="material-symbols-outlined hipdown" style="float:right">expand_more</span>
                     <span class="material-symbols-outlined hipup" style="float:right">expand_less</span>
                                         <div class="ulo_hide">	  	  <ol>
		   <dd class='head'><A style='color:#000' href='/eng/Sustainability/Sustainability.html'>Sustainability
</a></dd>
		  </ol>
          <ol>
		   <dd class='head'><A style='color:#000' href='/eng/Sustainability/environmental_protection.html'>Environmental Protection
</a></dd>
		  </ol>
          <ol>
		   <dd class='head'><A style='color:#000' href='/eng/Sustainability/energy.html'>Energy
</a></dd>
		  </ol>
		  <ol>
		   <dd class='head'><A style='color:#000' href='/eng/Sustainability/health_safety.html'>Safety and Health
</a></dd>
		  </ol>
          <ol>
		   <dd class='head'><A style='color:#000' href='/eng/Sustainability/SocialContribution.html'>CSR</a></dd>
		  </ol>
          <ol>
		   <dd class='head'><A style='color:#000' href='/eng/Sustainability/quality.html'>Quality
</a></dd>
		  </ol>
          <ol>
		   <dd class='head'><A style='color:#000' href='/eng/Sustainability/Compliance.html'>Compliance
</a></dd>
		  </ol>

</div>
                    </div>             
                    
                                    </li>
                                <li class="depth1  case" id="tab5">
					<a href="/eng/service/contact.html" target="_self" class="gnb_al_a">Contact</a>             
					<div class='gnb_al_a_mobile' onclick="location.href='/eng/service/contact.html';">Contact                                         <div class="ulo_hide">
</div>
                    </div>             
                    
                                    </li>
                
				

                    						<li class="depth1 case" style='background:#fffad7'>
							<div class='gnb_al_a_mobile' onclick="location.href='/eng/Company/company.html';">About us          
								  <div class="ulo_hide"></div>
							</div>        
						</li>
						<li class="depth1 case" style='background:#fffad7'>         
							<div class='gnb_al_a_mobile'>Language                                         
							 <span class="material-symbols-outlined hipdown" style="float:right">expand_more</span>
							 <span class="material-symbols-outlined hipup" style="float:right">expand_less</span>
							 <span class="hipdown" style="float:right;margin-right:15px;font-size:0.7em;padding-top:6px">
									ENG							 </span>
							 <div class="ulo_hide">
																  <ol>
								   <dd class='head'><A style='color:#000' href='/kor/'>KOR</a></dd>
								  </ol>
																  <ol>
								   <dd class='head'><A style='color:#000' href='/chn/'>CHN</a></dd>
								  </ol>
																 </div>
							</div>             
						</li>

			</ul>
            <ul class="ulo" style="margin-left:-430px;">
              <li id="ulo" style="color:#000"></li>
            </ul>
		</nav>
	</div>

</header>
 <style>

#header .gnb #tab1.depth1:hover > a:before { width:170px; }
#header .gnb #tab2.depth1:hover > a:before { width:75px; }
#header .gnb #tab3.depth1:hover > a:before { width:90px; }
#header .gnb #tab4.depth1:hover > a:before { width:110px; }
#header .gnb #tab5.depth1:hover > a:before { width:65px; }
#header .gnb #tab6.depth1:hover > a:before { width:90px; }
#header .gnb #tab7.depth1:hover > a:before { width:62px; }


#header .gnb #tab1.caseon > a:before { width:170px; }
#header .gnb #tab2.caseon > a:before { width:75px; }
#header .gnb #tab3.caseon > a:before { width:90px; }
#header .gnb #tab4.caseon > a:before { width:110px; }
#header .gnb #tab5.caseon > a:before { width:65px; }
#header .gnb #tab6.caseon > a:before { width:90px; }
#header .gnb #tab7.caseon > a:before { width:62px; }

.subs_tab .sub_box { display:table;margin:0 auto;width:100%;height:190px;}
.subs_tab .tab1s ul:first-child { margin-left:80px; }
.subs_tab .tab1s ul  { margin-right:30px; }
.subs_tab .tab2s ul:first-child { margin-left:290px; }
.subs_tab .tab2s ul  { margin-right:30px;; }
.subs_tab .tab2s ul:last-child  { margin-right:0px; }
.subs_tab .tab3s .unext { margin-left:100px; }
.subs_tab .tab3s ul  { margin-right:10px; }
.subs_tab .tab4s ul:first-child { margin-left:510px; }
.subs_tab .tab4s ul  { margin-right:20px; }
.subs_tab .sub_box ul {  float:left;  }
.subs_tab .sub_box ul li{ padding: 0px 0px 0px 10px;height:30px; }
.subs_tab .sub_box ul .head{ font-weight:600;font-size:1.2em;margin-bottom:10px;display:table;width:100%;height:45px;padding-top:10px; }
.subs_tab .sub_box ul .head_top{ font-weight:600;text-align:center;margin-bottom:10px;display:table;width:100%;height:45px }
.subs_tab .head_title { float:left;width:310px;display:table;font-weight:600;font-size:2em;border-right:1px solid silver;height:210px; }
.subs_tab .head_title  .big_title_1 { position:relative;top:155px;font-family: 'GmarketSansBold'; }
.subs_tab .head_title  .big_title_2 { position:relative;top:120px;font-family: 'GmarketSansBold'; }
.subs_tab .small_title_noline  { margin-top:10px;margin-bottom:20px;display:table;font-size:1.3em;width:300px;margin-left:92px;font-family: 'GmarketSansBold'; }
.subs_tab .head_content  { float:left;width:calc(100% - 310px);padding-left:50px;}
.subs_tab .sub_menu_4_for ul { margin-right:60px;float:left;  }
.subs_tab .head_content  { float:left;width:calc(100% - 310px);}
.subs_tab a:hover { color:#28AFB0 !important; }
#onfull { cursor:pointer }

#header_view { width:100%;position:fixed; z-index:100; color:#fff; transition:all .3s;height:60px;background:#fff;width:100%;border-bottom:1px solid silver; }
.header_view { position:fixed; left:0px; top:0px; z-index:100; color:#fff; transition:all .3s;height:60px;background:#fff;width:100%;border-bottom:1px solid silver; }

</style>
<div id="header_view">
  <div class="wrap" style="width:100%;max-width:1200px;margin:0 auto;">
			<div class='onmobile_menu1' id="onfull" onclick="javascript:load_mobile();"><span class="material-icons btn_gnbs">menu</span></div>
			<div class='onmobile_menu2'><A href='/eng'><img src="/img/mi_1.png?"></a></div>
			<div class='onmobile_menu3'><div class='search-box3' style="float:right"><input type="text" class="search-txt3" name="search_stx" id="search_stx3" placeholder="Search for a keyword"><a id="search_mmth3" class="search-btn3" href="#"><span class="material-icons" style="margin-top:2px;color:#000">search</span></a></div></div>
            <div class='onmobile_menu4'><span class="material-icons btn_gnbs" style="margin-top:2px">search</span></div>
  </div>
</div>
<div class='fulleshow'>
 <div style="float:right;font-weight:600;padding:10px;cursor:pointer" onclick="javascript:close_mobile()">Close X</div>
 <ul class='main'>
<li class='sli'><A href='/eng/Market/electronics.html'>Market & Application</a>
		<ul class='head'><li><A style='color:#000' href='/eng/Market/electronics.html'>Electronics
</a></li><li><A style='color:#000' href='/eng/Market/graphic_arts.html'>Graphic arts
</a></li><li><A style='color:#000' href='/eng/Market/Industrial_coating.html'>Industrial coating
</a></li><li><A style='color:#000' href='/eng/Market/specialty.html'>Specialty
</a></li></ul>
</li><li class='sli'><A href='/eng/Products/search.php'>Products</a>
		<ul class='head'><li><A style='color:#000' href='/eng/Products/search.php'>Product Finder</a></li><li><A style='color:#000' href='/eng/Products/Monomer_1.html'>Monomer
</a></li><li><A style='color:#000' href='/eng/Products/Oligomer_1.html'>Oligomer
</a></li><li><A style='color:#000' href='/eng/Products/Others_1.html'>Others
</a></li></ul>
</li><li class='sli'><A href='/bbs/board.php?bo_table=eng_news'>Info Center</a>
		<ul class='head'><li><A style='color:#000' href='/bbs/board.php?bo_table=eng_news'>Newsroom</a></li><li>
<A style='color:#000' href='/bbs/board.php?bo_table=eng_Brochures&#topnav_go'>Resources</a></li><li>
<A style='color:#000' href='/eng/Company/locations.html?#topnav_go'>Customer Experience</a></li></ul>
</li><li class='sli'><A href='/eng/Sustainability/Sustainability.html'>Sustainability</a>
		<ul class='head'><li><A style='color:#000' href='/eng/Sustainability/Sustainability.html'>Sustainability
</a></li><li><A style='color:#000' href='/eng/Sustainability/environmental_protection.html'>Environmental Protection
</a></li><li><A style='color:#000' href='/eng/Sustainability/energy.html'>Energy
</a></li><li><A style='color:#000' href='/eng/Sustainability/health_safety.html'>Safety and Health
</a></li><li><A style='color:#000' href='/eng/Sustainability/SocialContribution.html'>CSR</a></li><li><A style='color:#000' href='/eng/Sustainability/quality.html'>Quality
</a></li><li><A style='color:#000' href='/eng/Sustainability/Compliance.html'>Compliance
</a></li></ul>
</li><li class='sli'><A href='/eng/service/contact.html'>Contact</a>
		<ul class='head'><li></li><li></li><li></li><li></li><li></li><li></li></ul>
</li><li class='sli'><A href='/eng/Company/company.html'>ABOUT US</a>
		<ul class='head'><li><A style='color:#000' href='/eng/Company/company.html'>Company profile</a></li><li><A style='color:#000' href='/eng/Company/value.html'>What we believe</a></li><li><A style='color:#000' href='/eng/Company/point.html'>How we do</a></li><li><A style='color:#000' href='/eng/Company/history.html'>History</a></li><li><A style='color:#000' href='/eng/Company/locations.html'>Locations</a></li><li><A style='color:#000' href='/eng/Company/affiliated.html'>Affiliated companies</a></li></ul>
</li> </ul>
</div>
<script>
var isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry/i.test(navigator.userAgent) ? true : false;
function load_ajax(a) {
	$.ajax({
		url:'/include/menu.php',
		type:'post',
		data:{
				"on" : a,
				"lang" : "eng"
			},
			success: function(res) {
                //alert(res);
                loadtab_hide();
                $(".ulo").show();
                $(".ho_line").show();
				$("#"+a).addClass('caseon');
				$("#ulo").html(res);
			},
			error: function(err) {
				//alert("처리실패");
			}
			});

}

function loadtab_hide() {

    $("#tab1").removeClass('caseon');
	$("#tab2").removeClass('caseon');
	$("#tab3").removeClass('caseon');
	$("#tab4").removeClass('caseon');
	$("#tab5").removeClass('caseon');
	$("#tab6").removeClass('caseon');
	$("#tab7").removeClass('caseon');
	$("#tab8").removeClass('caseon');
	
}
function load_height() {
	$("#header.down").show(); 
	var width = $(window).width();
    if( width > 1200 ) {
	$("#header").css("height","100px");
    } else {
	$("#header").css("height","60px");
    }
}
function load_hide() {
	var width = $(window).width();
    if( width > 1200 ) {
	$("#header").css("height","100px");
    } else {
	$("#header").css("height","60px");
    }
	$("#header").removeClass('down');
	$('#header').removeClass('on');
	/*
	$("#bline_silver").hide();
    $("#tab1").hide();
	$("#tab2").hide();
	$("#tab3").hide();
	$("#tab4").hide();
	$("#tab5").hide();
	$("#tab6").hide();
	$("#tab7").hide();
	$("#tab8").hide();
    */
	
}
function load_hide_to() {
	var width = $(window).width();
    if( width > 1200 ) {
	$("#header").css("height","100px");
    } else {
	$("#header").css("height","60px");
    }
	$("#header").removeClass('down');
	/*
	$('#header').removeClass('on');
	$("#bline_silver").hide();
    $("#tab1").hide();
	$("#tab2").hide();
	$("#tab3").hide();
	$("#tab4").hide();
	$("#tab5").hide();
	$("#tab6").hide();
	$("#tab7").hide();
	$("#tab8").hide();
    */
	
}
function load_show(a,b) {
    //$(".ulo").hide();
	$("#header").addClass('down');
	$('#header').addClass('on');
    if(b=='n') {
    loadtab_hide();
    } else {
	$("#header").css("height","340px"); 
	load_ajax(a);
    }
    //$("#bline_silver").fadeIn();
	//$("#ulo").html(a);
}
function load_mobile() {
	var width = $(window).width();
    if( width > 1080 ) {
	$(".fulleshow").show();
    }
}
function close_mobile() {
	$(".fulleshow").hide();
}
$(function(){
        $("#header_view").hide();

	if(!isMobile){
		$("#tab1").on("mouseover", function(){
			load_hide();
			load_show('tab1');
		});
		$("#tab2").on("mouseover", function(){
			load_hide();
			load_show('tab2');
		});
		$("#tab3").on("mouseover", function(){
			load_hide();
			load_show('tab3');
		});
		$("#tab4").on("mouseover", function(){
			load_hide();
			load_show('tab4');
		});
		$("#tab5").on("mouseover", function(){
			$(".ulo").hide();
            loadtab_hide();
            load_hide();
		});
		$("#tab6").on("mouseover", function(){
			$(".ulo").hide();
            load_hide();
		});
		$("#tab7").on("mouseover", function(){
			$(".ulo").hide();
            load_hide();
            load_show('tab7','n');
		});
		$("#header").on("mouseover", function(){
			var width = $(window).width();
			$("#header.down").show(); 
			if( width > 1023 ) {
			$('#header').addClass('on');
			$("#header .user").addClass('on');
			$("#header .gnb_sub").addClass('on');
			} 
		});
		$("#header").on("mouseout", function(){
			$("#header .user").removeClass('on');
		});
		$("#header .btn_user").on("mouseover", function(){
			//alert(2);
			$('#header').addClass('on');
			$("#header .user").addClass('on');
		});
	};
	if(isMobile){
		$("#header .btn_user").on("click", function(){
			$("#header .user").toggleClass('on');
		});
	};
	$("#header .btn_gnb").on("click", function(){
		$("#header .user").removeClass('on');
		$(this).toggleClass('on');
		$("#header .gnb").toggleClass('on');
	});
	$("#header .btn_gnbs").on("click", function(){
		$("#header .user").removeClass('on');
		$(this).toggleClass('on');
		$("#header .gnb").toggleClass('on');
	});
/*
	$(window).scroll(function(){
		var top = $(window).scrollTop();
		var width = $(window).width();
        if( width > 1023 ) {
		if( top > 60 ){
			load_hide();
			$("#header").hide();
			$("#header_view").show();
			$("#header").css("height","60px");
			$('#header').addClass('on');
		}else{
			$("#header").show();
			$("#header_view").hide();
			$("#header").css("height","100px");
			$('#header').removeClass('on');
		}
        }
	});
*/
    $(function(){
      //Keep track of last scroll
      var lastScroll = 0;

      $(window).scroll(function(event){
          var st = $(this).scrollTop();
          var width = $(window).width();

          if( width > 1200 ) {
          //Sets the current scroll position
          

          //Determines up-or-down scrolling
		   $("#topnav").removeClass("sticky60");
		   $("#topnav").removeClass("sticky100");

          if (st > lastScroll){
             //Replace this with your function call for downward-scrolling
			load_hide();
			$("#header").hide();
			$("#header_view").show();
			$("#header").css("height","60px");
			$('#header').addClass('on');
			$("#topnav").addClass("sticky60");
            loadtab_hide();
            $(".ho_line").hide();
            $(".ulo").hide();
          }
          else {
          if(st < 200) {

			$("#header").removeClass('down');
			$("#header").css("height","100px");
			$("#header_view").hide();
			$("#header").show();
			$('#header').removeClass('on');
			$("#topnav").removeClass('sticky60');
			$("#topnav").removeClass('sticky100');
          } else { 
			$("#header").removeClass('down');
            //alert(width);
            if(width > 980) {
			$("#header").css("height","100px");
            $(".fulleshow").hide();
            } else {
 			$("#header").css("height","60px");
            } 
			$("#header_view").hide();
			$("#header").show();
			$('#header').addClass('on');
          }

          }
            if(width > 980) {
			$("#topnav").addClass("sticky100");
            $(".fulleshow").hide();
            } else {
			$("#topnav").addClass("sticky60");
            } 

          if(st < 101) {
           loadtab_hide();
           $(".ho_line").hide();
           $(".ulo").hide();
          }
          }
          //Updates scroll position
          lastScroll = st;
      });
    });
	$(window).scroll();
	$("#contents").on("mouseover", function(){
		var width = $(window).width();
        if( width > 1200 ) {
		load_hide_to();
        loadtab_hide();
        $(".ho_line").hide();
        $(".ulo").hide();
	    //$('#header').removeClass('on');
		//$('#header').addClass('on');
		//$("#header .user").addClass('on');
		//$("#header .gnb_sub").addClass('on');
        }

	});
	$("#sub_visual_big").on("mouseover", function(){
		var width = $(window).width();
        if( width > 1200 ) {
		load_hide();
        loadtab_hide();
        $(".ho_line").hide();
        $(".ulo").hide();
		//$('#header').addClass('on');
		//$("#header .user").addClass('on');
		//$("#header .gnb_sub").addClass('on');
        }
	});

	$("#event_close").on("click", function(){
		$("#event_ban").css("height","0px");
        var ck_name = 'event_ban';
        var exp_time = '24';
        set_cookie(ck_name, 1, exp_time, g5_cookie_domain);
	});

  

});
</script>
<!-- } 상단 끝 -->


<div id='search_head' class="sub10">
</div><A name='topnav_go' style="padding-top:50px;display:block;margin-top:-50px;"></a>
<script>
function myFunction() {
  var x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
}


</script>
<div id="contents" class="topnav">
 
<div>
	
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
<style>
.inbody { width:100%;max-width:1200px; margin:30px auto;}
#search_head { height:130px; background-position:center; background-size:cover; background-color:#000; }

.normal_board { width:100%;min-width:960px;margin-bottom:20px;border-top:2px solid #94b5b2;border-bottom:1px solid #d5d5db }
.normal_board th{ background:#E6F0EF;font-weight:bold;text-align:center;border-top:1px solid #d5d5db;border-right:1px solid #d5d5db;padding:10px; }
.normal_board td{ border-top:1px solid #d5d5db;border-right:1px solid #d5d5db;padding:5px;text-align:center }
.normal_board .non_right{ border-right:0px; }
.normal_board .text_left{ text-align:left; }
.hu1 { margin-top:10px;margin-bottom:10px }
.Region { cursor:pointer } 
.Category { cursor:pointer } 
.Product { cursor:pointer } 
.Product_head { cursor:pointer } 
.Product_middle { cursor:pointer } 
.Functionality { cursor:pointer } 
.viscosity { cursor:pointer } 
.Advantages { cursor:pointer; } 
.Advantages_hide { cursor:pointer;width:24% } 
.Advantages_span { padding:0px 4px 0px 4px;display:block; }
.Kd {float:left }
.small_material { font-size:1.35em;vertical-align:middle }

.top_menu { display:table;border-top:1px solid #b0b0b0;border-right:1px solid #b0b0b0;width:100%;background:#75a2de; }
.dept1 { display:table;width:100%;height:48px;}
.dept1:last-child { border-bottom:0px solid #b0b0b0; }
.dept1 > h2 { border-top:1px solid #b0b0b0;display:table;height:48px;padding:10px;float:left;background:#43536a;color:#fff;width:15%;min-width:100px; }
.dept1 > .dept2 { border-bottom:1px solid #b0b0b0;display:table;padding:10px;height:48px;float:left;background:#fff;color:#000;width:85%;max-height:48px;;overflow:hidden }
.dept1 > .dept2 > li { cursor:pointer;float:left;margin-right:10px;display:table;padding-right:10px;padding-left:10px;}
.dept1 > .dept2 > .dep_li { margin-bottom:15px }

.dept1 > .dept2_div{ border-bottom:1px solid #b0b0b0;padding-left:10px;overflow:hidden;height:48px;line-height: 180%;width: 85%;float:left;background:#fff;color:#000; }
.dept1 > .dept2_div > div { cursor:pointer;float:left;margin:10px 5px 10px 5px;padding-right:15px;padding-left:5px; }
.dept1 > .dept2_div_2{ border-bottom:1px solid #b0b0b0;padding-left:5px;height: auto;line-height: 180%;width: 85%;float:left;background:#fff;color:#000; }
.dept1 > .dept2_div_2 > div { cursor:pointer;float:left;margin:10px 5px 10px 5px;;padding-right:4px;padding-left:4px; }
.dept1 > h2 > .div_plus { float:right;margin-right:3px;cursor:pointer;font-weight:600 }
.dept1 > h2 > .div_minus { float:right;margin-right:5px;cursor:pointer;font-weight:600 }
.dept1 .input_box { height:25px;margin:0px; }

.dept1_1  > h2{ background:#5d89c3 }
.dept1_2  > h2{ background:#75a2de }

	@media all and (max-width:1080px){
		.dept1 > h2 { border-top:1px solid #b0b0b0;display:table;height:48px;padding:10px;float:normal;background:#43536a;color:#fff;width:100%;min-width:100px; }
		.dept1 > .dept2 { border-bottom:1px solid #b0b0b0;display:table;padding:10px;height:48px;float:normal;background:#fff;color:#000;width:100%;max-height:48px;;overflow:hidden }
		.dept1 > .dept2_div{ border-bottom:1px solid #b0b0b0;padding-left:10px;overflow:hidden;height:48px;line-height: 180%;width: 100%;float:normal;background:#fff;color:#000; }
.dept1 > .dept2_div_2{ border-bottom:1px solid #b0b0b0;padding-left:5px;height: auto;line-height: 180%;width: 100%;float:normal;background:#fff;color:#000; }
        .inbody { padding-left:20px; padding-right:20px; }
		.Advantages_hide { cursor:pointer;width:auto; } 

	}

	@media all and (max-width:840px){
		.clear_box	.box { display:none }
	}
#Advantages_full { display:none }
.Label_key_box { display:table;width:100%;background:#f7f7f7;height:36px;border-left:1px solid #b0b0b0;border-right:1px solid #b0b0b0;border-bottom:1px solid #b0b0b0;padding-bottom:5px; }
.Label_key { float:left; }

.close { margin-left:5px;font-size:0.5rem;cursor:pointer }
.keyword_Region { color:#68b84c;padding-left:10px;padding-right:10px;display:block }
.keyword_Category { color:#417de1;padding-left:10px;padding-right:10px;display:block }
.keyword_Product { color:#ff837a;padding-left:10px;padding-right:10px;display:block }
.keyword_Product_head { color:#ff837a;padding-left:10px;padding-right:10px;display:block }
.keyword_Product_middle { color:#ff837a;padding-left:10px;padding-right:10px;display:block }
.keyword_Functionality { color:#936921;padding-left:10px;padding-right:10px;display:block }
.keyword_viscosity { color:#217493;padding-left:10px;padding-right:10px;display:block }
.keyword_Advantages { color:#932164;padding-left:10px;padding-right:10px;display:block }
.keyword_reset { color:#000;padding-left:10px;padding-right:10px;display:block;cursor:pointer }
.keyword_round { 

	margin-right:5px;
	margin-top:5px;
	float:left;
 }

.d_open_down { background:#cdcdc9;color:#000;border-radius: 3px; }
.d_open_down1 { background:#68b84c;color:#fff;border-radius: 3px; }
.d_open_down2 { background:#417de1;color:#fff;border-radius: 3px; }
.d_open_down3 { background:#ff837a;color:#fff;border-radius: 3px; }
.d_open_down3_1 { background:#ff837a;color:#fff;border-radius: 3px; }
.d_open_down4 { background:#936921;color:#fff;border-radius: 3px; }
.d_open_down5 { background:#217493;color:#fff;border-radius: 3px; }
.d_open_down6 { background:#932164;color:#fff;border-radius: 3px; }
.Search_buttons { cursor:pointer;border:1px solid #d2d2d2;background:#f7f7f7;border-radius: 3px;display:inline-block;margin:0 0 0 5px }
.Search_buttons:hover{ cursor:pointer;border:1px solid #335fb0;background:#335fb0;color:#fff;border-radius: 3px;display:inline-block;margin:0 0 0 5px }
.Search_button { cursor:pointer;border:1px solid #d2d2d2;background:#f7f7f7;border-radius: 3px;display:inline-block;margin:0 0 0 5px }
.Search_button .material-icons { font-size:1.3em;margin:2px 5px 0 5px }
.Search_button .f_text{ float:right;margin:0 5px 0 0 }
.f_hide { display:none } 
#bo_cate {
    font-size: 0;
    margin-left: 1px;
    text-align: center;
}
#bo_cate a {
    display: block;
	width:50%;
    line-height: 28px;
    padding: 5px 15px;
    border-radius: 30px;
    border-top: 1px solid #d6e9ff;
    border-left: 1px solid #d6e9ff;
    border-right: 1px solid #d6e9ff;
    color: #6794d3;
	float:left
}
#bo_cate a {
    font-size: .95rem;
    border-radius: 0;
    margin: 0;
    min-width: 150px;
    text-align: center;
    height: 50px;
    line-height: 46px;
    padding: 0 20px;
    color: #aaa;
    border-top: 1px solid #d6e9ff;
    border-left: 1px solid #d6e9ff;
    border-right: 1px solid #d6e9ff;
    border-bottom: 0px;
    font-weight: 400;
}
#bo_cate .bo_cate_on {
    background: #fff;
    color: #222;
    border-color: #222;
    position: relative;
    z-index: 1;
    box-shadow: none;
    font-weight: 500;
}
.box {
  float:left;
  width: 150px;
  height: 22px;
  margin-right:20px;
  cursor:default
}
.clear_box {

  cursor:default !important
}

.slider {
  width: 100%;
  height: 100%;
  top:10px;
  /* 후에 padding: 1.5rem 2rem 으로 수정합니다. 참고바랍니다. */
  padding: 0rem;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: center;
  position: relative;
  cursor:no-drop;

}

.slider input {
  width: 100%;
  top: 0rem;
  left: 0rem;
  position: absolute;
  border: none;
  pointer-events: none;
  z-index: 10;
  appearance: none;
  opacity: 0;
  cursor:col-resize;
}

.slider input::-webkit-slider-thumb {
  pointer-events: all;
  width: 2.5rem;
  height: 1.5rem;
}
.slider input:first-child {
  top: 0rem;
}

.slider .track {
  position: relative;
  width: 100%;
  height: 0.5rem;
  margin-top: 0rem;
  background-color: #bdc3c7;
  border-radius: 0.5rem;
}

.slider .range {
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  background-color: #adeb88;
  border-radius: 0.5rem;
}

.slider .thumb {
  position: absolute;
  top: 0;
  transform: translateY(-0.25rem);
  width: 1rem;
  height: 1rem;
  background-color: #649845;
  border-radius: 50%;
}

.slider .left {
  left: 0;
}

.slider .right {
  right: 0;
}
.no_result {
  height:500px;
  font-size:1.5em;
  font-weight:600
}
.no_result .material-icons{
  font-size:3em
}
.layer_open { cursor:pointer }
#po_result { min-height:350px;margin-bottom:50px }

.go_products { display:table;margin-bottom:40px;width:100%; }
.go_products > h1 { font-size:2.2em;width:100%;margin-bottom:20px }
.go_products_td60 { font-size:1.2em;width:70%;float:left }
.go_products_td40 { font-size:1.2em;width:30%;float:left }
.go_products .button { width:150px;font-size:0.8em;margin-left:20px;padding:10px;background:#43536a;color:#fff;cursor:pointer;border-radius: 9px; }
	@media all and (max-width:840px){
        .go_products_td60 { width:100%; }
        .go_products_td40 { width:100%; }
		.go_products .button { width:150px;font-size:0.8em;margin-left:0px;margin-top:20px;padding:10px;background:#43536a;color:#fff;font-weight:600;cursor:pointer;border-radius: 9px; }
	}
</style>
<div class="small_nav topnavs sticky" id='topnav'>
 <div id="myTopnav">
  <div id="first_nav" class="dropdown_sub">
  Product Finder  </div>
  <div class="dropdown_sub">
	<ul>
	  <a href='search.php'><li class='active'><span>Product Finder</span></li></a>	
	  <a href='Monomer_1.html?#topnav_go'><li><span>MONOMER</span></li></a>	
	  <a href='Oligomer_1.html?#topnav_go'><li><span>OLIGOMER</span></li></a>	
	  <a href='Others_1.html?#topnav_go'><li><span>OTHERS</span></li></a>	
	  <a href='/eng/Bookmark.php?#topnav_go'><li><span>Bookmark</span></li></a>	
	</ul>
  </div>
  <div class="dropdown_share"><span class="material-icons" style='font-size:13pt;margin-top:4px'>share</span></div>
</div>
</div>
<div class='inbody'>
<div class='go_products'>
<h1 class="gbold">Find the Right Products</h1>
<div class='go_products_td60 glight'>Looking for more specific products or want to develop a project? <br>
We have the resources and expertise you need to achieve more.</div>
<div class='go_products_td40'><a href="/eng/service/contact.html" target=_blank class="btn_go"><div class="button glight">Contact our team</div></a></div>
</div>
<div style="margin:0 auto;width:100%;margin-bottom:40px;">
<center>
        <a><a id="Search_btn" style="cursor:pointer;color:gray;position:absolute;margin-left:10px;margin-top:5px;"><span class="material-icons" style='font-size:3em'>search</span> </a><input type=text name="keyword" id="Search_keyword" value="" placeholder="Search for a keyword" style="padding-left:70px;width:100%;max-width:650px;height:50px;margin-right:2px;margin-top:0px;background:#f7f7f7;font-size:1.4em;border-radius: 29px;"></a>
</center>
<input type=hidden id="Opt1" name="Region" value="" class="Search_button">
		 <input type=hidden id="Opt2" name="Category" value="" class="Search_button">
		 <input type=hidden id="Opt3" name="Product" value="" class="Search_button">
		 <input type=hidden id="Opt3_1" name="Product_head" value="" class="Search_button">
		 <input type=hidden id="Opt3_2" name="Product_middle" value="" class="Search_button">
		 <input type=hidden id="Opt4" name="Functionality" value="" class="Search_button">
		 <input type=hidden id="Opt5_1" name="viscosity_25" value="" class="Search_button">
		 <input type=hidden id="Opt5_2" name="viscosity_60" value="" class="Search_button">
		 <input type=hidden id="Opt5_3" name="viscosity_65" value="" class="Search_button">
		 <input type=hidden id="Opt6" name="Advantages" value="" class="Search_button">
   </div>
	<ul class="top_menu">


	<li class='dept1 Sa1'><h2>Region <span style="font-size:0.85em">(available market)</span>  </h2>
		<ul class='dept2'>
			<li class='Region' id='a2'>Australia & New Zealand</li>
    		<li class='Region' id='a3'>China</li>
    		<li class='Region' id='a4'>Europe</li>
    		<li class='Region' id='a5'>Japan</li>
    		<li class='Region' id='a6'>Korea</li>
    		<li class='Region' id='a7'>North America</li>
    		</ul>
	</li>
	<li class='dept1 Sa2'><h2>Category</h2>	
		<ul class='dept2'>
			<li class='Category' id='b22'>Electronics</li>
    		<li class='Category' id='b23'>Graphic arts</li>
    		<li class='Category' id='b24'>Industrial coating</li>
    		<li class='Category' id='b25'>Specialty</li>
    		</ul>
	</li>
	<li class='dept1 Sa3'><h2>Product Group</h2>	
		<ul class='dept2'>
		<li class='Product_head' id='c1'>Monomer</li>
		<li class='Product_head' id='c2'>Oligomer</li>
		</ul>
	</li>
	<li class='dept1 dept1_1 f_hide Sa3_1'><h2><div class="material-icons" style="float:left">chevron_right</div> Monomer</h2>	
		<ul class='dept2'>
			<li class='Product_middle' id='c1_1' data-name="Monomer" data-code="Acrylates">Acrylates</li>
    		<li class='Product_middle' id='c1_2' data-name="Monomer" data-code="Methacrylates">Methacrylates</li>
    		<li class='Product_middle' id='c1_3' data-name="Monomer" data-code=""></li>
    		<li class='Product_middle' id='c1_4' data-name="Monomer" data-code=""></li>
    		<li class='Product_middle' id='c1_5' data-name="Monomer" data-code=""></li>
    		<li class='Product_middle' id='c1_6' data-name="Monomer" data-code=""></li>
    		<li class='Product_middle' id='c1_7' data-name="Monomer" data-code=""></li>
    		<li class='Product_middle' id='c1_8' data-name="Monomer" data-code=""></li>
    		<li class='Product_middle' id='c1_9' data-name="Monomer" data-code=""></li>
    		<li class='Product_middle' id='c1_10' data-name="Monomer" data-code=""></li>
    		</ul>
	</li>
	<li class='dept1 dept1_1 f_hide Sa3_2'><h2><div class="material-icons" style="float:left">chevron_right</div> Oligomer</h2>	
		<ul class='dept2'>
			    <li class='Product_middle' id='c2_1' data-name="Oligomer" data-code="Amineacrylates">Amine acrylates</li>
    		    <li class='Product_middle' id='c2_2' data-name="Oligomer" data-code="Epoxyacrylates">Epoxy acrylates</li>
    		    <li class='Product_middle' id='c2_3' data-name="Oligomer" data-code="Polyesteracrylates">Polyester acrylates</li>
    		    <li class='Product_middle' id='c2_4' data-name="Oligomer" data-code="Specialtyacrylates">Specialty acrylates</li>
    		    <li class='Product_middle' id='c2_5' data-name="Oligomer" data-code="Urethaneacrylates">Urethane acrylates</li>
    		    <li class='Product_middle' id='c2_6' data-name="Oligomer" data-code=""></li>
    		    <li class='Product_middle' id='c2_7' data-name="Oligomer" data-code=""></li>
    		    <li class='Product_middle' id='c2_8' data-name="Oligomer" data-code=""></li>
    		    <li class='Product_middle' id='c2_9' data-name="Oligomer" data-code=""></li>
    		    <li class='Product_middle' id='c2_10' data-name="Oligomer" data-code=""></li>
    		</ul>
	</li>
	<li class='dept1 dept1_2 f_hide Sa3_3 Oligomer' ><h2><div class="material-icons" style="float:left;">chevron_right</div><div class="material-icons" style="float:left;margin-left:-17px;">chevron_right</div> Amine acrylates  </h2>	
			    <ul class='dept2'>
				<li class='Product Amineacrylates Amineacrylates0' id='c2_1_1' data-name="c2_1_1">Acrylated amine synergists</li>
				<li class='Product Amineacrylates Amineacrylates1' id='c2_1_2' data-name="c2_1_2">Amine acrylates</li>
				</ul>
	</li>
	<li class='dept1 dept1_2 f_hide Sa3_4 Oligomer' ><h2><div class="material-icons" style="float:left;">chevron_right</div><div class="material-icons" style="float:left;margin-left:-17px;">chevron_right</div> Epoxy acrylates  </h2>	
			    <ul class='dept2'>
				<li class='Product Epoxyacrylates Epoxyacrylates0' id='c2_2_1' data-name="c2_2_1">Epoxy acrylates</li>
				<li class='Product Epoxyacrylates Epoxyacrylates1' id='c2_2_2' data-name="c2_2_2">Epoxy methacrylates</li>
				<li class='Product Epoxyacrylates Epoxyacrylates2' id='c2_2_3' data-name="c2_2_3">Modified epoxy acrylates</li>
				</ul>
	</li>
    <li class='Sa3_5' style="height:0px;"></li>
	<li class='dept1 dept1_2 f_hide Sa3_6 Oligomer' ><h2><div class="material-icons" style="float:left;">chevron_right</div><div class="material-icons" style="float:left;margin-left:-17px;">chevron_right</div> Specialty acrylates  </h2>	
			    <ul class='dept2'>
				<li class='Product Specialtyacrylates Specialtyacrylates0' id='c2_4_1' data-name="c2_4_1">Acrylic acrylates</li>
				<li class='Product Specialtyacrylates Specialtyacrylates1' id='c2_4_2' data-name="c2_4_2">Butadiene acrylates</li>
				<li class='Product Specialtyacrylates Specialtyacrylates2' id='c2_4_3' data-name="c2_4_3">Dendritic acrylates</li>
				<li class='Product Specialtyacrylates Specialtyacrylates3' id='c2_4_4' data-name="c2_4_4">High refractive index acrylates</li>
				<li class='Product Specialtyacrylates Specialtyacrylates4' id='c2_4_5' data-name="c2_4_5">Melamine acrylates</li>
				<li class='Product Specialtyacrylates Specialtyacrylates5' id='c2_4_6' data-name="c2_4_6">Phosphate methacrylates</li>
				<li class='Product Specialtyacrylates Specialtyacrylates6' id='c2_4_7' data-name="c2_4_7">Polyester resins </li>
				<li class='Product Specialtyacrylates Specialtyacrylates7' id='c2_4_8' data-name="c2_4_8">Silicone acrylates</li>
				<li class='Product Specialtyacrylates Specialtyacrylates8' id='c2_4_9' data-name="c2_4_9">Special polyester acrylates </li>
				<li class='Product Specialtyacrylates Specialtyacrylates9' id='c2_4_10' data-name="c2_4_10">Sucrose Benzoate</li>
				<li class='Product Specialtyacrylates Specialtyacrylates10' id='c2_4_11' data-name="c2_4_11">Water borne acrylates</li>
				<li class='Product Specialtyacrylates Specialtyacrylates11' id='c2_4_12' data-name="c2_4_12">Water soluble acrylates</li>
				</ul>
	</li>
	<li class='dept1 dept1_2 f_hide Sa3_7 Oligomer' ><h2><div class="material-icons" style="float:left;">chevron_right</div><div class="material-icons" style="float:left;margin-left:-17px;">chevron_right</div> Urethane acrylates  </h2>	
			    <ul class='dept2'>
				<li class='Product Urethaneacrylates Urethaneacrylates0' id='c2_5_1' data-name="c2_5_1">Aliphatic urethane acrylates</li>
				<li class='Product Urethaneacrylates Urethaneacrylates1' id='c2_5_2' data-name="c2_5_2">Aromatic urethane acrylates</li>
				<li class='Product Urethaneacrylates Urethaneacrylates2' id='c2_5_3' data-name="c2_5_3">Urethane methacrylates</li>
				</ul>
	</li>

    <li class='dept1 Sa6' id='Advantages_half'><h2>Product Advantages <div class='div_plus Product_Advantages_plus'>+</div></h2>
		<div class='dept2_div'>
			<div class='Advantages' id='f1'>Abrasion resistance</div>
			<div class='Advantages' id='f2'>Adhesion</div>
			<div class='Advantages' id='f3'>Bio-based</div>
			<div class='Advantages' id='f4'>Chemical resistance</div>
			<div class='Advantages' id='f5'>Cutting power</div>
			<div class='Advantages' id='f6'>Dual cure</div>
			<div class='Advantages' id='f7'>Elasticity</div>
			<div class='Advantages' id='f8'>Elongation</div>
			<div class='Advantages' id='f9'>Flexibility</div>
			<div class='Advantages' id='f10'>Hardness</div>
			<div class='Advantages' id='f11'>Heat resistance</div>
			<div class='Advantages' id='f12'>High cross-linking density</div>
			<div class='Advantages' id='f13'>High gloss</div>
			<div class='Advantages' id='f14'>High refractive index</div>
			<div class='Advantages' id='f15'>Hydrophobic characteristic</div>
			<div class='Advantages' id='f16'>Levelling</div>
			<div class='Advantages' id='f17'>Lithographic properties</div>
			<div class='Advantages' id='f18'>Low color index</div>
			<div class='Advantages' id='f19'>Low MeHQ contents</div>
			<div class='Advantages' id='f20'>Low residual acid</div>
			<div class='Advantages' id='f21'>Low residual solvent</div>
			<div class='Advantages' id='f22'>Low shrinkage</div>
			<div class='Advantages' id='f23'>Low surface tension</div>
			<div class='Advantages' id='f24'>Low viscosity</div>
			<div class='Advantages' id='f25'>Low yellowing</div>
			<div class='Advantages' id='f26'>Non-halogen</div>
			<div class='Advantages' id='f27'>Organotin-free</div>
			<div class='Advantages' id='f28'>Pendulum hardness</div>
			<div class='Advantages' id='f29'>Pigment wetting</div>
			<div class='Advantages' id='f30'>Reactivity</div>
			<div class='Advantages' id='f31'>Scratch resistance</div>
			<div class='Advantages' id='f32'>Solvent resistance</div>
			<div class='Advantages' id='f33'>Toughness</div>
			<div class='Advantages' id='f34'>Wetting</div>
			<div class='Advantages' id='f35'>Wood wetting</div>
		</div>
	</li>
    <li class='dept1 f_hide Sa7' id='Advantages_full'><h2>Product Advantages <div class='div_minus Product_Advantages_minus'>-</div></h2>
		<div class='dept2_div_2'>
			<div class='Advantages_hide Advantages_span'><div class='Advantages' id='copy_f1' style="padding:0px 5px 0px 5px ;display:inline-block !important;">Abrasion resistance</div></div>
			<div class='Advantages_hide Advantages_span'><div class='Advantages' id='copy_f2' style="padding:0px 5px 0px 5px ;display:inline-block !important;">Adhesion</div></div>
			<div class='Advantages_hide Advantages_span'><div class='Advantages' id='copy_f3' style="padding:0px 5px 0px 5px ;display:inline-block !important;">Bio-based</div></div>
			<div class='Advantages_hide Advantages_span'><div class='Advantages' id='copy_f4' style="padding:0px 5px 0px 5px ;display:inline-block !important;">Chemical resistance</div></div>
			<div class='Advantages_hide Advantages_span'><div class='Advantages' id='copy_f5' style="padding:0px 5px 0px 5px ;display:inline-block !important;">Cutting power</div></div>
			<div class='Advantages_hide Advantages_span'><div class='Advantages' id='copy_f6' style="padding:0px 5px 0px 5px ;display:inline-block !important;">Dual cure</div></div>
			<div class='Advantages_hide Advantages_span'><div class='Advantages' id='copy_f7' style="padding:0px 5px 0px 5px ;display:inline-block !important;">Elasticity</div></div>
			<div class='Advantages_hide Advantages_span'><div class='Advantages' id='copy_f8' style="padding:0px 5px 0px 5px ;display:inline-block !important;">Elongation</div></div>
			<div class='Advantages_hide Advantages_span'><div class='Advantages' id='copy_f9' style="padding:0px 5px 0px 5px ;display:inline-block !important;">Flexibility</div></div>
			<div class='Advantages_hide Advantages_span'><div class='Advantages' id='copy_f10' style="padding:0px 5px 0px 5px ;display:inline-block !important;">Hardness</div></div>
			<div class='Advantages_hide Advantages_span'><div class='Advantages' id='copy_f11' style="padding:0px 5px 0px 5px ;display:inline-block !important;">Heat resistance</div></div>
			<div class='Advantages_hide Advantages_span'><div class='Advantages' id='copy_f12' style="padding:0px 5px 0px 5px ;display:inline-block !important;">High cross-linking density</div></div>
			<div class='Advantages_hide Advantages_span'><div class='Advantages' id='copy_f13' style="padding:0px 5px 0px 5px ;display:inline-block !important;">High gloss</div></div>
			<div class='Advantages_hide Advantages_span'><div class='Advantages' id='copy_f14' style="padding:0px 5px 0px 5px ;display:inline-block !important;">High refractive index</div></div>
			<div class='Advantages_hide Advantages_span'><div class='Advantages' id='copy_f15' style="padding:0px 5px 0px 5px ;display:inline-block !important;">Hydrophobic characteristic</div></div>
			<div class='Advantages_hide Advantages_span'><div class='Advantages' id='copy_f16' style="padding:0px 5px 0px 5px ;display:inline-block !important;">Levelling</div></div>
			<div class='Advantages_hide Advantages_span'><div class='Advantages' id='copy_f17' style="padding:0px 5px 0px 5px ;display:inline-block !important;">Lithographic properties</div></div>
			<div class='Advantages_hide Advantages_span'><div class='Advantages' id='copy_f18' style="padding:0px 5px 0px 5px ;display:inline-block !important;">Low color index</div></div>
			<div class='Advantages_hide Advantages_span'><div class='Advantages' id='copy_f19' style="padding:0px 5px 0px 5px ;display:inline-block !important;">Low MeHQ contents</div></div>
			<div class='Advantages_hide Advantages_span'><div class='Advantages' id='copy_f20' style="padding:0px 5px 0px 5px ;display:inline-block !important;">Low residual acid</div></div>
			<div class='Advantages_hide Advantages_span'><div class='Advantages' id='copy_f21' style="padding:0px 5px 0px 5px ;display:inline-block !important;">Low residual solvent</div></div>
			<div class='Advantages_hide Advantages_span'><div class='Advantages' id='copy_f22' style="padding:0px 5px 0px 5px ;display:inline-block !important;">Low shrinkage</div></div>
			<div class='Advantages_hide Advantages_span'><div class='Advantages' id='copy_f23' style="padding:0px 5px 0px 5px ;display:inline-block !important;">Low surface tension</div></div>
			<div class='Advantages_hide Advantages_span'><div class='Advantages' id='copy_f24' style="padding:0px 5px 0px 5px ;display:inline-block !important;">Low viscosity</div></div>
			<div class='Advantages_hide Advantages_span'><div class='Advantages' id='copy_f25' style="padding:0px 5px 0px 5px ;display:inline-block !important;">Low yellowing</div></div>
			<div class='Advantages_hide Advantages_span'><div class='Advantages' id='copy_f26' style="padding:0px 5px 0px 5px ;display:inline-block !important;">Non-halogen</div></div>
			<div class='Advantages_hide Advantages_span'><div class='Advantages' id='copy_f27' style="padding:0px 5px 0px 5px ;display:inline-block !important;">Organotin-free</div></div>
			<div class='Advantages_hide Advantages_span'><div class='Advantages' id='copy_f28' style="padding:0px 5px 0px 5px ;display:inline-block !important;">Pendulum hardness</div></div>
			<div class='Advantages_hide Advantages_span'><div class='Advantages' id='copy_f29' style="padding:0px 5px 0px 5px ;display:inline-block !important;">Pigment wetting</div></div>
			<div class='Advantages_hide Advantages_span'><div class='Advantages' id='copy_f30' style="padding:0px 5px 0px 5px ;display:inline-block !important;">Reactivity</div></div>
			<div class='Advantages_hide Advantages_span'><div class='Advantages' id='copy_f31' style="padding:0px 5px 0px 5px ;display:inline-block !important;">Scratch resistance</div></div>
			<div class='Advantages_hide Advantages_span'><div class='Advantages' id='copy_f32' style="padding:0px 5px 0px 5px ;display:inline-block !important;">Solvent resistance</div></div>
			<div class='Advantages_hide Advantages_span'><div class='Advantages' id='copy_f33' style="padding:0px 5px 0px 5px ;display:inline-block !important;">Toughness</div></div>
			<div class='Advantages_hide Advantages_span'><div class='Advantages' id='copy_f34' style="padding:0px 5px 0px 5px ;display:inline-block !important;">Wetting</div></div>
			<div class='Advantages_hide Advantages_span'><div class='Advantages' id='copy_f35' style="padding:0px 5px 0px 5px ;display:inline-block !important;">Wood wetting</div></div>
			
		</div>
	</li>
	<li class='dept1'><h2>Search Option </h2>
		<ul class='dept2'>
         <!--li class='Search_option' id='Sa1'>Region</li>
         <li class='Search_option' id='Sa2'>Category</li>
         <li class='Search_option' id='Sa3'>Product Group</li-->
         <li class='Search_option' id='Sa4'>Functionality</li>
         <li class='Search_option' id='Sa5'>Avg. viscosity</li>
         <!--li class='Search_option' id='Sa6'>Product Advantages</li-->
		</ul>
	</li>
	<li class='dept1 f_hide Sa4'><h2>Functionality</h2>
		<ul class='dept2'>
		<li class='Functionality' id='d1'>Mono</li>
		<li class='Functionality' id='d2'>Di</li>
		<li class='Functionality' id='d3'>Tri</li>
		<li class='Functionality' id='d4'>Multi</li>
		</ul>
	</li>
	<li class='dept1 f_hide Sa5'><h2>Avg. viscosity @25℃</h2>
		<ul class='dept2'>
		<li class='clear_box'>
		   <div class='box'>
			   <div class="slider">
				<input type="range" id="input-left1" min="2" max="110800" value="2" />
				<input type="range" id="input-right1" min="2" max="110800" value="110800" />
				<div class="track">
				  <div class="range range1"></div>
				  <div class="thumb left left1"></div>
				  <div class="thumb right right1"></div>
				</div>
			  </div>
		  </div>
 
        <div style='float:left'><input class='h1s input_box' type=text id="vi11" size=2 value='2' name="viscosity25_1"> ~ <input class='h1s input_box' type=text size=2 id="vi12" value='110800' name="viscosity25_2"></div>  
		<div class="material-icons Search_vi1" style='border:1px solid silver;height:25px;width:35px;text-align:center;background:#f7f7f7;cursor:pointer;border-radius: 3px;margin-left:5px;font-size:1.5em;padding-top:2px;float:left'>search</div>
		</li>
		</ul>
	</li>
	<li class='dept1 f_hide Sa5'><h2>Avg. viscosity @60℃</h2>
		<ul class='dept2'>
		<li class='clear_box'>
		   <div class='box'>
			   <div class="slider">
				<input type="range" id="input-left2" min="500" max="26300" value="500" />
				<input type="range" id="input-right2" min="500" max="26300" value="26300" />
				<div class="track">
				  <div class="range range2"></div>
				  <div class="thumb left left2"></div>
				  <div class="thumb right right2"></div>
				</div>
			  </div>
		  </div>		
 
        <div style='float:left'><input type=text id="vi21" size=2 value='500' class='h1s input_box' name="viscosity60_1"> ~ <input class='h1s input_box' type=text size=2 id="vi22" value='26300' name="viscosity60_2"></div>  
		<div class="material-icons Search_vi2" style='border:1px solid silver;height:25px;width:35px;text-align:center;background:#f7f7f7;cursor:pointer;border-radius: 3px;margin-left:5px;font-size:1.5em;padding-top:2px;float:left'>search</div>

		</ul>
	</li>
	<li class='dept1 f_hide Sa5'><h2>Avg. viscosity @65.5℃</h2>
		<ul class='dept2'>
		<li class='clear_box'>
		   <div class='box'>
			   <div class="slider">
				<input type="range" id="input-left3" min="3000" max="4200" value="3000" />
				<input type="range" id="input-right3" min="3000" max="4200" value="4200" />
				<div class="track">
				  <div class="range range3"></div>
				  <div class="thumb left left3"></div>
				  <div class="thumb right right3"></div>
				</div>
			  </div>
		  </div>	
        <div style='float:left'><input type=text id="vi31" size=2 value='3000' class='h1s input_box' name="viscosity60.5_1"> ~ <input class='h1s input_box' type=text size=2 id="vi32" value='4200' name="viscosity60.5_2"></div>  
		<div class="material-icons Search_vi3" style='border:1px solid silver;height:25px;width:35px;text-align:center;background:#f7f7f7;cursor:pointer;border-radius: 3px;margin-left:5px;font-size:1.5em;padding-top:2px;float:left'>search</div>

		</li>
		</ul>
	</li>
	</ul>
 <input type=hidden name="Sa3_1" id="Sa3_1" data-name="2" data-code="c1_1||c1_2||" value="Acrylates||Methacrylates||">
 <input type=hidden name="Sa3_2" id="Sa3_2" data-name="5" data-code="c2_1||c2_2||c2_3||c2_4||c2_5||" value="Amine acrylates||Epoxy acrylates||Polyester acrylates||Specialty acrylates||Urethane acrylates||">
 <input type=hidden name="Sa3_3" id="Sa3_3" data-name="4" data-code="Sa3_3||Sa3_4||Sa3_6||Sa3_7||" value="Sa3_3||Sa3_4||Sa3_6||Sa3_7||">
 <input type=hidden name="Sa3_4" id="Sa3_4" data-name="20" data-code="c2_1_1||c2_1_2||c2_2_1||c2_2_2||c2_2_3||c2_4_1||c2_4_2||c2_4_3||c2_4_4||c2_4_5||c2_4_6||c2_4_7||c2_4_8||c2_4_9||c2_4_10||c2_4_11||c2_4_12||c2_5_1||c2_5_2||c2_5_3||" value="Acrylated amine synergists||Amine acrylates||Epoxy acrylates||Epoxy methacrylates||Modified epoxy acrylates||Acrylic acrylates||Butadiene acrylates||Dendritic acrylates||High refractive index acrylates||Melamine acrylates||Phosphate methacrylates||Polyester resins ||Silicone acrylates||Special polyester acrylates ||Sucrose Benzoate||Water borne acrylates||Water soluble acrylates||Aliphatic urethane acrylates||Aromatic urethane acrylates||Urethane methacrylates||>">
 <div class='Label_key_box'>
 <div class='keyword_round keyword_reset'><!--Advantages Keyword : --><b>Clear Filters</b> <span class="material-symbols-outlined small_material">refresh</span></div>
 <div class='Label_key' id='Region'></div>
 <div class='Label_key' id='Category'></div>
 <div class='Label_key' id='Product'></div>
 <div class='Label_key' id='Product_head'></div>
 <div class='Label_key' id='Product_middle'></div>
 <div class='Label_key' id='Functionality'></div>
 <div class='Label_key' id='viscosity1'></div>
 <div class='Label_key' id='viscosity2'></div>
 <div class='Label_key' id='viscosity3'></div>
 <div class='Label_key' id='Advantages'></div>
 </div>
 <div id='po_result'></div>
 </div>

</div>
</div>
<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js'></script>
<script>
$('#Advantages_full').hide();
$('.Label_key_box').hide();

var Region_total=7;
var Product_total=21;
var Product_head_total=2;
var Product_middle_total=5;
var Category_total=4;
var Advantages_total=47;
var Functionality_total=4;
var Ajax_Search = function(){
	$.ajax({
		url:'./search_ajax.php',
		type:'post',
		data:{
				"Region" : $("#Opt1").val(),
				"Category" : $("#Opt2").val(),
				"Product" : $("#Opt3").val(),
				"Product_head" : $("#Opt3_1").val(),
				"Product_middle" : $("#Opt3_2").val(),
				"Functionality" : $("#Opt4").val(),
				"viscosity_25" : $("#Opt5_1").val(),
				"viscosity_60" : $("#Opt5_2").val(),
				"viscosity_65" : $("#Opt5_3").val(),
				"Advantages" : $("#Opt6").val(),
				"Search_keyword" : $("#Search_keyword").val()
			},
			success: function(res) {
				$("#po_result").html(res);
			},
			error: function(err) {
				//alert("처리실패");
			}
			});
      var pat=0;
      if($("#Opt1").val()!="") pat=1;
      if($("#Opt1").val()!="") pat=1;
      if($("#Opt2").val()!="") pat=1;
      if($("#Opt3").val()!="") pat=1;
      if($("#Opt3_1").val()!="") pat=1;
      if($("#Opt3_2").val()!="") pat=1;
      if($("#Opt4").val()!="") pat=1;
      if($("#Opt5_1").val()!="") pat=1;
      if($("#Opt5_2").val()!="") pat=1;
      if($("#Opt5_3").val()!="") pat=1;
      if($("#Opt6").val()!="") pat=1;
      if($("#Search_keyword").val()!="") pat=1;
      if(pat==0) $('.Label_key_box').hide();
							//
}
function microtime(get_as_float){ 
			 var now = new Date().getTime() / 1000;
			 var s = parseInt(now);
			 return (get_as_float) ? now : (Math.round((now - s) * 1000) / 1000) + ' ' + s;
}
var close_tek ="";
var del_tek ="";
function close_check(as_check,val,action){ 
			 var Roll_for = $(as_check).val();
			 var Roll_split = Roll_for.split('||');
			 var same_name ="";
			 for(var i in Roll_split) {
               if(val==Roll_split[i]) { 
			   same_name="True";
			   }
			 }
			 return same_name;
}
function close_del_check(as_check,val,action){ 
			 var Roll_for = $(as_check).val();
			 var Roll_split = Roll_for.split('||');
			 var same_name ="";
			 $(as_check).val('');
			 for(var i in Roll_split) {
               if(val!=Roll_split[i]) { 
                 if(Roll_split[i]) $(as_check).val($(as_check).val()+"||"+Roll_split[i]);
			   }
			 }
}
function open_layer(a){ 
   if($(a).css('display')=='none') {
   $(a).show();
   }
}
function close_layer(a){ 

   if($('#Region').text()=="" && $('#Category').text()=="" && $('#Product').text()=="" && $('#roduct_head').text()=="" && $('#Product_middle').text()=="" && $('#Functionality').text()=="" && $('#viscosity1').text()=="" && $('#viscosity2').text()=="" && $('#viscosity3').text()=="" && $('#Advantages').text()=="") {
 $(a).hide();
   }
}
$("#input-left1").on('input', function(){	
	$("#vi11").val($("#input-left1").val());
});
$("#input-right1").on('input', function(){	
	$("#vi12").val($("#input-right1").val());
});

$("#input-left2").on('input', function(){	
	$("#vi21").val($("#input-left2").val());
});
$("#input-right2").on('input', function(){	
	$("#vi22").val($("#input-right2").val());
});

$("#input-left3").on('input', function(){	
	$("#vi31").val($("#input-left3").val());
});
$("#input-right3").on('input', function(){	
	$("#vi32").val($("#input-right3").val());
});

$(document).on('click', '.Product_Advantages_plus', function(e){
	$('#Advantages_half').hide();
	$('#Advantages_full').show();

});
$(document).on('click', '.Product_Advantages_minus', function(e){
	$('#Advantages_half').show();
	$('#Advantages_full').hide();

});

$(document).on('click', '.keyword_reset', function(e){
  location.reload();
});

$(document).on('click', '.Search_option', function(e){
	  if($("."+this.id).css('display')=='none') {
            $("."+this.id).show();
			$("#"+this.id).addClass("d_open_down");
	  } else {
            $("."+this.id).hide();
			$("#"+this.id).removeClass("d_open_down");
	  }
});

$(document).on('click', '.layer_open', function(e){
 var total = $(this).data('total');

 for(i=1; i<=total; i++) {
  $("#layer_"+i).hide();
  $(".layer_open > a").removeClass("bo_cate_on");
 }
  $("#layer_"+$(this).data('now')).show();		
  $("#layer_open"+$(this).data('now')+" > a").addClass("bo_cate_on");
});



$(document).on('click', '.Region', function(e){
			close_tek = close_check("#Opt1",$(this).text(),'');
            now_id = this.id;
			if(close_tek!="True") { //없는 경우에만
			open_layer('.Label_key_box');
            $("#"+this.id).addClass("d_open_down1");
            var orderno1 = $("#Region").children().length;
				if(orderno1 < Region_total)  { //Total Count
					$("#Region").append("<div id='close1_" + now_id + "' class='keyword_round keyword_Region'><!--Region Keyword : --><b>"+$(this).text()+"</b> <span data-name='"+$(this).text()+"'  data-code='"+now_id+"'  class='close close1' id='" + now_id + "'>X</span></div>");
					$("#Opt1").val($("#Opt1").val()+"||"+$(this).text());
						//Delete
						$(".close1").bind("click", function(){
						 del_tek = close_del_check("#Opt1",$(this).data('name'),'del');
						 //$("#Opt1").val(del_tek);
						 $("#close1_"+this.id).remove();
                         $("#"+$(this).data('code')).removeClass("d_open_down1");
			             close_layer('.Label_key_box');
						 Ajax_Search();
						 close_layer('.Label_key_box');
						});
						//Delete
				}
			Ajax_Search();
			} else {
			
			del_tek = close_del_check("#Opt1",$(this).text(),'del');
			//$("#Opt1").val(del_tek);
			$("#close1_"+now_id).remove();
            $("#"+now_id).removeClass("d_open_down1");
			Ajax_Search();
            close_layer('.Label_key_box');
			}
});


$(document).on('click', '.Category', function(e){
			close_tek = close_check("#Opt2",$(this).text(),'');
            now_id = this.id;
			if(close_tek!="True") { //없는 경우에만
			open_layer('.Label_key_box');
			$("#"+this.id).addClass("d_open_down2");
			var orderno1 = $("#Category").children().length;
				if(orderno1 < Category_total)  { //Total Count
					
					$("#Category").append("<div id='close2_" + now_id + "' class='keyword_round keyword_Category'><!--Category Keyword : --><b>"+$(this).text()+"</b> <span data-name='"+$(this).text()+"'  data-code='"+now_id+"' class='close close2' id='" + now_id + "'>X</span></div>");
					$("#Opt2").val($("#Opt2").val()+"||"+$(this).text());
						//Delete
						$(".close2").bind("click", function(){
						 del_tek = close_del_check("#Opt2",$(this).data('name'),'del');
						 //$("#Opt2").val(del_tek);
						 $("#close2_"+this.id).remove();
                         $("#"+$(this).data('code')).removeClass("d_open_down2");
						 Ajax_Search();
						 close_layer('.Label_key_box');
						});
						//Delete
				}
			Ajax_Search();
			} else {
			del_tek = close_del_check("#Opt2",$(this).text(),'del');
			$("#close2_"+now_id).remove();
            $("#"+now_id).removeClass("d_open_down2");
			Ajax_Search();
            close_layer('.Label_key_box');
			}
});


$(document).on('click', '.Product', function(e){
			close_tek = close_check("#Opt3",$(this).text(),'');
            now_id = this.id;
			if(close_tek!="True") { //없는 경우에만
			open_layer('.Label_key_box');
			$("#"+this.id).addClass("d_open_down3");
			var orderno1 = $("#Product").children().length;
				if(orderno1 < Product_total)  { //Total Count
					
					$("#Product").append("<div id='close3_" + now_id + "' class='Oligomer keyword_round keyword_Product'><!--Product Keyword : --><b>"+$(this).text()+"</b> <span data-name='"+$(this).text()+"'  data-code='"+now_id+"' class='close close3' id='" + now_id + "'>X</span></div>");
					$("#Opt3").val($("#Opt3").val()+"||"+$(this).text());
						//Delete
						$(".close3").bind("click", function(){
						 del_tek = close_del_check("#Opt3",$(this).data('name'),'del');
						 //$("#Opt2").val(del_tek);
						 $("#close3_"+this.id).remove();
                         $("#"+$(this).data('code')).removeClass("d_open_down3");
						 Ajax_Search();
						 close_layer('.Label_key_box');
						});
						//Delete
				}
			Ajax_Search();
			} else {
			del_tek = close_del_check("#Opt3",$(this).text(),'del');
			$("#close3_"+now_id).remove();
            $("#"+now_id).removeClass("d_open_down3");
			Ajax_Search();
            close_layer('.Label_key_box');
			}
});
$(document).on('click', '.Product_head', function(e){
			close_tek = close_check("#Opt3_1",$(this).text(),'');
            now_id = this.id;
			if(close_tek!="True") { //없는 경우에만
			if($(this).text()=="Monomer") { $(".Sa3_1").show(); }
			if($(this).text()=="Oligomer") { $(".Sa3_2").show(); }
			open_layer('.Label_key_box');
			$("#"+this.id).addClass("d_open_down3_1");
			var orderno1 = $("#Product_head").children().length;
				if(orderno1 < Product_total)  { //Total Count
					
					$("#Product_head").append("<div id='close3_1_" + now_id + "' class='keyword_round keyword_Product_head'><!--Product_head Keyword : --><b>"+$(this).text()+"</b> <span data-name='"+$(this).text()+"'  data-code='"+now_id+"' class='close close3_1' id='" + now_id + "'>X</span></div>");
					$("#Opt3_1").val($("#Opt3_1").val()+"||"+$(this).text());
						//Delete
						$(".close3_1").bind("click", function(){
						 del_tek = close_del_check("#Opt3_1",$(this).data('name'),'del');
						 //$("#Opt2").val(del_tek);
						 $("#close3_1_"+this.id).remove();
                         $("#"+$(this).data('code')).removeClass("d_open_down3_1");
						 if($(this).data('name')=="Monomer") { $(".Sa3_1").hide(); }
						 if($(this).data('name')=="Oligomer") { $(".Sa3_2").hide(); }
						 Ajax_Search();
						 close_layer('.Label_key_box');
						});
						//Delete
				}
			Ajax_Search();
			} else {
			del_tek = close_del_check("#Opt3_1",$(this).text(),'del');
            //alert($(this).text());
			$("#close3_1_"+now_id).remove();
            $("#"+now_id).removeClass("d_open_down3_1");
			if($(this).text()=="Monomer") { 
                //alert($("#Opt3_1").val());   
                //alert($("#Opt3_2").val());   
			    var split1=$("#Sa3_1").val().split('||');
			    var split2=$("#Sa3_1").data('code').split('||');
                for(u=0; u<$("#Sa3_1").data('name'); u++) {
                   del_tek = close_del_check("#Opt3_2",split1[u],'del');
                   $("#close3_2_"+split2[u]).remove();
                   $("#"+split2[u]).removeClass("d_open_down3_1");
                }
                $(".Sa3_1").hide();   
            }
           
			if($(this).text()=="Oligomer") { 
			    var split1=$("#Sa3_2").val().split('||');
			    var split2=$("#Sa3_2").data('code').split('||');
                for(u=0; u<$("#Sa3_2").data('name'); u++) {
                   del_tek = close_del_check("#Opt3_2",split1[u],'del');
                   $("#close3_2_"+split2[u]).remove();
                   $("#"+split2[u]).removeClass("d_open_down3_1");
                }
			    split1=$("#Sa3_4").val().split('||');
			    split2=$("#Sa3_4").data('code').split('||');
                for(u=0; u<$("#Sa3_4").data('name'); u++) {
                   del_tek = close_del_check("#Opt3",split1[u],'del');
                   $("#close3_"+split2[u]).remove();
                   $("#"+split2[u]).removeClass("d_open_down3");
                }
                $(".Sa3_2").hide(); 
                $(".Oligomer").hide(); 
            }
			Ajax_Search();
            close_layer('.Label_key_box');
			}
});

$(document).on('click', '.Product_middle', function(e){
			close_tek = close_check("#Opt3_2",$(this).text(),'');
            now_id = this.id;

			if(close_tek!="True") { //없는 경우에만
            cs=2;
            for(o=1; o<=Product_middle_total; o++) {
            ou=cs+o;
		    if(this.id=="c2_"+o) { $(".Sa3_"+ou).show(); }
            }

            //alert($(this).text());
			open_layer('.Label_key_box');
			$("#"+this.id).addClass("d_open_down3_1");
			var orderno1 = $("#Product_middle").children().length;
				if(orderno1 < Product_total)  { //Total Count
					
					$("#Product_middle").append("<div id='close3_2_" + now_id + "' class='keyword_round keyword_Product_middle'><!--Product_middle Keyword : --><b>"+$(this).text()+"</b> <span data-name='"+$(this).text()+"'  data-code='"+now_id+"' class='close close3_2' id='" + now_id + "'>X</span></div>");
					$("#Opt3_2").val($("#Opt3_2").val()+"||"+$(this).text());
						//Delete
						$(".close3_2").bind("click", function(){
						 del_tek = close_del_check("#Opt3_2",$(this).data('name'),'del');
						 //$("#Opt2").val(del_tek);
						 $("#close3_2_"+this.id).remove();
                         $("#"+$(this).data('code')).removeClass("d_open_down3_1");
							cs=2;
							for(o=1; o<=Product_middle_total; o++) {
							ou=cs+o;
							if(this.id=="c2_"+o) { $(".Sa3_"+ou).hide(); }
							}
/*
							if(this.id=="c2_1") { $(".Sa3_3").hide(); }
							if(this.id=="c2_2") { $(".Sa3_4").hide(); }
							if(this.id=="c2_3") { $(".Sa3_5").hide(); }
							if(this.id=="c2_4") { $(".Sa3_6").hide(); }
*/
						 Ajax_Search();
						 close_layer('.Label_key_box');
						});
						//Delete
				}
			Ajax_Search();
			} else {
            if($("#"+now_id).data('name')=="Oligomer") {
                //close_del_check("#Opt3",$(this).text(),'del');
                var class_code=$(this).data('code');
                //alert(class_code);
                var vas_talk="";
                for(u=0; u<$('.'+class_code).length; u++) {
                   vas_talk= "."+$(this).data('code')+u;
                   del_tek = close_del_check("#Opt3",$(vas_talk).text(),'del');
                   $(vas_talk).removeClass("d_open_down3");
                   $("#close3_"+$(vas_talk).data('name')).remove();
                }
            }

			del_tek = close_del_check("#Opt3_2",$(this).text(),'del');
			$("#close3_2_"+now_id).remove();
            $("#"+now_id).removeClass("d_open_down3_1");
			cs=2;
			for(o=1; o<=Product_middle_total; o++) {
			ou=cs+o;
			if(this.id=="c2_"+o) { $(".Sa3_"+ou).hide(); }
			}
/*
		    if(now_id=="c2_1") { $(".Sa3_3").hide(); }
			if(now_id=="c2_2") { $(".Sa3_4").hide(); }
			if(now_id=="c2_3") { $(".Sa3_5").hide(); }
			if(now_id=="c2_4") { $(".Sa3_6").hide(); }
*/
			Ajax_Search();
            close_layer('.Label_key_box');
			}
});

$(document).on('click', '.Functionality', function(e){
			close_tek = close_check("#Opt4",$(this).text(),'');
            now_id = this.id;
			if(close_tek!="True") { //없는 경우에만
			open_layer('.Label_key_box');
			$("#"+this.id).addClass("d_open_down4");
			var orderno1 = $("#Functionality").children().length;
				if(orderno1 < Functionality_total)  { //Total Count
					
					$("#Functionality").append("<div id='close4_" + now_id + "' class='keyword_round keyword_Functionality'><!--Functionality Keyword : --><b>"+$(this).text()+"</b> <span data-name='"+$(this).text()+"'  data-code='"+now_id+"' class='close close4' id='" + now_id + "'>X</span></div>");
					$("#Opt4").val($("#Opt4").val()+"||"+$(this).text());
						//Delete
						$(".close4").bind("click", function(){
						 del_tek = close_del_check("#Opt4",$(this).data('name'),'del');
						 //$("#Opt2").val(del_tek);
						 $("#close4_"+this.id).remove();
                         $("#"+$(this).data('code')).removeClass("d_open_down4");
						 Ajax_Search();
						 close_layer('.Label_key_box');
						});
						//Delete
				}
			Ajax_Search();
			} else {
			del_tek = close_del_check("#Opt4",$(this).text(),'del');
			$("#close4_"+now_id).remove();
            $("#"+now_id).removeClass("d_open_down4");
			Ajax_Search();
            close_layer('.Label_key_box');
			}
});


$(document).on('click', '.Search_vi1', function(e){
if($("#vi11").val()!="") { 
$("#viscosity1").html("<div class='keyword_round keyword_viscosity'>Avg. viscosity @25℃ Keyword : <b>"+$("#vi11").val()+"~"+$("#vi12").val()+"</b> <span class='close' id='close5_1'>X</span></div>");
$("#Opt5_1").val($("#vi11").val()+"~"+$("#vi12").val());
}
open_layer('.Label_key_box');
Ajax_Search();

});

$(document).on('click', '.Search_vi2', function(e){

if($("#vi21").val()!="") { 
$("#viscosity2").html("<div class='keyword_round keyword_viscosity'>Avg. viscosity @60℃ Keyword : <b>"+$("#vi21").val()+"~"+$("#vi22").val()+"</b> <span class='close' id='close5_2'>X</span></div>");
$("#Opt5_2").val($("#vi21").val()+"~"+$("#vi22").val());
}
open_layer('.Label_key_box');
Ajax_Search();

});

$(document).on('click', '.Search_vi3', function(e){

if($("#vi31").val()!="") { 
$("#viscosity3").html("<div class='keyword_round keyword_viscosity'>Avg. viscosity @65.5℃ Keyword : <b>"+$("#vi31").val()+"~"+$("#vi32").val()+"</b> <span class='close' id='close5_3'>X</span></div>");
$("#Opt5_3").val($("#vi31").val()+"~"+$("#vi32").val());
}
open_layer('.Label_key_box');
Ajax_Search();

});

$(document).on('click', '.Advantages', function(e){
			close_tek = close_check("#Opt6",$(this).text(),'');
            now_id = this.id;
			now_id = now_id.replace('copy_', '');
			if(close_tek!="True") { //없는 경우에만
			open_layer('.Label_key_box');
			$("#"+now_id).addClass("d_open_down6");
            $("#copy_"+now_id).addClass("d_open_down6");
			var orderno1 = $("#Advantages").children().length;
				if(orderno1 < Advantages_total)  { //Total Count
					
					$("#Advantages").append("<div id='close6_" + now_id + "' class='keyword_round keyword_Advantages'><!--Advantages Keyword : --><b>"+$(this).text()+"</b> <span data-name='"+$(this).text()+"'  data-code='"+now_id+"' class='close close6' id='" + now_id + "'>X</span></div>");
					$("#Opt6").val($("#Opt6").val()+"||"+$(this).text());
						//Delete
						$(".close6").bind("click", function(){
						 //alert();
						 del_tek = close_del_check("#Opt6",$(this).data('name'),'del');
						 //$("#Opt2").val(del_tek);
						 $("#close6_"+this.id).remove();
                         $("#"+$(this).data('code')).removeClass("d_open_down6");
                         $("#copy_"+$(this).data('code')).removeClass("d_open_down6");
						 Ajax_Search();
						 close_layer('.Label_key_box');
						});
						//Delete
				}
			Ajax_Search();
			} else {
			//alert(now_id);
			del_tek = close_del_check("#Opt6",$(this).text(),'del');
			$("#close6_"+now_id).remove();
            $("#"+now_id).removeClass("d_open_down6");
            $("#copy_"+now_id).removeClass("d_open_down6");
			Ajax_Search();
            close_layer('.Label_key_box');
			}
});

$(document).on('click', '#close5_1', function(e){
$("#viscosity1").html('');
$("#Opt5_1").val('');
$("#vi11").val('');
$("#vi12").val('');
Ajax_Search();
});
$(document).on('click', '#close5_2', function(e){
$("#viscosity2").html('');
$("#Opt5_2").val('');
$("#vi21").val('');
$("#vi22").val('');
Ajax_Search();
});
$(document).on('click', '#close5_3', function(e){
$("#viscosity3").html('');
$("#Opt5_3").val('');
$("#vi31").val('');
$("#vi32").val('');
Ajax_Search();
});

$(document).on('click', '#Search_btn', function(e){
Ajax_Search();
});


$(document).on('keyup', '#Search_keyword',function(e){
  if(e.keyCode==13) {
    Ajax_Search();       
  }
});


$(document).on('click', '#Reset_btn', function(e){
$("#Search_keyword").val('');
Ajax_Search();
});

Ajax_Search();
</script>
<script src="/js/sc.js"></script>

	</div>
</div>
<div style="background:#ebebeb;padding:50px;font-size:2em" class="contact">
	<div class="container_box"><p class="small_title_bar">How Can We Help?</p><div class="small_txt">Questions? Concerns? Feedback? Let us know, we're here to help.</div></div>
	<div class="container_box">
<style>
    .small_txt {
      font-size:1rem;
	  padding:10px;
	}
	.small_title_bar {
      font-size:2.5rem;
	  font-weight:600;
	  background: linear-gradient(to left, #292929, #747474);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
	  padding:10px;
	  display:inline-block
	}
.container_box { width:100%;max-width:1200px;margin:0 auto }
.container_box .select-style select, .container_box .select-style input {
    width: 100%;
    background-color: transparent;
    background-image: none;
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    cursor: pointer;
	font-size:0.9rem;
	background:#f9f9f9;
}

.container_box textarea{
	font-size:0.9rem;
}

.container_box .col_text {
	font-size:0.9rem;
	background:#3fb0ff;
	color:#fff
}

.container_box .col_text_no {
	font-size:0.9rem;
	background:#c3c3c3;
	color:#fff
}

.container_box button, select, input {
    text-transform: none;
	height:50px;
}


.container_box input {
    text-transform: none;
	height:50px;
}

.container_box button, input, optgroup, select, textarea {
    margin: 0;
    font-family: inherit;
    font-size: inherit;
    line-height: inherit;
}
.container_box .small_td {
    width:33.3%;
	float:left;
	padding:10px;
}
.container_box .big_td {
    width:50%;
	float:left;
	padding:10px;
}
.container_box .big_td_full {
    width:100%;
	padding:10px
}
.container_box .fx_Value{
    font-size: 0.6em;
}
.container_box .fx_Value > span{
    font-weight:bold;
	color:#f54f15
}
.pc_none { display:none }
.news2, .news3, .news4, .news5, .news6 { display:none }

.select-step{
  position: relative;
  display: inline-block;
  margin-bottom: 15px;
  width :100%;

}

.select-step select{
  display:inline-block;
  width:100%;
  padding:10px 15px;
  appearance:none;
  -webkit-appearance:none;
  -moz-appearance:none;
}

.select-step select::-ms-expand{
  display:none;
}

	.select__arrow{
	  position: absolute;
	  top :22px;
	  right: 15px;
	  width :0;
	  height :0;
	  pointer-events: none;
	  border-style :solid;
	  border-width: 8px 5px 0 5px;
	  border-color: #999 transparent transparent transparent;
	}
	.tcenter { text-align:center }
</style>
                   <form name="q_post_content" onsubmit="return contactr_submit(this);" method="post">
		           <input type=hidden name='page' value='/eng/Products/search.php'>
		           <input type=hidden name='lang' value='eng'>
                   <div class="row">
                        <div class="big_td_full">
                            <textarea name="comment" id="comment_wrkey" placeholder="Please specify the name of the product, chemicals, or documents you need when you enter your message here *" rows="6" class="big-textarea required"></textarea><p style='font-size:0.85rem;margin-top:10px'>Notice: If you are located in the United States, please let us know which state you live in so that your inquiry can be processed quickly as possible.</p>
                        </div>
				   </div>
            
                   <div class="row pc_none" id="kw_use">

                        <div class="small_td">
                            <div class="select-step select-style big-select">
                                <select name="location" id="Region" class="bg-transparent mb-0" required>
                                    <option value="">Select Your Location</option>
									<option value='Afghanistan@@miramer@miwonsc.com'>Afghanistan</option><option value='Albania@@miramer@miwonsc.com'>Albania</option><option value='Algeria@@miramer@miwonsc.com'>Algeria</option><option value='Angola@@miramer@miwonsc.com'>Angola</option><option value='Argentina@@miramer@miwonsc.com'>Argentina</option><option value='Armenia@@miramer@miwonsc.com'>Armenia</option><option value='Aruba@@miramer@miwonsc.com'>Aruba</option><option value='Australia@@miramer@miwonsc.com'>Australia</option><option value='Austria@@miramer@miwonsc.com'>Austria</option><option value='Azerbaijan@@miramer@miwonsc.com'>Azerbaijan</option><option value='Bahamas@@miramer@miwonsc.com'>Bahamas</option><option value='Bahrain@@miramer@miwonsc.com'>Bahrain</option><option value='Bangladesh@@miramer@miwonsc.com'>Bangladesh</option><option value='Barbados@@miramer@miwonsc.com'>Barbados</option><option value='Belarus@@miramer@miwonsc.com'>Belarus</option><option value='Belgium@@miramer@miwonsc.com'>Belgium</option><option value='Belize@@miramer@miwonsc.com'>Belize</option><option value='Benin@@miramer@miwonsc.com'>Benin</option><option value='Bhutan@@miramer@miwonsc.com'>Bhutan</option><option value='Bolivia (Plurinational State of)@@miramer@miwonsc.com'>Bolivia (Plurinational State of)</option><option value='Bosnia and Herzegovina@@miramer@miwonsc.com'>Bosnia and Herzegovina</option><option value='Botswana@@miramer@miwonsc.com'>Botswana</option><option value='Brazil@@miramer@miwonsc.com'>Brazil</option><option value='Brunei Darussalam@@miramer@miwonsc.com'>Brunei Darussalam</option><option value='Bulgaria@@miramer@miwonsc.com'>Bulgaria</option><option value='Burkina Faso@@miramer@miwonsc.com'>Burkina Faso</option><option value='Burundi@@miramer@miwonsc.com'>Burundi</option><option value='Cambodia@@miramer@miwonsc.com'>Cambodia</option><option value='Cameroon@@miramer@miwonsc.com'>Cameroon</option><option value='Canada@@miramer@miwonsc.com'>Canada</option><option value='Cape Verde@@miramer@miwonsc.com'>Cape Verde</option><option value='Central African Republic@@miramer@miwonsc.com'>Central African Republic</option><option value='Chad@@miramer@miwonsc.com'>Chad</option><option value='Channel Islands@@miramer@miwonsc.com'>Channel Islands</option><option value='Chile@@miramer@miwonsc.com'>Chile</option><option value='China@@miramer@miwonsc.com'>China</option><option value='China, Hong Kong@@miramer@miwonsc.com'>China, Hong Kong</option><option value='China, Macao@@miramer@miwonsc.com'>China, Macao</option><option value='China, Taiwan@@miramer@miwonsc.com'>China, Taiwan</option><option value='Colombia@@miramer@miwonsc.com'>Colombia</option><option value='Comoros@@miramer@miwonsc.com'>Comoros</option><option value='Congo (Congo-Brazzaville)@@miramer@miwonsc.com'>Congo (Congo-Brazzaville)</option><option value='Congo (Democratic Republic of the)@@miramer@miwonsc.com'>Congo (Democratic Republic of the)</option><option value='Costa Rica@@miramer@miwonsc.com'>Costa Rica</option><option value='Côte d`Ivoire@@miramer@miwonsc.com'>Côte d`Ivoire</option><option value='Croatia@@miramer@miwonsc.com'>Croatia</option><option value='Cuba@@miramer@miwonsc.com'>Cuba</option><option value='Cyprus@@miramer@miwonsc.com'>Cyprus</option><option value='Czech Republic@@miramer@miwonsc.com'>Czech Republic</option><option value='Denmark@@miramer@miwonsc.com'>Denmark</option><option value='Djibouti@@miramer@miwonsc.com'>Djibouti</option><option value='Dominican Republic@@miramer@miwonsc.com'>Dominican Republic</option><option value='Ecuador@@miramer@miwonsc.com'>Ecuador</option><option value='Egypt@@miramer@miwonsc.com'>Egypt</option><option value='El Salvador@@miramer@miwonsc.com'>El Salvador</option><option value='Equatorial Guinea@@miramer@miwonsc.com'>Equatorial Guinea</option><option value='Eritrea@@miramer@miwonsc.com'>Eritrea</option><option value='Estonia@@miramer@miwonsc.com'>Estonia</option><option value='Ethiopia@@miramer@miwonsc.com'>Ethiopia</option><option value='Fiji@@miramer@miwonsc.com'>Fiji</option><option value='Finland@@miramer@miwonsc.com'>Finland</option><option value='France@@miramer@miwonsc.com'>France</option><option value='French Guiana@@miramer@miwonsc.com'>French Guiana</option><option value='French Polynesia@@miramer@miwonsc.com'>French Polynesia</option><option value='Gabon@@miramer@miwonsc.com'>Gabon</option><option value='Gambia@@miramer@miwonsc.com'>Gambia</option><option value='Georgia@@miramer@miwonsc.com'>Georgia</option><option value='Germany@@miramer@miwonsc.com'>Germany</option><option value='Ghana@@miramer@miwonsc.com'>Ghana</option><option value='Greece@@miramer@miwonsc.com'>Greece</option><option value='Grenada@@miramer@miwonsc.com'>Grenada</option><option value='Guadeloupe@@miramer@miwonsc.com'>Guadeloupe</option><option value='Guam@@miramer@miwonsc.com'>Guam</option><option value='Guatemala@@miramer@miwonsc.com'>Guatemala</option><option value='Guinea@@miramer@miwonsc.com'>Guinea</option><option value='Guinea-Bissau@@miramer@miwonsc.com'>Guinea-Bissau</option><option value='Guyana@@miramer@miwonsc.com'>Guyana</option><option value='Haiti@@miramer@miwonsc.com'>Haiti</option><option value='Honduras@@miramer@miwonsc.com'>Honduras</option><option value='Hungary@@miramer@miwonsc.com'>Hungary</option><option value='Iceland@@miramer@miwonsc.com'>Iceland</option><option value='India@@miramer@miwonsc.com'>India</option><option value='Indonesia@@miramer@miwonsc.com'>Indonesia</option><option value='Iran (Islamic Republic of)@@miramer@miwonsc.com'>Iran (Islamic Republic of)</option><option value='Iraq@@miramer@miwonsc.com'>Iraq</option><option value='Ireland@@miramer@miwonsc.com'>Ireland</option><option value='Israel@@miramer@miwonsc.com'>Israel</option><option value='Italy@@miramer@miwonsc.com'>Italy</option><option value='Jamaica@@miramer@miwonsc.com'>Jamaica</option><option value='Japan@@miramer@miwonsc.com'>Japan</option><option value='Jordan@@miramer@miwonsc.com'>Jordan</option><option value='Kazakhstan@@miramer@miwonsc.com'>Kazakhstan</option><option value='Kenya@@miramer@miwonsc.com'>Kenya</option><option value='Korea (Democratic People`s Republic of)@@miramer@miwonsc.com'>Korea (Democratic People`s Republic of)</option><option value='Korea (Republic of)@@miramer@miwonsc.com'>Korea (Republic of)</option><option value='Kuwait@@miramer@miwonsc.com'>Kuwait</option><option value='Kyrgyzstan@@miramer@miwonsc.com'>Kyrgyzstan</option><option value='Lao People`s Democratic Republic@@miramer@miwonsc.com'>Lao People`s Democratic Republic</option><option value='Latvia@@miramer@miwonsc.com'>Latvia</option><option value='Lebanon@@miramer@miwonsc.com'>Lebanon</option><option value='Lesotho@@miramer@miwonsc.com'>Lesotho</option><option value='Liberia@@miramer@miwonsc.com'>Liberia</option><option value='Libyan Arab Jamahiriya@@miramer@miwonsc.com'>Libyan Arab Jamahiriya</option><option value='Lithuania@@miramer@miwonsc.com'>Lithuania</option><option value='Luxembourg@@miramer@miwonsc.com'>Luxembourg</option><option value='Madagascar@@miramer@miwonsc.com'>Madagascar</option><option value='Malawi@@miramer@miwonsc.com'>Malawi</option><option value='Malaysia@@miramer@miwonsc.com'>Malaysia</option><option value='Maldives@@miramer@miwonsc.com'>Maldives</option><option value='Mali@@miramer@miwonsc.com'>Mali</option><option value='Malta@@miramer@miwonsc.com'>Malta</option><option value='Martinique@@miramer@miwonsc.com'>Martinique</option><option value='Mauritania@@miramer@miwonsc.com'>Mauritania</option><option value='Mauritius@@miramer@miwonsc.com'>Mauritius</option><option value='Mayotte@@miramer@miwonsc.com'>Mayotte</option><option value='Mexico@@miramer@miwonsc.com'>Mexico</option><option value='Micronesia (Federated States of)@@miramer@miwonsc.com'>Micronesia (Federated States of)</option><option value='Mongolia@@miramer@miwonsc.com'>Mongolia</option><option value='Montenegro@@miramer@miwonsc.com'>Montenegro</option><option value='Morocco@@miramer@miwonsc.com'>Morocco</option><option value='Mozambique@@miramer@miwonsc.com'>Mozambique</option><option value='Myanmar@@miramer@miwonsc.com'>Myanmar</option><option value='Namibia@@miramer@miwonsc.com'>Namibia</option><option value='Nepal@@miramer@miwonsc.com'>Nepal</option><option value='Netherlands@@miramer@miwonsc.com'>Netherlands</option><option value='Netherlands Antilles@@miramer@miwonsc.com'>Netherlands Antilles</option><option value='New Caledonia@@miramer@miwonsc.com'>New Caledonia</option><option value='New Zealand@@miramer@miwonsc.com'>New Zealand</option><option value='Nicaragua@@miramer@miwonsc.com'>Nicaragua</option><option value='Niger@@miramer@miwonsc.com'>Niger</option><option value='Nigeria@@miramer@miwonsc.com'>Nigeria</option><option value='North Macedonia (Republic of)@@miramer@miwonsc.com'>North Macedonia (Republic of)</option><option value='Norway@@miramer@miwonsc.com'>Norway</option><option value='Occupied Palestinian Territory@@miramer@miwonsc.com'>Occupied Palestinian Territory</option><option value='Oman@@miramer@miwonsc.com'>Oman</option><option value='Pakistan@@miramer@miwonsc.com'>Pakistan</option><option value='Panama@@miramer@miwonsc.com'>Panama</option><option value='Papua New Guinea@@miramer@miwonsc.com'>Papua New Guinea</option><option value='Paraguay@@miramer@miwonsc.com'>Paraguay</option><option value='Peru@@miramer@miwonsc.com'>Peru</option><option value='Philippines@@miramer@miwonsc.com'>Philippines</option><option value='Poland@@miramer@miwonsc.com'>Poland</option><option value='Portugal@@miramer@miwonsc.com'>Portugal</option><option value='Puerto Rico@@miramer@miwonsc.com'>Puerto Rico</option><option value='Qatar@@miramer@miwonsc.com'>Qatar</option><option value='Republic of Moldova@@miramer@miwonsc.com'>Republic of Moldova</option><option value='Réunion@@miramer@miwonsc.com'>Réunion</option><option value='Romania@@miramer@miwonsc.com'>Romania</option><option value='Russian Federation@@miramer@miwonsc.com'>Russian Federation</option><option value='Rwanda@@miramer@miwonsc.com'>Rwanda</option><option value='Saint Lucia@@miramer@miwonsc.com'>Saint Lucia</option><option value='Saint Vincent and the Grenadines@@miramer@miwonsc.com'>Saint Vincent and the Grenadines</option><option value='Samoa@@miramer@miwonsc.com'>Samoa</option><option value='Sao Tome and Principe@@miramer@miwonsc.com'>Sao Tome and Principe</option><option value='Saudi Arabia@@miramer@miwonsc.com'>Saudi Arabia</option><option value='Senegal@@miramer@miwonsc.com'>Senegal</option><option value='Serbia@@miramer@miwonsc.com'>Serbia</option><option value='Sierra Leone@@miramer@miwonsc.com'>Sierra Leone</option><option value='Singapore@@miramer@miwonsc.com'>Singapore</option><option value='Slovakia@@miramer@miwonsc.com'>Slovakia</option><option value='Slovenia@@miramer@miwonsc.com'>Slovenia</option><option value='Solomon Islands@@miramer@miwonsc.com'>Solomon Islands</option><option value='Somalia@@miramer@miwonsc.com'>Somalia</option><option value='South Africa@@miramer@miwonsc.com'>South Africa</option><option value='Spain@@miramer@miwonsc.com'>Spain</option><option value='Sri Lanka@@miramer@miwonsc.com'>Sri Lanka</option><option value='Sudan@@miramer@miwonsc.com'>Sudan</option><option value='Suriname@@miramer@miwonsc.com'>Suriname</option><option value='Swaziland@@miramer@miwonsc.com'>Swaziland</option><option value='Sweden@@miramer@miwonsc.com'>Sweden</option><option value='Switzerland@@miramer@miwonsc.com'>Switzerland</option><option value='Syrian Arab Republic@@miramer@miwonsc.com'>Syrian Arab Republic</option><option value='Tajikistan@@miramer@miwonsc.com'>Tajikistan</option><option value='Thailand@@miramer@miwonsc.com'>Thailand</option><option value='Timor-Leste@@miramer@miwonsc.com'>Timor-Leste</option><option value='Togo@@miramer@miwonsc.com'>Togo</option><option value='Tonga@@miramer@miwonsc.com'>Tonga</option><option value='Trinidad and Tobago@@miramer@miwonsc.com'>Trinidad and Tobago</option><option value='Tunisia@@miramer@miwonsc.com'>Tunisia</option><option value='Türkiye@@miramer@miwonsc.com'>Türkiye</option><option value='Turkmenistan@@miramer@miwonsc.com'>Turkmenistan</option><option value='Uganda@@miramer@miwonsc.com'>Uganda</option><option value='Ukraine@@miramer@miwonsc.com'>Ukraine</option><option value='United Arab Emirates@@miramer@miwonsc.com'>United Arab Emirates</option><option value='United Kingdom@@miramer@miwonsc.com'>United Kingdom</option><option value='United Republic of Tanzania@@miramer@miwonsc.com'>United Republic of Tanzania</option><option value='United States of America@@miramer@miwonsc.com'>United States of America</option><option value='United States Virgin Islands@@miramer@miwonsc.com'>United States Virgin Islands</option><option value='Uruguay@@miramer@miwonsc.com'>Uruguay</option><option value='Uzbekistan@@miramer@miwonsc.com'>Uzbekistan</option><option value='Vanuatu@@miramer@miwonsc.com'>Vanuatu</option><option value='Venezuela (Bolivarian Republic of)@@miramer@miwonsc.com'>Venezuela (Bolivarian Republic of)</option><option value='Vietnam@@miramer@miwonsc.com'>Vietnam</option><option value='Western Sahara@@miramer@miwonsc.com'>Western Sahara</option><option value='Yemen@@miramer@miwonsc.com'>Yemen</option><option value='Zambia@@miramer@miwonsc.com'>Zambia</option><option value='Zimbabwe@@miramer@miwonsc.com'>Zimbabwe</option>                                </select>
								<div class="select__arrow"></div>
                            </div>
                        </div>
                        <div class="small_td">
                            <div class="select-step select-style big-select">
                                <select name="category" id="Application" class="bg-transparent mb-0">
                                    <option value="">Select a category</option>
									<option value="Academia">Academia</option>
									<option value="Current Customer">Current Customer</option>
									<option value="Potential Customer">Potential Customer</option>
									<!--<option value="Industrial_coating">Industrial_coating</option>-->
									<option value="Other">Other</option>
                                </select>
								<div class="select__arrow"></div>
                            </div>
                        </div>
                        <div class="small_td">
                            <div class="select-step select-style big-select">
                                <select name="inquiry" id="Region" class="bg-transparent mb-0">
                                    <option value="">Select a Type of inquiry</option>
									<option value="Sales">Sales</option>
									<option value="Technical Support">Technical Support</option>
									<option value="Compliance">Compliance</option>
									<option value="SDS">SDS</option> 
									<option value="Technical Literature">Technical Literature</option> 
									<option value="Other">Other</option>
                                </select>
								<div class="select__arrow"></div>
                            </div>
                        </div>
                        <div class="big_td">
                            <div class="select-style big-select">
							   <input type="text" name="name1" required  placeholder="First name" class="big-input required">
                            </div>
                        </div>
                       <div class="big_td">
                            <div class="select-style big-select">
                                <input type="text" name="name2" required  placeholder="Last name" class="big-input required">
                            </div>
						</div>
                        <div class="big_td">
                            <div class="select-style big-select">
							   <input type="text" name="email" required  placeholder="E-mail" class="big-input required">
                            </div>
                        </div>
                       <div class="big_td">
                            <div class="select-style big-select">
                                <input type="text" name="phone"   placeholder="Phone" class="big-input">
                            </div>
						</div>
                        <div class="big_td">
                            <div class="select-style big-select">
							   <input type="text" name="company" required  placeholder="Company" class="big-input required">
                            </div>
                        </div>
                       <div class="big_td">
                            <div class="select-style big-select">
                                <input type="text" name="ma" required  placeholder="Market & application" class="big-input required">
                            </div>
						</div>

                        <div class="big_td_full">
						    <label class="fx_Value"><img src='/img/require.png'> Mandatory Fields.</label><br>
                            <style>
#contect_area_go {  margin-top:50px;font-size:0.9em;font-weight:600;padding-bottom:20px;margin-bottom:10px;border-bottom:1px dotted silver  }
#contect_area_go_but {  float:right;font-size:0.5em;cursor:pointer;  }
#contect_area_go_but span{  font-size:1.2em  }
#contect_area {width:100%; max-width:1200px;  margin:0px auto;font-size:0.8em; padding:20px; background:#fff }
#contect_area .btits { font-size:0.8em;padding-left:10px;  }
#contect_area .btit {  margin-top:10px;font-size:0.9em;font-weight:600;padding-bottom:20px;margin-bottom:10px;border-bottom:1px dotted silver  }
#contect_area .btit_top { margin-top:40px;font-size:0.9em;font-weight:600;padding-bottom:20px;margin-bottom:10px;border-bottom:1px dotted silver  }
#contect_area .bcon { font-size:0.8em;  }
#contect_area .bcons { font-size:0.8em;padding-left:35px;  }

</style>

<div id="contect_area_go">
Consent to collection, use and provision of personal information
<a id="contect_area_go_but"><span id='contect_area_go_plus'>+</span><span id='contect_area_go_minus' style="display:none">-</span> All</a>
</div>
<div id="contect_area" class="sub01_01" style="display:none">

<p class='btit'>Purpose for the Collection and Use of Personal Information</p>

<p class='bcon p10'>The company processes personal information for the following purposes. The personal information being processed will not be used for any purpose other than the following, and in any case where the purpose of use changes, we will take due measures, such as obtaining additional consent according to Article 18 of the Personal Information Protection Act.</p>

<p class='btits'>I.	Service Provision and Respond to Inquiry</p>
<p class='bcons'>Provision of product information, marketing, development of new products and provision of customized services, delivery of requested samples, response to product complaints, record preservation for dispute resolution, sales response, answers to inquiries from customers and civil servants, request for personal information access, correction, and suspension of processing</p>


<p class='btit_top'>Processing and Use of Personal Information and Retention Period</p>
<p class='bcon p10'>
The company processes and retains personal information within the period of retention and use of personal information in accordance with laws and regulations or within the period of retention and use of personal information agreed upon when collecting personal information from the information subject.</p>
<p class='btits'>I.	Service Provision and Respond to Inquiry: 3 Months</p>

<p class='btit_top'>Items of Personal Information Processed</p>

<p class='bcon p10'>The company collects the following personal information from the information subjects.</p>

<p class='btits'>I.	 Service Provision and Respond to Inquiry</p>
<p class='bcons'>A.	Mandatory Items: person’s name, e-mail address, company name, location</p>
<p class='bcons'>B.	Optional Items: Contact Information (Phone number)</p>

</div>

<script>
$("#contect_area_go_but").click(function() {
  
  if($('#contect_area').css('display')=="none") {
  $('#contect_area_go_plus').hide();
  $('#contect_area_go_minus').show(); 
  $('#contect_area').show(); 
  } else {
  $('#contect_area_go_minus').hide();
  $('#contect_area_go_plus').show(); 
  $('#contect_area').hide(); 
  }
});
</script>
                            <input type="checkbox" name="agree"  id="contact_agree"> 
							<label class="fx_Value">
								(Required) I agree to the collection and use of personal information in order to process and follow my inquiry.

							</label>

                        </div>
                        <div class="big_td_full">
                            <button id="project-contact-us-button" onclick='FormCheck()' class="btn btn-transparent-dark-gray btn-large margin-20px-top col_text">Send</button>
                            <button id="project-re-button" class="btn btn-transparent-dark-gray btn-large margin-20px-top col_text_no">Cancel</button>
                        </div>
                    </div></form>
	</div>
</div>
<style>
.f_box { width:100%;max-width:1200px;margin:0 auto; }
.f_box .f_half1 { width:60%;float:left; }
.f_box .f_half2 { width:40%;float:left; }
.f_box .f_half { width:50%;float:left; }
.f_box .f_half3 { width:32%;float:left; }
.f_box .f_half4 { width:68%;float:left; }
.f_box .f_gan { color:#e5e5e5;margin-right:15px; }
.f_box .full_body { width:100%;height:50px }
.qmenu { margin-left:100px;font-size:0.9rem}
.qmenu li{ line-height:160% }
.f_box .qmenu_title{ font-weight:600;font-size:1.2rem;margin-bottom:15px; }
.pl10 { padding-left:10px}
.pt10 { padding-top:10px}
.mt10 { margin-top:10px}
.mt20 { margin-top:20px}
.mt30 { margin-top:30px}
.f-height { margin-left:10px;margin-bottom:15px;display:table;width:100%; }
.f-height a { color:#e5e5e5 }
.f_bold { color:#fff;font-weight:600 }
</style> 
<script src="https://miwonsc.com/theme/basic/js/css3-animate-it.js"></script>
<!-- 하단 시작 { -->
<footer id="footer">
	<div class="wrap footer_box">
	  <div class="f_box">
	    <div class="f_half1">
		 <div class='full_body'><h1><a href="/"><img src='/img/mi_1.png?'></a></h1></div>
		 <div class='full_body pl10'>We are committed to making tomorrow better by<br>fostering innovative and sustainable solutions.</div>
		 <div class='full_body pl10 mt30'>
		 <span class='f_gan'>www.miwonsc.com</span> <span class='f_gan'>|</span> <span class='f_gan'>TEL: +82-31-479-9140</span><br>
		  20 Poeun-daero 59 beon-gil, Suji-gu, Yongin-si, Gyeonggi-do, 16864, Korea  </div>
		 </div>
	    <div class="f_half2">
		  <div class="f_half3">
             <ul>
				<li class='qmenu_title' style='text-align:left'>Stay Connected</li>
				<li style='padding-left:20px;'><A href='https://www.linkedin.com/company/83511337/admin/' target=_blank><img src='/img/linkdin.png' height=20px></a></li>
			</ul>

		  </div>
		  <div class="f_half4">
			<ul class="qmenu">
				<li class='qmenu_title' style='text-align:left'>Quick Navigation</li>
				<li>
					<div class='f-height'>
					  <A href='/eng/Company/company.html'><span class='f_half'>ABOUT US</span></a>
					  <A href='/eng/Sustainability/Sustainability.html'><span class='f_half'>Sustainability</span></a>
					</div>
					<div class='f-height'>
					  <A href='/eng/Products/search.php'><span class='f_half'>Products</span></a>
					  <A href='/bbs/board.php?bo_table=eng_news'><span class='f_half'>Info Center</span></a>
					</div>
					<div class='f-height'>
					  <A href='/eng/Market/electronics.html'><span>Market & Application</span></a>
					  <!--A href='/eng/Careers/Human.html'><span class='f_half'>인재채용</span></a-->
					</div>
				</li>
			</ul>
		  </div>
	    </div>
	  </div>
	</div>
	<div class="f_copyright">
	  <div class="f_box">
	    <div class="f_half t_left pl10"><a href='/eng/service/Privacy_Statement.html' class='f_gan f_bold'>Privacy Statement</a>  <a href='/eng/service/contact.html' class='f_gan'>CONTACT</a> </div>
        <div class="f_half t_right">© 2022 <strong>Miwon Specialty Chemical Co., Ltd.</strong> All rights reserved.</div>
	  </div>
	</div>
	<a href="javascript:" id="top_btn"><i class="fa fa-angle-up" aria-hidden="true"></i><span class="sound_only">상단으로</span> </a>
    
</footer>
<!-- } 하단 끝 -->



<!-- ie6,7에서 사이드뷰가 게시판 목록에서 아래 사이드뷰에 가려지는 현상 수정 -->
<!--[if lte IE 7]>
<script>
$(function() {
    var $sv_use = $(".sv_use");
    var count = $sv_use.length;

    $sv_use.each(function() {
        $(this).css("z-index", count);
        $(this).css("position", "relative");
        count = count - 1;
    });
});
</script>
<![endif]-->
		 <script src="/js/wow.js"></script>
		 <script>
                $(".dropdown_share").click(function(){
					var url = '/eng/Products/search.php';
					var textarea = document.createElement("textarea");
					document.body.appendChild(textarea);
					url = window.document.location.href;
					textarea.value = url;
					textarea.select();
					document.execCommand("copy");
					document.body.removeChild(textarea);
					alert("URL이 복사되었습니다.")
				});
				$("#comment_wrkey").click(function(){
					if ($('#kw_use').css('display') === 'none') {
						$("#kw_use").show(500);
					}
				});
				$("#project-re-button").click(function(){
						$("#kw_use").hide(500);
				});
				$(".main_card li").hover(function(){
				   for(i=1; i<7; i++) {
                    if(this.id=="news"+i) {
					  $(".news"+i).show();
					  //$('#news'+i).addClass('active');
					} else {
					  $(".news"+i).hide();
					  //$('#news'+i).removeClass('active');
					  //$('#news'+i+ ' > a').removeClass('aline');
					}
				   }
				});

				wow = new WOW(
				  {
					animateClass: 'animated',
					offset:       100,
					callback:     function(box) {
					  console.log("WOW: animating <" + box.tagName.toLowerCase() + ">")
					}
				  }
				);
				wow.init();
				document.getElementById('moar').onclick = function() {
				  var section = document.createElement('section');
				  section.className = 'section--purple wow fadeInDown';
				  this.parentNode.insertBefore(section, this);
				};
			// submit 최종 폼체크
				function contactr_submit(f)
				{
                  				  if (f.agree.checked==false) {
						alert("You must agree to the Privacy Policy.");
						//f.re1.focus();
						return false;
				  }     
				  var error = "NO";
				  var message = "";
				  var link = "";
				  var params = $("form[name=q_post_content]").serialize();
					 
			  
					$.ajax({
						url: "/register_sign.php",
						method: "post",
						dataType: "json",
						async: false,
						data: params,
						success: function (data) {
						if (data.code == 1)
						{
							error = 'YES';
							message =data.message
							link =data.link;
						} else {
							error = 'NO';
							message =data.message
							link =data.link;
					   }
						}
					});
				  
					alert(message);
                    //return false;
			 

				}
		</script>
		<script>
 		$(function() {
			$("#top_btn").on("click", function() {
				$("html, body").animate({scrollTop:0}, '500');
				return false;
			});
			$("#first_nav").on("click", function() {
				$("html, body").animate({scrollTop:0}, '500');
				return false;
			});
		});
		</script>
<style>
.btn_cookie_area {
  position: fixed; /* 이 부분을 고정 */
  bottom: 0; /* 하단에 여백 없이 */
  width: 100%; /* 가로 사이즈를 브라우저에 가득 채움 */
  height: 150px;
  background:#f7f7f7;
  z-index:9999999999;
}
.btn_cookie_area .container{
  max-width:1200px;
  width:100%;
  margin:0 auto;
}
.btn_cookie_area .container > p{
  width:70%;
  float:left;
  padding-top:30px;
  font-size:1.1em 
}

.btn_cookie_area .container > p.hum  {
  width:30%;
  text-align:right;
  padding-top:50px;
}

.btn_cookie_area .container > p.hum > .Allsign {
    font-size: 0.8em;
    margin-left: 20px;
    padding: 10px;
    background: #28AFB0;
    color: #fff;
    cursor: pointer;
    border-radius: 9px;
    margin-top:30px
}
.btn_cookie_area .container > p.hum > .Close {
    width: 150px;
    font-size: 0.8em;
    margin-left: 20px;
    padding: 10px;
    background: #43536a;
    color: #fff;
    cursor: pointer;
    border-radius: 9px;
    margin-top:30px
}
@media (max-width:960px) {
.btn_cookie_area {
  position: fixed; /* 이 부분을 고정 */
  bottom: 0; /* 하단에 여백 없이 */
  width: 100%; /* 가로 사이즈를 브라우저에 가득 채움 */
  height: auto;
  background:#f7f7f7;
  z-index:9999999999;
}
.btn_cookie_area .container > p {
    width: 100%;
    float:normal;
    padding:20px;
}
.btn_cookie_area .container > p.hum  {
  width:100%;
  padding-top:10px;
}

}
</style>

<div class="btn_cookie_area" style="display:none">
    <div class="container gnormal">
	<p>We value your privacy<br>
This website uses cookies to ensure you get the best experience on our website.<br>By continuing to browse, you agree to the use of cookies to enhance your site experience. </p>

	<p class="hum"><a href="#" class="Allsign" onclick="javascript:aCookie();">Accept all cookies</a>
	<!--a href="#" class="Close" onclick="javascript:aClose();">&times;</a--></p>
    </div>
</div>    
<script>
  $(document).ready(function() {
	  var aCookie = getCookie("agreecookie");
      //alert(aCookie);
	  if(!aCookie) {
		  $('div.btn_cookie_area').show();  
	  }
	  $(".gnb_al_a_mobile").on("click", function() {
		if ( $(this).hasClass('active') ) {
            //alert(1);
			$(this).find(' > .hipup').hide();
			$(this).find(' > .hipdown').show();
			$(this).find(' > .ulo_hide').hide();
			$(this).removeClass('active');
		}
		else {
            //alert(2);
			$('.hipdown').show();
			$('.hipup').hide();
			$('.ulo_hide').hide();
			$('.gnb_al_a_mobile').removeClass('active');
			$(this).find(' > .ulo_hide').show();
			$(this).find(' > .hipdown').hide();
			$(this).find(' > .hipup').show();
			$(this).addClass('active');
		}		  
	  });
  });
  
  function aCookie() {
	  $('div.btn_cookie_area').hide();
	  setCookie("agreecookie", 'agreecookie', 365);
  }
  
  function aClose() {
	  $('div.btn_cookie_area').hide();  
  }


  function setCookie(cookie_name, value, days) {
	  var exdate = new Date();
	  exdate.setDate(exdate.getDate() + days);
	  // 설정 일수만큼 현재시간에 만료값으로 지정

	  var cookie_value = escape(value) + ((days == null) ? '' : '; path=/; expires=' + exdate.toUTCString());
	  document.cookie = cookie_name + '=' + cookie_value;
  }

  function getCookie(cookie_name) {
		var x, y;
		var val = document.cookie.split(';');
		for (var i = 0; i < val.length; i++) {
			x = val[i].substr(0, val[i].indexOf('='));
			y = val[i].substr(val[i].indexOf('=') + 1);
			x = x.replace(/^\s+|\s+$/g, '');
			// 앞과 뒤의 공백 제거하기
			if (x == cookie_name) {
				return unescape(y);
				// unescape로 디코딩 후 값 리턴
			}
		}
  }
</script>
<script>
function mcheck(a,b) {
   var dataString = 'lng=eng&get_cook=set_80981349.37.115.251&row='+ a;


   if($('#'+b).prop("checked")==false) {
   dataString = dataString + '&type=del';
   } else {
   dataString = dataString + '&type=add';
   }

   $.ajax({
    type: "POST",
    url: "/input.php",
    data: dataString,
    cache: false,
    success: function(html) {
        alert(html);
    }
   	});
}
function ccheck(a,b) {
   var dataString = 'lng=eng&get_cook=set_80981349.37.115.251&type=del&row='+ a;

   $.ajax({
    type: "POST",
    url: "/input.php",
    data: dataString,
    cache: false,
    success: function(html) {
        alert(html);
    }
   	});
    location.href='/eng/Products/search.php';
}
</script>

</script>
</body>
</html>
