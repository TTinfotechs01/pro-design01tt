<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=0,maximum-scale=10,user-scalable=yes">
<meta name="HandheldFriendly" content="true">
<meta name="format-detection" content="telephone=no">
<meta http-equiv="imagetoolbar" content="no">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<link rel="canonical" href="http://miwonsc.com/">
<link rel="shortcut icon" href="/img/miwon.ico">
<meta name="author" content="Miwon Specialty Chemical Co., Ltd.">
<meta name="subject" content="Miwon Specialty Chemical Co., Ltd.">
<meta name="title" content="engMiwon Specialty Chemical Co., Ltd.">
<meta name="Keywords" content="Miwon, MSC, Miwon Specialty Chemical, Miwon North America, Miwon Europe, Miwon USA, Miwon Nantong, Miwon Guangzhou, Miwon Spain, Miwon Austria, MNA, MEU, MUS, MSP, MSI, MNT, MGU, MAU, miramer, photocryl, tmpta, hdda, tpgda, dpgda, monomer, oligomer, energy curing">
<meta name="description" content="Miwon Specialty Chemical Co., Ltd. is a global leading chemical company in Energy Curing industry, mainly producing monomers and oligomers.">
<meta name="copyright" content="Miwon Specialty Chemical Co., Ltd.">
<meta name="robots" content="Miwon Specialty Chemical Co., Ltd." />
<meta name="naver-site-verification" content="73a82b379de82e02877878959ddf039c01e388c0" />
<meta property="og:type" content="website">
<meta property="og:url" content="http://miwonsc.com/" />
<meta property="og:title" content="Miwon Specialty Chemical Co., Ltd.">
<meta property="og:description" content="Miwon Specialty Chemical Co., Ltd. is a global leading chemical company in Energy Curing industry, mainly producing monomers and oligomers.">

<title>Miwon Specialty Chemical Co., Ltd.</title>
<link rel="stylesheet" href="https://miwonsc.com/theme/basic/css/default.css?ver=210618&date=20250807202131">
<link rel="stylesheet" href="https://miwonsc.com/theme/basic/skin/latest/main_tab/style.css?ver=210618">
<link rel="stylesheet" href="https://miwonsc.com/theme/basic/css/design.css?date=20250807202131">
<link rel="stylesheet" href="https://miwonsc.com/theme/basic/css/animations.css?ver=210618&date=20250807202131">
<link rel="stylesheet" href="https://miwonsc.com/theme/basic/css/responsive.css?ver=210618&date=20250807202131">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link rel="stylesheet" href="https://miwonsc.com/theme/basic/css/animate.css?date=20250807202131">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />
<!--[if lte IE 8]>
<script src="https://miwonsc.com/js/html5.js"></script>
<![endif]-->
<style>

.fcolbg1 { padding-top:10px; }
.colbg1 { padding-bottom:20px; }
.colbg2 { background:#FCF7F2;padding-bottom:20px;padding-top:1px; }
.bg_sky { background:#F2F6FC; }
</style>
<script>
// 자바스크립트에서 사용하는 전역변수 선언
var g5_url       = "https://miwonsc.com";
var g5_bbs_url   = "https://miwonsc.com/bbs";
var g5_is_member = "";
var g5_is_admin  = "";
var g5_is_mobile = "";
var g5_bo_table  = "";
var g5_sca       = "";
var g5_editor    = "";
var g5_cookie_domain = "";
</script>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/jquery-migrate-1.4.1.min.js"></script>
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-MHG6HZJ9');</script>
<!-- End Google Tag Manager -->
<script src="https://miwonsc.com/js/jquery.menu.js?ver=210618"></script>
<script src="https://miwonsc.com/js/common.js?ver=210618"></script>
<script src="https://miwonsc.com/js/wrest.js?ver=210618"></script>
<script src="https://miwonsc.com/js/placeholders.min.js?ver=210618"></script>
<script src="https://miwonsc.com/js/jquery.bxslider.js?ver=210618"></script>
<script src="https://miwonsc.com/theme/basic/js/jquery.touchSlider.js?ver=210618"></script>
</head>
<body>
<script>
 $(function() {
	$("#search_mmth").on("click", function() {
        if($("#search_stx").val()=="") {

         alert("A search term is required.");
        } else {
         location.href='/bbs/search.php?lng=eng&stx='+$("#search_stx").val();
        }
		return false;
	});
	$("#search_mmth2").on("click", function() {
        if($("#search_stx2").val()=="") {
         alert("A search term is required.");
        } else {
         location.href='/bbs/search.php?lng=eng&stx='+$("#search_stx2").val();
        }
		return false;
	});
	$("#search_mmth3").on("click", function() {
        if($("#search_stx3").val()=="") {
         alert("A search term is required.");
        } else {
         location.href='/bbs/search.php?lng=eng&stx='+$("#search_stx3").val();
        }
		return false;
	});
	$("#search_mmth4").on("click", function() {
        if($("#search_stx4").val()=="") {
         alert("A search term is required.");
        } else {
         location.href='/bbs/search.php?lng=eng&stx='+$("#search_stx4").val();
        }
		return false;
	});
	$("#search_mmth5").on("click", function() {
        if($("#search_stx5").val()=="") {
         alert("A search term is required.");
        } else {
         location.href='/bbs/search.php?lng=eng&stx='+$("#search_stx5").val();
        }
		return false;
	});
    $('#search_stx').on("keydown", function(e) {
     if (e.keyCode == 13) {
        if($("#search_stx").val()=="") {
         alert("A search term is required.");
        } else {
         location.href='/bbs/search.php?lng=eng&stx='+$("#search_stx").val();
        }
     }
	});

    $('#search_stx2').on("keydown", function(e) {
     if (e.keyCode == 13) {
        if($("#search_stx2").val()=="") {
         alert("A search term is required.");
        } else {
         location.href='/bbs/search.php?lng=eng&stx='+$("#search_stx2").val();
        }
     }
	});

    $('#search_stx3').on("keydown", function(e) {
     if (e.keyCode == 13) {
        if($("#search_stx3").val()=="") {
         alert("A search term is required.");
        } else {
         location.href='/bbs/search.php?lng=eng&stx='+$("#search_stx3").val();
        }
     }
	});

    $('#search_stx4').on("keydown", function(e) {
     if (e.keyCode == 13) {
        if($("#search_stx4").val()=="") {
         alert("A search term is required.");
        } else {
         location.href='/bbs/search.php?lng=eng&stx='+$("#search_stx4").val();
        }
     }
	});


    $('#search_stx5').on("keydown", function(e) {
     if (e.keyCode == 13) {
        if($("#search_stx5").val()=="") {
         alert("A search term is required.");
        } else {
         location.href='/bbs/search.php?lng=eng&stx='+$("#search_stx5").val();
        }
     }
	});
});

</script>
<style>
.fulleshow { display:none;width:100%;max-width:1200px;top:100px;left:calc(50% - 590px);background:#fff;border:5px solid #f7f7f7;position:fixed;z-index:100000000000000 }
.fulleshow > .main { display:table;width:100%;max-width:1080px;margin:50px auto; }
.fulleshow > .main > .sli{ display:table;width:20%;vertical-align: middle;text-align:center;float:left; }
.fulleshow > .main > .sli > a { height:55px;display:table;text-align:center;font-size:1.2em;font-weight:600;width:calc(100% - 5px);color:#ffff;background:navy;padding-top:15px }
.fulleshow > .main > .sli > .head { width:100%;display:table; }
.fulleshow > .main > .sli > .head > li{ width:100%;font-size:1em;font-weight:normal;display:table;height:40px;text-align:left;padding:10px 0px 0px 5px }
.fulleshow > .main > .sli > .head > li > a:hover{ color:#2ab0b1 }


.search-box{
  transition: 0.4s;
  padding: 0px;
  width: 225px;
  height: 30px;
  margin-top:-5px;
  border: 1px solid rgba(255, 255, 255, 0);
}
.search-box:hover{
  border: 1px solid #dedede;
  height: 30px;
  border-radius: 30px;
  box-shadow: 0px 0px .5px 1px #dedede;
  width: 242px;
  margin-top:-5px;
}
.search-txt{
  display: none;
  padding: 0;
  width: 0px;
  height:0px
  border:0px;
  background: none;
  float: left;
  font-size: 1rem;
  line-height: 30px;
  transition: .4s;
  margin-left:20px;
}
.search-btn{
  text-decoration: none;
  float: right;
  width: 20px;
  height: 20px;
  border-radius: 50%;
  display: flex;
  justify-content: center;
  align-items: center;
  margin-right:5px;
  margin-top:2px;
}
.search-box:hover > .search-txt{
  display: flex;
  width: 175px;
  height: 30px;
  padding: 0 6px 3px;
  border:0px;
}


.search-txt2{
  display: none;
  padding: 0;
  width: 0px;
  height:0 px
  border:none;
  background: none;
  outline: none;
  float: left;
  font-size: 1rem;
  line-height: 30px;
  transition: .4s;
}
.search-box2:hover > .search-txt2{
  display: flex;
  width: 240px;
  height: 30px;
  padding: 0 6px;
}
.search-box3{
  transition: 0.4s;
  padding: 0px;
  width: 230px;
  height: 30px;
  margin-top:-5px;
  border: 1px solid rgba(255, 255, 255, 0);
}
.search-box3:hover{
  border: 1px solid #dedede;
  height: 30px;
  border-radius: 30px;
  box-shadow: 0px 0px .5px 1px #dedede;
  width: 242px;
  margin-top:-5px;
}
.search-txt3{
  display: none;
  padding: 0;
  width: 0px;
  height:0px
  border:0px;
  background: none;
  float: left;
  font-size: 1rem;
  line-height: 30px;
  transition: .4s;
  margin-left:20px;
}
.search-btn3{
  text-decoration: none;
  float: right;
  width: 20px;
  height: 20px;
  border-radius: 50%;
  display: flex;
  justify-content: center;
  align-items: center;
  margin-right:5px;
  margin-top:2px;
}
.search-box3:hover > .search-txt3{
  display: flex;
  width: 175px;
  height: 30px;
  padding: 0 6px 3px;
  border:0px;
}
.search-box5{
  transition: 0.4s;
  padding: 0px;
  width: 230px;
  height: 30px;
  margin-top:-5px;
  border: 1px solid rgba(255, 255, 255, 0);
}
.search-box5:hover{
  border: 1px solid #dedede;
  height: 30px;
  border-radius: 30px;
  box-shadow: 0px 0px .5px 1px #dedede;
  width: 242px;
  margin-top:-5px;
}
.search-txt5{
  display: none;
  padding: 0;
  width: 0px;
  height:0px
  border:0px;
  background: none;
  float: left;
  font-size: 1rem;
  line-height: 30px;
  transition: .4s;
  margin-left:20px;
}
.search-btn5{
  text-decoration: none;
  float: right;
  width: 20px;
  height: 20px;
  border-radius: 50%;
  display: flex;
  justify-content: center;
  align-items: center;
  margin-right:5px;
  margin-top:2px;
}
.search-box5:hover > .search-txt5{
  display: flex;
  width: 175px;
  height: 30px;
  padding: 0 6px 3px;
  border:0px;
}
#header #top_tnb {
    border-bottom: 0px;
}
#top_tnb { width:100%;height:30px;position:absolute;z-index:1000000 }
#top_tnb > ul { max-width:1200px;margin:0 auto;height:30px }
#top_tnb > ul > li { float:right;margin:5px; }

.dropdown {
  position: relative;
  display: inline-block;
}
.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 100px;
  color:#000;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}
.wait_content { width:100%;margin-top:100px;margin-bottom:200px;text-align:center;font-size:2em}
.wait_content .material-icons { font-size:3em }
.dropdown-content a {
  color: black;
  padding: 5px 5px;
  text-decoration: none;
  display: block;

}
.dropdown-content a:hover {background-color: #ddd;color:#000;}
.dropdown:hover .dropdown-content {display: block;}
.bload { color:#000 } 
#top_tnb > ul > li { margin-right:10px;}

@media (max-width:1080px) {
#header .subs_tab { display:none }
#header #top_tnb { display:none }
#footer { display:none }
.tl_latest_box_warp { display:none }
}

#top_tnb .material-icons { margin-top:4px;font-size:1rem }
.dropbtn .go_title { margin-left:5px;float:right }
.a4 .go_title { margin-left:5px;margin-top:1px;float:right }
    .small_title {
      border-bottom:2px solid #113387;
	  margin:0 auto;
	  width:150px;
	  font-weight:bold;
	}
    #event_ban  {
      width:100%;;
    }
    #event_ban .event_hip_pop {
      max-width:1180px;margin:0 auto;
    }
	#event_ban.event_ban_show{
	  transition: 0.4s;
	  width:100%;height:70px;
	}
	.event_ban_hide{
	  background:blue;width:100%;height:0px;
	}
    #event_close {
      background:blue;
    }
@media (max-width:1380px) {
    #event_ban {
      display:none;
    }
}

.onmobile_menu1 { width:250px;color:#000;float:left;padding-top:15px }
.onmobile_menu2 { width:calc(100% - 500px);float:left;padding-top:10px;text-align:center }
.onmobile_menu3 { width:250px;color:#000;float:left;padding-top:18px }
.onmobile_menu4 { display:none; }

@media (max-width:960px) {
 #event_ban  {
   display:none;
 }
.fulleshow { display:none;width:calc(100% - 40px);top:100px;left:20px;position:fixed;z-index:100000000000000 }
.fulleshow > .main > .sli{ display:table;width:50%;vertical-align: middle;text-align:center;float:left;padding:5px; }
.fulleshow > .main > .sli > a { height:55px;display:table;text-align:center;font-size:1.2em;font-weight:600;width:100%;color:#ffff;background:navy;padding-top:15px;margin-bottom:10px; }


}


@media (max-width:760px) {

.fulleshow { display:none;width:calc(100% - 40px);top:100px;left:20px;position:fixed;z-index:100000000000000 }
.fulleshow > .main > .sli{ display:table;width:100%;vertical-align: middle;text-align:center;float:normal; }
.fulleshow > .main > .sli > a { height:55px;display:table;text-align:center;font-size:1.2em;font-weight:600;width:100%;color:#ffff;background:navy;padding-top:15px;margin-bottom:10px; }
.fulleshow > .main > .sli > .head { display:none; }
.onmobile_menu3 { display:none; }

.onmobile_menu1 { width:100px;color:#000;float:left;padding-top:15px;cursor:normal }
.onmobile_menu2 { width:calc(100% - 200px);float:left;padding-top:10px;text-align:center }
.onmobile_menu4 { display:block;width:100px;color:#000;float:right;padding-top:15px;text-align:right }


.search-box{
  transition: 0.4s;
  padding: 0px;
  width: 185px;
  height: 30px;
  margin-top:-5px;
  border: 1px solid rgba(255, 255, 255, 0);
}
.search-box:hover{
  border: 1px solid #dedede;
  height: 30px;
  border-radius: 30px;
  box-shadow: 0px 0px .5px 1px #dedede;
  width: 202px;
  margin-top:-5px;
}
.search-txt{
  display: none;
  padding: 0;
  width: 0px;
  height:0px
  border:0px;
  background: none;
  float: left;
  font-size: 1rem;
  line-height: 30px;
  transition: .4s;
  margin-left:20px;
}
.search-btn{
  text-decoration: none;
  float: right;
  width: 20px;
  height: 20px;
  border-radius: 50%;
  display: flex;
  justify-content: center;
  align-items: center;
  margin-right:5px;
  margin-top:2px;
}
.search-box:hover > .search-txt{
  display: flex;
  width: 135px;
  height: 30px;
  padding: 0 6px 3px;
  border:0px;
}

.search-box3{
  transition: 0.4s;
  padding: 0px;
  width: 230px;
  height: 30px;
  margin-top:-5px;
  border: 1px solid rgba(255, 255, 255, 0);
}
.search-box3:hover{
  border: 1px solid #dedede;
  height: 30px;
  border-radius: 30px;
  box-shadow: 0px 0px .5px 1px #dedede;
  width: 242px;
  margin-top:-5px;
}
.search-txt3{
  display: none;
  padding: 0;
  width: 0px;
  height:0px
  border:0px;
  background: none;
  float: left;
  font-size: 1rem;
  line-height: 30px;
  transition: .4s;
  margin-left:20px;
}
.search-btn3{
  text-decoration: none;
  float: right;
  width: 20px;
  height: 20px;
  border-radius: 50%;
  display: flex;
  justify-content: center;
  align-items: center;
  margin-right:5px;
  margin-top:2px;
}
.search-box3:hover > .search-txt3{
  display: flex;
  width: 105px;
  height: 30px;
  padding: 0 6px 3px;
  border:0px;
}


.search-box5{
  transition: 0.4s;
  padding: 0px;
  width: 230px;
  height: 30px;
  margin-top:-5px;
  border: 1px solid rgba(255, 255, 255, 0);
}
.search-box5:hover{
  border: 1px solid #dedede;
  height: 30px;
  border-radius: 30px;
  box-shadow: 0px 0px .5px 1px #dedede;
  width: 242px;
  margin-top:-5px;
}
.search-txt5{
  display: none;
  padding: 0;
  width: 0px;
  height:0px
  border:0px;
  background: none;
  float: left;
  font-size: 1rem;
  line-height: 30px;
  transition: .4s;
  margin-left:20px;
}
.search-btn5{
  text-decoration: none;
  float: right;
  width: 20px;
  height: 20px;
  border-radius: 50%;
  display: flex;
  justify-content: center;
  align-items: center;
  margin-right:5px;
  margin-top:2px;
}
.search-box5:hover > .search-txt5{
  display: flex;
  width: 105px;
  height: 30px;
  padding: 0 6px 3px;
  border:0px;
}

}

</style>
<!-- 상단 시작 { -->
<header id="header">
    <div id="top_tnb">
        <ul>

            <li class='a4' style='margin-top:7px;'><a href="/eng/Bookmark.php"><span class="material-icons">star_border</span> <div class="go_title">Bookmark (0)</div></a></li>
            <li class='a' style='margin-top:7px;'><a>|</a></li>
            <li class='a3' style='margin-top:7px;'>
			    <div class="dropdown">
				  <a class="dropbtn"><span class="material-icons">language</span> <div class="go_title">ENG</div></a>
				  <div class="dropdown-content">
					<a href="/kor" style="color:#000">KOR</a>
					<a href="/chn" style="color:#000">CHN</a>
				  </div>
				</div>
			</li>
            <li class='a' style='margin-top:7px;'><a>|</a></li>
            <li class='a2' style='margin-top:7px;'><a href="/eng/Company/company.html">ABOUT US</a></li>
            <li class='a' style='margin-top:7px;'><a>|</a></li>
		    <li class="a1 search-box">
			  <input type="text" class="search-txt" name="search_stx" id="search_stx" placeholder="Search for a keyword">
			  <a id="search_mmth" class="search-btn" href="#">
				<span class="material-icons">search</span>
			  </a>
			</li>


        </ul>
     </div>
     <div class="ho_line"></div>
	 <div class="wrap gnb_down">
		
<!-- 팝업레이어 시작 { -->
<div id="hd_pop">
    <h2>팝업레이어 알림</h2>

<span class="sound_only">팝업레이어 알림이 없습니다.</span></div>

<script>
$(function() {
    $(".hd_pops_reject").click(function() {
        var id = $(this).attr('class').split(' ');
        var ck_name = id[1];
        var exp_time = parseInt(id[2]);
        $("#"+id[1]).css("display", "none");
        set_cookie(ck_name, 1, exp_time, g5_cookie_domain);
    });
    $('.hd_pops_close').click(function() {
        var idb = $(this).attr('class').split(' ');
        $('#'+idb[1]).css('display','none');
    });
    $("#hd").css("z-index", 1000);
});
</script>
<!-- } 팝업레이어 끝 -->		<h1><a href="/eng" title="메인으로">Miwon Specialty Chemical Co, Ltd.</a></h1>
                <style>
		#header .gnb .depth1 { float:left; padding:0px; position:relative;  }
        		#header .gnb .depth1 a{ padding-left:23px;padding-right:23px; }
		#header .gnb .depth1:last-child a{ padding-left:23px;padding-right:8px; }
                .ho_line { position: absolute;top:100px;display:none;clear:both;width:100%;height:1px;background:silver; }
        @media (max-width:760px) {
        .ho_line { height:0px; }
        #myTopnav #first_nav { display:none; }
        #myTopnav .dropdown_share { display:none; }
        #myTopnav ul li { width:100%;height:30px;text-align:right }
		#header .gnb { max-height:860px;position: fixed;overflow-y:auto; }
        }

        .ulo { animation: fadein 1s !important; }
		@keyframes fadein {
			from {
				opacity: 0;
			}
			to {
				opacity: 1;
			}
		}
		@-moz-keyframes fadein { /* Firefox */
			from {
				opacity: 0;
			}
			to {
				opacity: 1;
			}
		}
		@-webkit-keyframes fadein { /* Safari and Chrome */
			from {
				opacity: 0;
			}
			to {
				opacity: 1;
			}
		}
		@-o-keyframes fadein { /* Opera */
			from {
				opacity: 0;
			}
			to {
				opacity: 1;
			}
		}
        </style>
				<div id="" class="header_view mobile_only">
		  <div class="wrap" style="width:100%;max-width:1200px;margin:0 auto;">
			<div class='onmobile_menu1' id="onfull" onclick="javascript:load_mobile();"><span class="material-icons btn_gnbs">menu</span></div>
			<div class='onmobile_menu2'><A href='/eng'><img src="/img/mi_1.png?"></a></div>
			<div class='onmobile_menu3'><div class='search-box5' style="float:right"><input type="text" class="search-txt5" name="search_stx" id="search_stx5" placeholder="search for keyword"><a id="search_mmth5" class="search-btn5" href="#"><span class="material-icons" style="margin-top:2px;color:#000">search</span></a></div></div>
            <div class='onmobile_menu4'><span class="material-icons btn_gnbs" style="margin-top:2px">search</span></div>
		  </div>
		</div>



   	    <nav class="gnb">
			<ul>
                <li class="gnb_al_a_mobile" style="background:#f7f7f7;height:80px"><div><input type="text" name="search_stx" id="search_stx4" placeholder="Search for a keyword" style='border:1px solid silver;width:calc(100% - 60px);margin-right:10px;float:left'><a id="search_mmth4" style="border-radius: 30px;text-align:center;width:38px;height:30px;padding-top:5px;display:table;float:left;background:gray;color:#fff" href="#"><span class="material-icons" style="margin-top:2px;color:#000">search</span></a></div></li>
   
                <li class="depth1  case" id="tab1">
					<a href="/eng/Market/electronics.html" target="_self" class="gnb_al_a">Market & Application</a>             
					<div class='gnb_al_a_mobile' >Market & Application                                         <span class="material-symbols-outlined hipdown" style="float:right">expand_more</span>
                     <span class="material-symbols-outlined hipup" style="float:right">expand_less</span>
                                         <div class="ulo_hide">
			  <ol>
			   <dd class='head'><A style='color:#000' href='/eng/Market/electronics.html'>Electronics
</a></dd>
			   <!--A href='/eng/Market/electronics.html?#1'><dd>Display</dd></a>
			   <A href='/eng/Market/electronics.html?#2'><dd>PCB</dd></a-->
			  </ol>
			  <ol>
			   <dd class='head'><A style='color:#000' href='/eng/Market/graphic_arts.html'>Graphic arts
</a></dd>
			   <!--A href='/eng/Market/graphic_arts.html?#1'><dd>Flexible Packaging</dd></a>
			   <A href='/eng/Market/graphic_arts.html?#2'><dd>Inks</dd></a>
			   <A href='/eng/Market/graphic_arts.html?#3'><dd>OPV</dd></a-->
			  </ol>
			  <ol>
			   <dd class='head'><A style='color:#000' href='/eng/Market/Industrial_coating.html'>Industrial coating
</a></dd>
			   <!--a href='/eng/Market/Industrial_coating.html?#1'><dd>Automotive</dd></a>
			   <a href='/eng/Market/Industrial_coating.html?#2'><dd>Consumer Electronics</dd></a>
			   <a href='/eng/Market/Industrial_coating.html?#3'><dd>Flooring & Furniture</dd></a>
			   <a href='/eng/Market/Industrial_coating.html?#4'><dd>Industrial Metal</dd></a>
			   <a href='/eng/Market/Industrial_coating.html?#5'><dd>Mobile & Cosmetic Case</dd></a-->
			  </ol>
			  <ol>
			   <dd class='head'><A style='color:#000' href='/eng/Market/specialty.html'>Specialty
</a></dd>
			   <!--A href='/eng/Market/specialty.html?#1'><dd>3D Printing Resins</dd></a>
			   <A href='/eng/Market/specialty.html?#2'><dd>Adhesive</dd></a>
			   <A href='/eng/Market/specialty.html?#3'><dd>Cross-linking</dd></a>
			   <A href='/eng/Market/specialty.html?#4'><dd>Polymerization</dd></a-->
			  </ol>
		  

</div>
                    </div>             
                    
                                    </li>
                                <li class="depth1  case" id="tab2">
					<a href="/eng/Products/search.php" target="_self" class="gnb_al_a">Products</a>             
					<div class='gnb_al_a_mobile' >Products                                         <span class="material-symbols-outlined hipdown" style="float:right">expand_more</span>
                     <span class="material-symbols-outlined hipup" style="float:right">expand_less</span>
                                         <div class="ulo_hide">
		  <ol>
		   <dd class='head'><A style='color:#000' href='/eng/Products/search.php'>Product Finder</a></dd>
		   <!--A href='/eng/Products/search.php'><dd>By classification
</dd></a-->

		   <dd class='head'><A style='color:#000' href='/eng/Products/Monomer_1.html'>Monomer
</a></dd>
		   <!--A href='/eng/Products/Monomer_1.html'><dd>Acrylates</dd></a>
		   <A href='/eng/Products/Monomer_2.html'><dd>Methacrylates</dd></a-->
		  </ol>
          <ol>
		   <dd class='head'><A style='color:#000' href='/eng/Products/Oligomer_1.html'>Oligomer
</a></dd>
		   <!--A href='/eng/Products/Oligomer_1.html'><dd>Amine Acrylates</dd></a>
		   <A href='/eng/Products/Oligomer_2.html'><dd>Epoxy Acrylates</dd></a>
		   <A href='/eng/Products/Oligomer_3.html'><dd>Polyester Acrylates</dd></a>
		   <A href='/eng/Products/Oligomer_5.html'><dd>Specialty Acrylates</dd></a>
		   <A href='/eng/Products/Oligomer_4.html'><dd>Urethane Acrylates</dd></a-->
		  </ol>
          <ol>
		   <dd class='head'><A style='color:#000' href='/eng/Products/Others_1.html'>Others
</a></dd>
		   <!--A href='/eng/Products/Others_1.html'><dd>Benzoin</dd></a>
		   <A href='/eng/Products/Others_2.html'><dd>Epoxy Diluents</dd></a-->
		  </ol>
		 
</div>
                    </div>             
                    
                                    </li>
                                <li class="depth1  case" id="tab3">
					<a href="/bbs/board.php?bo_table=eng_news" target="_self" class="gnb_al_a">Info Center</a>             
					<div class='gnb_al_a_mobile' >Info Center                                         <span class="material-symbols-outlined hipdown" style="float:right">expand_more</span>
                     <span class="material-symbols-outlined hipup" style="float:right">expand_less</span>
                                         <div class="ulo_hide">	 
		  <ol>
		   <dd class='head'><A style='color:#000' href='/bbs/board.php?bo_table=eng_news'>Newsroom</a></dd>
		   <!--li><A href='/bbs/board.php?bo_table=eng_news'>News</a></dd>
		   <dd><A href='/bbs/board.php?bo_table=eng_event'>Events</a></li-->
		  </ol>
          <ol>
		   <dd class='head'>
<A style='color:#000' href='/bbs/board.php?bo_table=eng_Brochures&#topnav_go'>Resources</a></dd>
		   <!--li><A href='/bbs/board.php?bo_table=eng_Brochures&#topnav_go'>E-catalog/Certificates</a></dd>
		   <dd><A href='/bbs/board.php?bo_table=eng_Technical&#topnav_go'>Technical Literatures
</a></dd>
		   <dd><A href='/eng/Products/search.php'>Technical Data Sheets</a></dd>
		   <dd><A href='/eng/service/contact.html'>Safety Data Sheets</a></li-->
		  </ol>
          <ol>
		   <dd class='head'>
<A style='color:#000' href='/eng/Company/locations.html?#topnav_go'>Customer Experience</a></dd>
		   <!--li><A href='/eng/Company/locations.html?#topnav_go'>Global Locations
</a></dd>
		   <dd><A href='/eng/service/contact.html'>Contact Us</a></li-->
		  </ol>
		  
</div>
                    </div>             
                    
                                    </li>
                                <li class="depth1  case" id="tab4">
					<a href="/eng/Sustainability/Sustainability.html" target="_self" class="gnb_al_a">Sustainability</a>             
					<div class='gnb_al_a_mobile' >Sustainability                                         <span class="material-symbols-outlined hipdown" style="float:right">expand_more</span>
                     <span class="material-symbols-outlined hipup" style="float:right">expand_less</span>
                                         <div class="ulo_hide">	  	  <ol>
		   <dd class='head'><A style='color:#000' href='/eng/Sustainability/Sustainability.html'>Sustainability
</a></dd>
		  </ol>
          <ol>
		   <dd class='head'><A style='color:#000' href='/eng/Sustainability/environmental_protection.html'>Environmental Protection
</a></dd>
		  </ol>
          <ol>
		   <dd class='head'><A style='color:#000' href='/eng/Sustainability/energy.html'>Energy
</a></dd>
		  </ol>
		  <ol>
		   <dd class='head'><A style='color:#000' href='/eng/Sustainability/health_safety.html'>Safety and Health
</a></dd>
		  </ol>
          <ol>
		   <dd class='head'><A style='color:#000' href='/eng/Sustainability/SocialContribution.html'>CSR</a></dd>
		  </ol>
          <ol>
		   <dd class='head'><A style='color:#000' href='/eng/Sustainability/quality.html'>Quality
</a></dd>
		  </ol>
          <ol>
		   <dd class='head'><A style='color:#000' href='/eng/Sustainability/Compliance.html'>Compliance
</a></dd>
		  </ol>

</div>
                    </div>             
                    
                                    </li>
                                <li class="depth1  case" id="tab5">
					<a href="/eng/service/contact.html" target="_self" class="gnb_al_a">Contact</a>             
					<div class='gnb_al_a_mobile' onclick="location.href='/eng/service/contact.html';">Contact                                         <div class="ulo_hide">
</div>
                    </div>             
                    
                                    </li>
                
				

                    						<li class="depth1 case" style='background:#fffad7'>
							<div class='gnb_al_a_mobile' onclick="location.href='/eng/Company/company.html';">About us          
								  <div class="ulo_hide"></div>
							</div>        
						</li>
						<li class="depth1 case" style='background:#fffad7'>         
							<div class='gnb_al_a_mobile'>Language                                         
							 <span class="material-symbols-outlined hipdown" style="float:right">expand_more</span>
							 <span class="material-symbols-outlined hipup" style="float:right">expand_less</span>
							 <span class="hipdown" style="float:right;margin-right:15px;font-size:0.7em;padding-top:6px">
									ENG							 </span>
							 <div class="ulo_hide">
																  <ol>
								   <dd class='head'><A style='color:#000' href='/kor/'>KOR</a></dd>
								  </ol>
																  <ol>
								   <dd class='head'><A style='color:#000' href='/chn/'>CHN</a></dd>
								  </ol>
																 </div>
							</div>             
						</li>

			</ul>
            <ul class="ulo" style="margin-left:-430px;">
              <li id="ulo" style="color:#000"></li>
            </ul>
		</nav>
	</div>

</header>
 <style>

#header .gnb #tab1.depth1:hover > a:before { width:170px; }
#header .gnb #tab2.depth1:hover > a:before { width:75px; }
#header .gnb #tab3.depth1:hover > a:before { width:90px; }
#header .gnb #tab4.depth1:hover > a:before { width:110px; }
#header .gnb #tab5.depth1:hover > a:before { width:65px; }
#header .gnb #tab6.depth1:hover > a:before { width:90px; }
#header .gnb #tab7.depth1:hover > a:before { width:62px; }


#header .gnb #tab1.caseon > a:before { width:170px; }
#header .gnb #tab2.caseon > a:before { width:75px; }
#header .gnb #tab3.caseon > a:before { width:90px; }
#header .gnb #tab4.caseon > a:before { width:110px; }
#header .gnb #tab5.caseon > a:before { width:65px; }
#header .gnb #tab6.caseon > a:before { width:90px; }
#header .gnb #tab7.caseon > a:before { width:62px; }

.subs_tab .sub_box { display:table;margin:0 auto;width:100%;height:190px;}
.subs_tab .tab1s ul:first-child { margin-left:80px; }
.subs_tab .tab1s ul  { margin-right:30px; }
.subs_tab .tab2s ul:first-child { margin-left:290px; }
.subs_tab .tab2s ul  { margin-right:30px;; }
.subs_tab .tab2s ul:last-child  { margin-right:0px; }
.subs_tab .tab3s .unext { margin-left:100px; }
.subs_tab .tab3s ul  { margin-right:10px; }
.subs_tab .tab4s ul:first-child { margin-left:510px; }
.subs_tab .tab4s ul  { margin-right:20px; }
.subs_tab .sub_box ul {  float:left;  }
.subs_tab .sub_box ul li{ padding: 0px 0px 0px 10px;height:30px; }
.subs_tab .sub_box ul .head{ font-weight:600;font-size:1.2em;margin-bottom:10px;display:table;width:100%;height:45px;padding-top:10px; }
.subs_tab .sub_box ul .head_top{ font-weight:600;text-align:center;margin-bottom:10px;display:table;width:100%;height:45px }
.subs_tab .head_title { float:left;width:310px;display:table;font-weight:600;font-size:2em;border-right:1px solid silver;height:210px; }
.subs_tab .head_title  .big_title_1 { position:relative;top:155px;font-family: 'GmarketSansBold'; }
.subs_tab .head_title  .big_title_2 { position:relative;top:120px;font-family: 'GmarketSansBold'; }
.subs_tab .small_title_noline  { margin-top:10px;margin-bottom:20px;display:table;font-size:1.3em;width:300px;margin-left:92px;font-family: 'GmarketSansBold'; }
.subs_tab .head_content  { float:left;width:calc(100% - 310px);padding-left:50px;}
.subs_tab .sub_menu_4_for ul { margin-right:60px;float:left;  }
.subs_tab .head_content  { float:left;width:calc(100% - 310px);}
.subs_tab a:hover { color:#28AFB0 !important; }
#onfull { cursor:pointer }

#header_view { width:100%;position:fixed; z-index:100; color:#fff; transition:all .3s;height:60px;background:#fff;width:100%;border-bottom:1px solid silver; }
.header_view { position:fixed; left:0px; top:0px; z-index:100; color:#fff; transition:all .3s;height:60px;background:#fff;width:100%;border-bottom:1px solid silver; }

</style>
<div id="header_view">
  <div class="wrap" style="width:100%;max-width:1200px;margin:0 auto;">
			<div class='onmobile_menu1' id="onfull" onclick="javascript:load_mobile();"><span class="material-icons btn_gnbs">menu</span></div>
			<div class='onmobile_menu2'><A href='/eng'><img src="/img/mi_1.png?"></a></div>
			<div class='onmobile_menu3'><div class='search-box3' style="float:right"><input type="text" class="search-txt3" name="search_stx" id="search_stx3" placeholder="Search for a keyword"><a id="search_mmth3" class="search-btn3" href="#"><span class="material-icons" style="margin-top:2px;color:#000">search</span></a></div></div>
            <div class='onmobile_menu4'><span class="material-icons btn_gnbs" style="margin-top:2px">search</span></div>
  </div>
</div>
<div class='fulleshow'>
 <div style="float:right;font-weight:600;padding:10px;cursor:pointer" onclick="javascript:close_mobile()">Close X</div>
 <ul class='main'>
<li class='sli'><A href='/eng/Market/electronics.html'>Market & Application</a>
		<ul class='head'><li><A style='color:#000' href='/eng/Market/electronics.html'>Electronics
</a></li><li><A style='color:#000' href='/eng/Market/graphic_arts.html'>Graphic arts
</a></li><li><A style='color:#000' href='/eng/Market/Industrial_coating.html'>Industrial coating
</a></li><li><A style='color:#000' href='/eng/Market/specialty.html'>Specialty
</a></li></ul>
</li><li class='sli'><A href='/eng/Products/search.php'>Products</a>
		<ul class='head'><li><A style='color:#000' href='/eng/Products/search.php'>Product Finder</a></li><li><A style='color:#000' href='/eng/Products/Monomer_1.html'>Monomer
</a></li><li><A style='color:#000' href='/eng/Products/Oligomer_1.html'>Oligomer
</a></li><li><A style='color:#000' href='/eng/Products/Others_1.html'>Others
</a></li></ul>
</li><li class='sli'><A href='/bbs/board.php?bo_table=eng_news'>Info Center</a>
		<ul class='head'><li><A style='color:#000' href='/bbs/board.php?bo_table=eng_news'>Newsroom</a></li><li>
<A style='color:#000' href='/bbs/board.php?bo_table=eng_Brochures&#topnav_go'>Resources</a></li><li>
<A style='color:#000' href='/eng/Company/locations.html?#topnav_go'>Customer Experience</a></li></ul>
</li><li class='sli'><A href='/eng/Sustainability/Sustainability.html'>Sustainability</a>
		<ul class='head'><li><A style='color:#000' href='/eng/Sustainability/Sustainability.html'>Sustainability
</a></li><li><A style='color:#000' href='/eng/Sustainability/environmental_protection.html'>Environmental Protection
</a></li><li><A style='color:#000' href='/eng/Sustainability/energy.html'>Energy
</a></li><li><A style='color:#000' href='/eng/Sustainability/health_safety.html'>Safety and Health
</a></li><li><A style='color:#000' href='/eng/Sustainability/SocialContribution.html'>CSR</a></li><li><A style='color:#000' href='/eng/Sustainability/quality.html'>Quality
</a></li><li><A style='color:#000' href='/eng/Sustainability/Compliance.html'>Compliance
</a></li></ul>
</li><li class='sli'><A href='/eng/service/contact.html'>Contact</a>
		<ul class='head'><li></li><li></li><li></li><li></li><li></li><li></li></ul>
</li><li class='sli'><A href='/eng/Company/company.html'>ABOUT US</a>
		<ul class='head'><li><A style='color:#000' href='/eng/Company/company.html'>Company profile</a></li><li><A style='color:#000' href='/eng/Company/value.html'>What we believe</a></li><li><A style='color:#000' href='/eng/Company/point.html'>How we do</a></li><li><A style='color:#000' href='/eng/Company/history.html'>History</a></li><li><A style='color:#000' href='/eng/Company/locations.html'>Locations</a></li><li><A style='color:#000' href='/eng/Company/affiliated.html'>Affiliated companies</a></li></ul>
</li> </ul>
</div>
<script>
var isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry/i.test(navigator.userAgent) ? true : false;
function load_ajax(a) {
	$.ajax({
		url:'/include/menu.php',
		type:'post',
		data:{
				"on" : a,
				"lang" : "eng"
			},
			success: function(res) {
                //alert(res);
                loadtab_hide();
                $(".ulo").show();
                $(".ho_line").show();
				$("#"+a).addClass('caseon');
				$("#ulo").html(res);
			},
			error: function(err) {
				//alert("처리실패");
			}
			});

}

function loadtab_hide() {

    $("#tab1").removeClass('caseon');
	$("#tab2").removeClass('caseon');
	$("#tab3").removeClass('caseon');
	$("#tab4").removeClass('caseon');
	$("#tab5").removeClass('caseon');
	$("#tab6").removeClass('caseon');
	$("#tab7").removeClass('caseon');
	$("#tab8").removeClass('caseon');
	
}
function load_height() {
	$("#header.down").show(); 
	var width = $(window).width();
    if( width > 1200 ) {
	$("#header").css("height","100px");
    } else {
	$("#header").css("height","60px");
    }
}
function load_hide() {
	var width = $(window).width();
    if( width > 1200 ) {
	$("#header").css("height","100px");
    } else {
	$("#header").css("height","60px");
    }
	$("#header").removeClass('down');
	$('#header').removeClass('on');
	/*
	$("#bline_silver").hide();
    $("#tab1").hide();
	$("#tab2").hide();
	$("#tab3").hide();
	$("#tab4").hide();
	$("#tab5").hide();
	$("#tab6").hide();
	$("#tab7").hide();
	$("#tab8").hide();
    */
	
}
function load_hide_to() {
	var width = $(window).width();
    if( width > 1200 ) {
	$("#header").css("height","100px");
    } else {
	$("#header").css("height","60px");
    }
	$("#header").removeClass('down');
	/*
	$('#header').removeClass('on');
	$("#bline_silver").hide();
    $("#tab1").hide();
	$("#tab2").hide();
	$("#tab3").hide();
	$("#tab4").hide();
	$("#tab5").hide();
	$("#tab6").hide();
	$("#tab7").hide();
	$("#tab8").hide();
    */
	
}
function load_show(a,b) {
    //$(".ulo").hide();
	$("#header").addClass('down');
	$('#header').addClass('on');
    if(b=='n') {
    loadtab_hide();
    } else {
	$("#header").css("height","340px"); 
	load_ajax(a);
    }
    //$("#bline_silver").fadeIn();
	//$("#ulo").html(a);
}
function load_mobile() {
	var width = $(window).width();
    if( width > 1080 ) {
	$(".fulleshow").show();
    }
}
function close_mobile() {
	$(".fulleshow").hide();
}
$(function(){
        $("#header_view").hide();

	if(!isMobile){
		$("#tab1").on("mouseover", function(){
			load_hide();
			load_show('tab1');
		});
		$("#tab2").on("mouseover", function(){
			load_hide();
			load_show('tab2');
		});
		$("#tab3").on("mouseover", function(){
			load_hide();
			load_show('tab3');
		});
		$("#tab4").on("mouseover", function(){
			load_hide();
			load_show('tab4');
		});
		$("#tab5").on("mouseover", function(){
			$(".ulo").hide();
            loadtab_hide();
            load_hide();
		});
		$("#tab6").on("mouseover", function(){
			$(".ulo").hide();
            load_hide();
		});
		$("#tab7").on("mouseover", function(){
			$(".ulo").hide();
            load_hide();
            load_show('tab7','n');
		});
		$("#header").on("mouseover", function(){
			var width = $(window).width();
			$("#header.down").show(); 
			if( width > 1023 ) {
			$('#header').addClass('on');
			$("#header .user").addClass('on');
			$("#header .gnb_sub").addClass('on');
			} 
		});
		$("#header").on("mouseout", function(){
			$("#header .user").removeClass('on');
		});
		$("#header .btn_user").on("mouseover", function(){
			//alert(2);
			$('#header').addClass('on');
			$("#header .user").addClass('on');
		});
	};
	if(isMobile){
		$("#header .btn_user").on("click", function(){
			$("#header .user").toggleClass('on');
		});
	};
	$("#header .btn_gnb").on("click", function(){
		$("#header .user").removeClass('on');
		$(this).toggleClass('on');
		$("#header .gnb").toggleClass('on');
	});
	$("#header .btn_gnbs").on("click", function(){
		$("#header .user").removeClass('on');
		$(this).toggleClass('on');
		$("#header .gnb").toggleClass('on');
	});
/*
	$(window).scroll(function(){
		var top = $(window).scrollTop();
		var width = $(window).width();
        if( width > 1023 ) {
		if( top > 60 ){
			load_hide();
			$("#header").hide();
			$("#header_view").show();
			$("#header").css("height","60px");
			$('#header').addClass('on');
		}else{
			$("#header").show();
			$("#header_view").hide();
			$("#header").css("height","100px");
			$('#header').removeClass('on');
		}
        }
	});
*/
    $(function(){
      //Keep track of last scroll
      var lastScroll = 0;

      $(window).scroll(function(event){
          var st = $(this).scrollTop();
          var width = $(window).width();

          if( width > 1200 ) {
          //Sets the current scroll position
          

          //Determines up-or-down scrolling
		   $("#topnav").removeClass("sticky60");
		   $("#topnav").removeClass("sticky100");

          if (st > lastScroll){
             //Replace this with your function call for downward-scrolling
			load_hide();
			$("#header").hide();
			$("#header_view").show();
			$("#header").css("height","60px");
			$('#header').addClass('on');
			$("#topnav").addClass("sticky60");
            loadtab_hide();
            $(".ho_line").hide();
            $(".ulo").hide();
          }
          else {
          if(st < 200) {

			$("#header").removeClass('down');
			$("#header").css("height","100px");
			$("#header_view").hide();
			$("#header").show();
			$('#header').removeClass('on');
			$("#topnav").removeClass('sticky60');
			$("#topnav").removeClass('sticky100');
          } else { 
			$("#header").removeClass('down');
            //alert(width);
            if(width > 980) {
			$("#header").css("height","100px");
            $(".fulleshow").hide();
            } else {
 			$("#header").css("height","60px");
            } 
			$("#header_view").hide();
			$("#header").show();
			$('#header').addClass('on');
          }

          }
            if(width > 980) {
			$("#topnav").addClass("sticky100");
            $(".fulleshow").hide();
            } else {
			$("#topnav").addClass("sticky60");
            } 

          if(st < 101) {
           loadtab_hide();
           $(".ho_line").hide();
           $(".ulo").hide();
          }
          }
          //Updates scroll position
          lastScroll = st;
      });
    });
	$(window).scroll();
	$("#contents").on("mouseover", function(){
		var width = $(window).width();
        if( width > 1200 ) {
		load_hide_to();
        loadtab_hide();
        $(".ho_line").hide();
        $(".ulo").hide();
	    //$('#header').removeClass('on');
		//$('#header').addClass('on');
		//$("#header .user").addClass('on');
		//$("#header .gnb_sub").addClass('on');
        }

	});
	$("#sub_visual_big").on("mouseover", function(){
		var width = $(window).width();
        if( width > 1200 ) {
		load_hide();
        loadtab_hide();
        $(".ho_line").hide();
        $(".ulo").hide();
		//$('#header').addClass('on');
		//$("#header .user").addClass('on');
		//$("#header .gnb_sub").addClass('on');
        }
	});

	$("#event_close").on("click", function(){
		$("#event_ban").css("height","0px");
        var ck_name = 'event_ban';
        var exp_time = '24';
        set_cookie(ck_name, 1, exp_time, g5_cookie_domain);
	});

  

});
</script>
<!-- } 상단 끝 -->

	
<script>
$(document).ready(function(){
	$(window).scroll();

	$("#main_visual").on("mouseover", function(){
		var width = $(window).width();
        if( width > 1023 ) {
		load_hide();
        loadtab_hide();

        $(".ho_line").hide();
        $(".ulo").hide();
		//$('#header').addClass('on');
		//$("#header .user").addClass('on');
		//$("#header .gnb_sub").addClass('on');
        }
	});
 



	$('#main_visual .slider').bxSlider({
		mode: 'fade',
		fadeType:'zoom',
		auto: true,
		autoControls: true,
		stopAutoOnClick: false,
		speed: 800,
		pager: true,
		touchEnabled: true,
		pause: 8000
	});
});
</script>

<div id="main_visual">
	<div class="slider">
		<div class="roll" style="background-image:url(https://miwonsc.com/data/file/main_bg/thumb-2077641158_RVeUPgX1_3eb0fb09908a84480c2381ae32adeb0863432675_1920x1080.jpg) ">
			<div class="black"></div>
			<div class="container_box">
			<!-- <video src="http://test.islro.com/theme/a01/img/visual01.mp4" autoplay="autoplay" loop="loop" muted="muted"></video> -->
			<p class='gnormal'>Sustainability</p>
			<h2 class='glight'>For a Better<br>Tomorrow</h2>
			<A href='http://miwonsc.com/eng/Sustainability/Sustainability.html' target='_blank'><div class="READ_MORE gnormal" style="color:#fff">READ MORE <div class="material-icons">arrow_forward</div></div></a>
		    </div>
		</div>
		<div class="roll" style="background-image:url(https://miwonsc.com/data/file/main_bg/thumb-2077641158_ZNEzbufe_ec7b696ac567c144a2169923dc9dcce23bf8d900_1920x1080.jpg) ">
			<div class="black"></div>
			<div class="container_box">
			<!-- <video src="http://test.islro.com/theme/a01/img/visual01.mp4" autoplay="autoplay" loop="loop" muted="muted"></video> -->
			<p class='gnormal'>Product Finder</p>
			<h2 class='glight'>The Solution<br>In Energy Curing</h2>
			<A href='http://miwonsc.com/eng/Products/search.php' target='_blank'><div class="READ_MORE gnormal" style="color:#fff">EXPLORE MORE <div class="material-icons">arrow_forward</div></div></a>
		    </div>
		</div>
		<div class="roll" style="background-image:url(https://miwonsc.com/data/file/main_bg/thumb-2077641158_6Ky3v2GW_6077531a1fac71f458fcdeb3e36b5effc164ee77_1920x1080.jpg) ">
			<div class="black"></div>
			<div class="container_box">
			<!-- <video src="http://test.islro.com/theme/a01/img/visual01.mp4" autoplay="autoplay" loop="loop" muted="muted"></video> -->
			<p class='gnormal'>Your Experience</p>
			<h2 class='glight'>It’s All<br>That Matters</h2>
			<A href='http://miwonsc.com/eng/service/contact.html' target='_blank'><div class="READ_MORE gnormal" style="color:#fff">CONTACT US <div class="material-icons">arrow_forward</div></div></a>
		    </div>
		</div>


	</div>
</div>
<style>
.wrap_content { display:table;width:100%;height:calc(100vh - 60px); }
.wrap_content .content_box{ display:table;width:100%; max-width:1200px;margin:0 auto;text-align:center}
.cq_title { display:block;width:100%;float:left;font-size:3em;padding-bottom:30px; padding:80px 0px 80px 0px }
.cq_title strong{ font-weight:600; }
.cq_content { display:block;font-size:0.5em;margin-top:50px; }
.cq_img { display:block;float:right;text-align:right }
#sub_visual_com { height:100%; text-align:left; color:#fff; font-family:nanumsquare; position:relative; z-index:1 }
#sub_visual_com > #comtype { width:100%;max-width:1200px;  margin:0 auto; padding-top:200px;color:#000;display:table; }
#sub_visual_com > #comtype > .com_left { width:58%;float:left;display:table; }

#sub_visual_com > #comtype > .com_left > .video-container {
  position:relative;
  height:0;
  padding-bottom:56.25%;
}

#sub_visual_com > #comtype > .com_left > .video-container > iframe {
  position:absolute;
  top:0;
  left:0;
  width:100%;
  height:100%;
}

#sub_visual_com > #comtype > .com_right { width:37%;float:right;display:table; }
#sub_visual_com > #comtype > .com_right > h2 { font-size:2.45em;color:#000;line-height:130% }
#sub_visual_com > #comtype > .com_right > p { font-size:1.4em;color:#000;margin-top:40px }
#sub_visual_com > #comtype > .comg_full { clear:both;display:table;width:100%; }
#sub_visual_com > .com_full { width:100%;max-width:1200px;  margin:0 auto; text-align:center; padding-top:100px;color:#000;display:table; }
#sub_visual_com > .com_full > h2 { font-size:2.5em;color:#3d5630;line-height:130%;font-weight:600 }
#sub_visual_com > .com_full > p { font-size:2.8em;color:#3d5630;margin-top:10px;font-weight:600 }

@media (max-width:1200px) {
	#sub_visual_com > #comtype > .com_left { width:100%;padding:20px;float:normal }
	#sub_visual_com > #comtype > .com_right { width:100%;padding:20px;float:normal }
}
</style>
<section class="tl_latest_box_warp wrap_content" style="background:#ffffff;z-index:999">
<div class="content_box">
	<!--div class='cq_title'><strong>SUSTAINABLE PARTNER,<br>
	RELIABLE SUPPLIER</strong>
    <p class='cq_content'>We continuously provide infinite efforts to earn your trust and <br>
	persistently take on the challenge to let your success be possible</p>
    </div>
	<<div class='cq_img'>img src='/img/tree.png'</div>-->
<div id='sub_visual_com' class="sub10">
	<div id='comtype'>
      <div class='com_left'><div class="video-container"><iframe src="https://www.youtube-nocookie.com/embed/t4R5YPvSU9I?controls=0&autoplay=1" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe></div></div>
      <div class='com_right'><h2>SUSTAINABLE PARTNER,<br>RELIABLE SUPPLIER</h2><p>At Miwon, we continuously provide infinite efforts to earn your trust <br> and persistently take on challenges to enable your success</p></div>
	</div>
    <!--div class='com_full'><h2 class='gnormal'>지속가능한 성장과 고객경험을 위한</h2>
<p class='gbold'>FOR A BETTER TOMORROW</p></div-->
</div>
</div>
</section>
<style>
/*
	 .responsive_ban1 { background-image:url('http://msc2022.jhost.co.kr/img/437213_grs.png'); background-repeat: no-repeat;  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;width:30%;float:left;height:470px;border-right:1px solid #dfdfdf;padding-top:40px;padding-bottom:40px; }
*/
	 .responsive_ban1 { width:30%;float:left;height:500px;border-right:1px solid #dfdfdf;padding-top:40px;padding-bottom:40px; }

	 .responsive_ban2 { width:70%;margin-left:30%;padding-top:40px; }



	 .main_card  {
		 margin-right:40px;
		 margin-top:10px;
	 }
	 .main_card a { text-decoration: none; color: inherit; } 

	 .main_card > li { 	 font-size: 1.4em; line-height: 50px;text-align:right;cursor:pointer }
	 .main_card > li > a { display: inline-block; position: relative; }
	 .main_card > li > a:after { content:""; position: absolute; left: 50%; bottom: 0; width: 0; height: 4px; background-color: aqua; transition: all .5s; }
	 .main_card > li > a:before { content:""; position: absolute; right: 50%; bottom: 0; width: 0; height: 4px; background-color: aqua; transition: all .5s; }
	 .main_card > li > a:hover { font-weight:bold }
	 .main_card > li > a:hover:after { width: 50% }
	 .main_card > li > a:hover:before { width: 50%; }

	 .main_card .actives { font-weight:bold }

     .card_news { margin-top:40px;}

     .card_news img { width:280px;height:157.5px; }

     .card_news > li { 
         height:320px;
		 float:left;
		 margin:20px 20px 20px 20px;
		 display: inline-block;
		 position: relative;
		 width: 100%;
		 max-width: 280px;
		 vertical-align: top;
		 text-align: left;
		 max-height: 594px;
		 white-space: normal;
		 border: 1px solid #ebebeb;
		 cursor:pointer;
		 box-shadow: 0 5px 29px rgb(0 0 0 / 8%);
		 transition: all 250ms cubic-bezier(.02, .01, .47, 1);
	 }


     .card_news > li:hover { 
		 box-shadow: 0 10px 40px rgb(0 0 0 / 25%);
		 transition: all 250ms cubic-bezier(.02, .01, .47, 1);
	 }



     .card_news > li > .card_title { 
		 color:#a10909;
		 width:100%;
		 padding:8px 5px 0px 10px;
		 font-weight:bold
	 }
	 /*
     .card_news > li > .card_title_color1 { 
	     background:#2d7bc3;
	 }
     .card_news > li > .card_title_color2 { 
	     background:#d66f41;
	 }
     .card_news > li > .card_title_color3 { 
	     background:#ee325e;
	 }
*/
     .card_news > li > .card_content { 
	    padding:10px 10px 0px 10px;
	 }
     .card_news > li > .card_small_content { 
	    padding:0px 10px 10px 10px;color:silver
	 }

	 
	 @media screen and (max-width:900px) {
	 .responsive_ban1 { width:100%;}
	 .responsive_ban2 { width:100%; }
	 .index_responsive_ban  { height:350px;float:normal }
  	 }

	@-webkit-keyframes uparrow {
	  0% { -webkit-transform: translateY(0); opacity: 0.4 }
	  100% { -webkit-transform: translateY(-0.4em); opacity: 0.9 }
	}
	@-webkit-keyframes downarrow {
	  0% { -webkit-transform: translateY(0); opacity: 0.4 }
	  100% { -webkit-transform: translateY(0.4em); opacity: 0.9 }
	}

	.contact .container {
	  top:0;
	  bottom:0;
	  left:0;
	  right:0;
	}
	.contact .arrow {
	  border-color:transparent;
	  border-style:solid;
	  border-width:0 1em;
	  display:block;
	  height:0;
	  margin:0 auto;
	  opacity:0.4;
	  text-indent:-9999px;
	  transform-origin: 50% 50%;
	  width:0;
	}
	.contact .up {
	  -webkit-animation: uparrow 0.6s infinite alternate ease-in-out;
	  border-bottom:1em solid #00b6f1;
	}
	.contact .down {
	  -webkit-animation: downarrow 0.6s infinite alternate ease-in-out;
	  border-top:1em solid #00b6f1;
	}

    .small_txt {
      font-size:1rem;
	  padding:10px;
	}
	.small_title_bar {
      font-size:2.5rem;
	  font-weight:600;
	  background: linear-gradient(to left, #292929, #747474);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
	  padding:10px;
	  display:inline-block
	}

      .tmap_notice_line { font-weight:600;width:100%;text-align:center;border-bottom:1px solid #e9e9e9;padding-top:30px;}
      .tmap_notice_title { font-weight:600;width:100%;text-align:center;padding-top:30px;}
      .tmap_notice_title .tltle { font-weight:600;font-size:2rem;margin:0 auto;background:#fff}

	 .so_small  { padding-top:60px }
     .so_news { padding-left:30px;padding-top:30px; }
	 @media screen and (max-width:900px) {
	 .so_small  { height:200px;float:normal;padding-top:20px  }
     .so_news { padding-left:10px;padding-top:0px;background:#f7f7f7;width:100%;overflow-x:auto;overflow-y:hidden;height:400px; }
	 .responsive_ban2 { width:100%;margin-left:0%;padding-top:0px; }

     .card_news { margin-top:0px; width:100%;min-width:960px; height:400px; overflow-x:auto;overflow-y:hidden; }
     .card_news img { width:280px;height:157.5px; }
     .tmap_notice_title .tltle { font-size:2em }
     .card_news > li { 
         height:320px;
		 float:left;
		 margin:20px 20px 20px 20px;
		 display: inline-block;
		 position: relative;
		 width: 100%;
		 max-width: 280px;
		 vertical-align: top;
		 text-align: left;
		 max-height: 594px;
		 white-space: normal;
		 border: 1px solid #ebebeb;
		 cursor:pointer;
		 box-shadow: 0 5px 29px rgb(0 0 0 / 8%);
		 transition: all 250ms cubic-bezier(.02, .01, .47, 1);
	 }

  	 }
</style>
		<!-- start complany section -->
<!----//메인상단과 퀵메뉴 스크립트 
<section class="tl_latest_box_warp" style='border-top:1px solid #dfdfdf'>--->
<section class="">
            <div class="container-fluid p-0">
					<div class='tmap_notice_title'><span class='tltle'>Our Latest News & Events </span></div>
				    <div class='tmap_notice_line'></div>

                    <div class="xs_hide index_responsive_ban responsive_ban1 col-12 col-lg-6 position-relative md-height-550px sm-height-350px cover-background wow slideInLeft so_small" data-wow-duration="900ms">
						<ul class="main_card">
						 <li id='news1' class="actives"><a>News</a></li>
						 <li id='news2'><a>Innovation</a></li>
						 <li id='news3'><a>Events</a></li>
                        </ul> 
                    </div>
                    <div class="index_responsive_ban responsive_ban2 col-12 col-lg-6 padding-seven-tb padding-eight-lr md-padding-nine-tb md-padding-twelve-lr sm-padding-30px-tb sm-padding-50px-lr text-center text-lg-left wow slideInRight last-paragraph-no-margin main_load_photo1 so_news" data-wow-duration="900ms" id="eff-4s">
						<ul class="card_news news1">
						  

    						 <li onclick="location.href='https://miwonsc.com/bbs/board.php?bo_table=eng_news&amp;wr_id=120'"><img src="https://miwonsc.com/data/file/eng_news/thumb-2077641158_7iKsMNAd_1825a277abdb2b19172d8b7b1fcaeef6f7715461_297x212.png?wd=0" alt="" >						 <div class='card_title card_title_color1'>Press Release</div><div class='card_content'>Miwon Specialty Chemicals Announces Major U.S. Facility Expa…</div><div class='card_small_content' style="overflow:hidden">As the global leader in energy-curing technology, Miwon Specialty Chemicals is proud to announce ano…</div></li>

    						 <li onclick="location.href='https://miwonsc.com/bbs/board.php?bo_table=eng_news&amp;wr_id=109'"><img src="https://miwonsc.com/data/editor/2501/thumb-342b1a89e06f0db170119beda8aab0bf_1737588092_5852_297x212.jpg?wd=1" alt="" >						 <div class='card_title card_title_color1'>Sustainability</div><div class='card_content'>Awarded Jeonbuk Governor's Award for Energy Efficiency</div><div class='card_small_content' style="overflow:hidden">Miwon Specialty Chemical’s Hyo Sang Kim recognized with Jeonbuk Governor's Award for contributions t…</div></li>

    						 <li onclick="location.href='https://miwonsc.com/bbs/board.php?bo_table=eng_news&amp;wr_id=108'"><img src="https://miwonsc.com/data/editor/2412/thumb-195ae075d07ee654b223fc6bda0be78e_1734332752_9901_297x212.png?wd=2" alt="" >						 <div class='card_title card_title_color1'>CSR</div><div class='card_content'>Charity Bazaar Held at Gwanggyo Center to Support the Korean…</div><div class='card_small_content' style="overflow:hidden">Giving Tradition and Charity Bazaar for Sharing</div></li>

                            </ul> 
						<ul class="card_news news2">
						  

    						 <li onclick="location.href='https://miwonsc.com/bbs/board.php?bo_table=eng_news&amp;wr_id=121'"><img src="https://miwonsc.com/data/file/eng_news/thumb-2077641158_1uFs40fP_844aecb63af0f30c2d8a3a8a151f4aa79a8e3d4a_297x212.jpg?wd=0" alt="" >						 <div class='card_title card_title_color1'>Products</div><div class='card_content'>MIRAMER® CEA</div><div class='card_small_content' style="overflow:hidden">High-Performance Functional Acrylate for Enhanced Adhesion and Flexibility</div></li>

    						 <li onclick="location.href='https://miwonsc.com/bbs/board.php?bo_table=eng_news&amp;wr_id=119'"><img src="https://miwonsc.com/img/no_img.png?wd=1" alt="이미지가 없습니다." >						 <div class='card_title card_title_color1'>Insights</div><div class='card_content'>A Day in the Life of Miwon Specialty Chemical’s Quality Cont…</div><div class='card_small_content' style="overflow:hidden"></div></li>

    						 <li onclick="location.href='https://miwonsc.com/bbs/board.php?bo_table=eng_news&amp;wr_id=118'"><img src="https://miwonsc.com/data/file/eng_news/thumb-2077641158_Yz1wRtVj_a0f97993fd5a9efd0c20a4cf9eef7ddfb161ece2_297x212.jpg?wd=2" alt="" >						 <div class='card_title card_title_color1'>Products</div><div class='card_content'>[ASIA] High Hardness Urethane Acrylate</div><div class='card_small_content' style="overflow:hidden">Introduction to High-Hardness Urethane Acrylate Grades</div></li>

                            </ul> 
						<ul class="card_news news3">
						  

    						 <li onclick="location.href='https://miwonsc.com/bbs/board.php?bo_table=eng_event&amp;wr_id=33'"><img src="https://miwonsc.com/data/file/eng_event/thumb-2077641158_9B0Dg13h_15b190856ded72557c810ea339194af69ea5eec3_297x212.png?wd=0" alt="" >						 <div class='card_title card_title_color1'>Exhibitions</div><div class='card_content'>Join Miwon at RADTECH 2025</div><div class='card_small_content' style="overflow:hidden">MSC and MNA will be attending RADTECH 2025 from May 18-21, 2025.</div></li>

    						 <li onclick="location.href='https://miwonsc.com/bbs/board.php?bo_table=eng_event&amp;wr_id=32'"><img src="https://miwonsc.com/data/file/eng_event/thumb-2077641158_0nVfcITt_b3a37c67c7ba8753530cf3361e31c907972dc647_297x212.jpg?wd=1" alt="" >						 <div class='card_title card_title_color1'>Exhibitions</div><div class='card_content'>Join Miwon at ECS 2025</div><div class='card_small_content' style="overflow:hidden">MSC and MEU will be attending ECS 2025 from Mar. 25-27, 2025.</div></li>

    						 <li onclick="location.href='https://miwonsc.com/bbs/board.php?bo_table=eng_event&amp;wr_id=31'"><img src="https://miwonsc.com/data/editor/2405/thumb-73a9065a6930a0554ca780b498889b65_1715676070_5601_297x212.png?wd=2" alt="" >						 <div class='card_title card_title_color1'>Exhibitions</div><div class='card_content'>Join Miwon at RADTECH 2024</div><div class='card_small_content' style="overflow:hidden">MSC and MNA will be attending RADTECH 2024 from May 20-22, 2024.</div></li>

                            </ul> 
                    </div>     
            </div>
</section>
<style>
	.container-carres {
		  height:350px;
		  width:100%;
		  font-family: nanumsquare;
		  text-align:center;
		  color:#fff;
		  overflow:hidden;
		  display:table;
	}

	.container-carres .responsive_carees {
			display: inline-block;
			background-color: white;
			background-image: url('https://miwonsc.com/data/file/sub_07/2084080241_R1dDyl2N_9632a4a44658a90ab149e62c68309011fd1ec99b.png');
			background-size: cover;
			background-repeat: no-repeat;
			background-position: center top;
        
         -webkit-transition: transform .3s ease-out; 
         -moz-transition: transform .3s ease-out; 
         -ms-transition: transform .3s ease-out;
         -o-transition: transform .3s ease-out; 
         transition: transform .3s ease-out;    


		  height:350px;
		  width:100%;
		  font-family: nanumsquare;
		  text-align:center;
		  color:#fff;
	}

	 .container-carres .responsive_carees:hover {	  
        -webkit-transform: scale(1.1);
        -moz-transform: scale(1.1);
        -ms-transform: scale(1.1); /* IE 9 */
        -o-transform: scale(1.1);
        transform: scale(1.1);
        -ms-filter: "progid:DXImageTransform.Microsoft.Matrix(M11=1.1, M12=0, M21=0, M22=1.1, SizingMethod='auto expand')"; /* IE8 */
        filter: progid:DXImageTransform.Microsoft.Matrix(M11=1.1, M12=0, M21=0, M22=1.1, SizingMethod='auto expand'); /* IE6 and 7 */ 

		
	   }
      .container-carres .responsive_carees_txt {
	    position:relative;
		margin:0 auto;
		width:420px;
		text-align:center;
	  }
      .container-carres .responsive_carees_but {
	    position:relative;
		margin:0 auto;
		width:180px;
		text-align:center;
	  }

	  .container-carres .responsive_carees_txt h1{ 
		width:420px;
		text-align:center;
	    position:absolute;
		top:-270px;
        font-size:2rem;
		font-weight:normal;
		line-height: 1.4;
		animation: down .5s 0.8s forwards;
		opacity: 0;
	  }
	  
	  .container-carres .responsive_carees_txt h3{ 
		width:420px;
		text-align:center;
	    position:absolute;
		top:-220px;
	    font-size:3.5rem;  
	    background: linear-gradient(to left, #fffbe9, #ffff);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
		line-height: 1;
		animation: left .5s 1.2s forwards;
		text-shadow: 0 10px 40px rgb(0 0 0 / 70%);
		opacity: 0;
	    font-weight:600;
	  }
	  
	  .container-carres .responsive_carees_but .spb{ 
		width:180px;
		text-align:center;
	    position:absolute;
		top:-120px;
	    font-size:1.1rem;  
		line-height: 1;
	    background: #A50034;
        padding:10px 30px 10px 30px;
		animation: left .5s 1.2s forwards;
		text-shadow: 0 10px 40px rgb(0 0 0 / 70%);
		opacity: 0;
	    font-weight:600;
        cursor:pointer;
        color:#fff
	  }
</style>
<!----//메인상단과 퀵메뉴 스크립트 --->
<section class="tl_latest_box_warp">
            <div class="container-carres">
			  <div class="responsive_carees">
			  </div>  
			  <div class="responsive_carees_txt">
              <h1>Careers</h1>			  
<h3>Miwon & You</h3>			  </div> 
              <A href='/kor/Careers/Human.html'>
			  <div class="responsive_carees_but">
              <div class='spb'>Explore more</div>
			  </div> 
              </a>

			</div>
</section>

<div style="background:#ebebeb;padding:50px;font-size:2em" class="contact">
	<div class="container_box"><p class="small_title_bar">How Can We Help?</p><div class="small_txt">Questions? Concerns? Feedback? Let us know, we're here to help.</div></div>
	<div class="container_box">
<style>
    .small_txt {
      font-size:1rem;
	  padding:10px;
	}
	.small_title_bar {
      font-size:2.5rem;
	  font-weight:600;
	  background: linear-gradient(to left, #292929, #747474);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
	  padding:10px;
	  display:inline-block
	}
.container_box { width:100%;max-width:1200px;margin:0 auto }
.container_box .select-style select, .container_box .select-style input {
    width: 100%;
    background-color: transparent;
    background-image: none;
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    cursor: pointer;
	font-size:0.9rem;
	background:#f9f9f9;
}

.container_box textarea{
	font-size:0.9rem;
}

.container_box .col_text {
	font-size:0.9rem;
	background:#3fb0ff;
	color:#fff
}

.container_box .col_text_no {
	font-size:0.9rem;
	background:#c3c3c3;
	color:#fff
}

.container_box button, select, input {
    text-transform: none;
	height:50px;
}


.container_box input {
    text-transform: none;
	height:50px;
}

.container_box button, input, optgroup, select, textarea {
    margin: 0;
    font-family: inherit;
    font-size: inherit;
    line-height: inherit;
}
.container_box .small_td {
    width:33.3%;
	float:left;
	padding:10px;
}
.container_box .big_td {
    width:50%;
	float:left;
	padding:10px;
}
.container_box .big_td_full {
    width:100%;
	padding:10px
}
.container_box .fx_Value{
    font-size: 0.6em;
}
.container_box .fx_Value > span{
    font-weight:bold;
	color:#f54f15
}
.pc_none { display:none }
.news2, .news3, .news4, .news5, .news6 { display:none }

.select-step{
  position: relative;
  display: inline-block;
  margin-bottom: 15px;
  width :100%;

}

.select-step select{
  display:inline-block;
  width:100%;
  padding:10px 15px;
  appearance:none;
  -webkit-appearance:none;
  -moz-appearance:none;
}

.select-step select::-ms-expand{
  display:none;
}

	.select__arrow{
	  position: absolute;
	  top :22px;
	  right: 15px;
	  width :0;
	  height :0;
	  pointer-events: none;
	  border-style :solid;
	  border-width: 8px 5px 0 5px;
	  border-color: #999 transparent transparent transparent;
	}
	.tcenter { text-align:center }
</style>
                   <form name="q_post_content" onsubmit="return contactr_submit(this);" method="post">
		           <input type=hidden name='page' value='/eng/index.php'>
		           <input type=hidden name='lang' value='eng'>
                   <div class="row">
                        <div class="big_td_full">
                            <textarea name="comment" id="comment_wrkey" placeholder="Please specify the name of the product, chemicals, or documents you need when you enter your message here *" rows="6" class="big-textarea required"></textarea><p style='font-size:0.85rem;margin-top:10px'>Notice: If you are located in the United States, please let us know which state you live in so that your inquiry can be processed quickly as possible.</p>
                        </div>
				   </div>
            
                   <div class="row pc_none" id="kw_use">

                        <div class="small_td">
                            <div class="select-step select-style big-select">
                                <select name="location" id="Region" class="bg-transparent mb-0" required>
                                    <option value="">Select Your Location</option>
									<option value='Afghanistan@@miramer@miwonsc.com'>Afghanistan</option><option value='Albania@@miramer@miwonsc.com'>Albania</option><option value='Algeria@@miramer@miwonsc.com'>Algeria</option><option value='Angola@@miramer@miwonsc.com'>Angola</option><option value='Argentina@@miramer@miwonsc.com'>Argentina</option><option value='Armenia@@miramer@miwonsc.com'>Armenia</option><option value='Aruba@@miramer@miwonsc.com'>Aruba</option><option value='Australia@@miramer@miwonsc.com'>Australia</option><option value='Austria@@miramer@miwonsc.com'>Austria</option><option value='Azerbaijan@@miramer@miwonsc.com'>Azerbaijan</option><option value='Bahamas@@miramer@miwonsc.com'>Bahamas</option><option value='Bahrain@@miramer@miwonsc.com'>Bahrain</option><option value='Bangladesh@@miramer@miwonsc.com'>Bangladesh</option><option value='Barbados@@miramer@miwonsc.com'>Barbados</option><option value='Belarus@@miramer@miwonsc.com'>Belarus</option><option value='Belgium@@miramer@miwonsc.com'>Belgium</option><option value='Belize@@miramer@miwonsc.com'>Belize</option><option value='Benin@@miramer@miwonsc.com'>Benin</option><option value='Bhutan@@miramer@miwonsc.com'>Bhutan</option><option value='Bolivia (Plurinational State of)@@miramer@miwonsc.com'>Bolivia (Plurinational State of)</option><option value='Bosnia and Herzegovina@@miramer@miwonsc.com'>Bosnia and Herzegovina</option><option value='Botswana@@miramer@miwonsc.com'>Botswana</option><option value='Brazil@@miramer@miwonsc.com'>Brazil</option><option value='Brunei Darussalam@@miramer@miwonsc.com'>Brunei Darussalam</option><option value='Bulgaria@@miramer@miwonsc.com'>Bulgaria</option><option value='Burkina Faso@@miramer@miwonsc.com'>Burkina Faso</option><option value='Burundi@@miramer@miwonsc.com'>Burundi</option><option value='Cambodia@@miramer@miwonsc.com'>Cambodia</option><option value='Cameroon@@miramer@miwonsc.com'>Cameroon</option><option value='Canada@@miramer@miwonsc.com'>Canada</option><option value='Cape Verde@@miramer@miwonsc.com'>Cape Verde</option><option value='Central African Republic@@miramer@miwonsc.com'>Central African Republic</option><option value='Chad@@miramer@miwonsc.com'>Chad</option><option value='Channel Islands@@miramer@miwonsc.com'>Channel Islands</option><option value='Chile@@miramer@miwonsc.com'>Chile</option><option value='China@@miramer@miwonsc.com'>China</option><option value='China, Hong Kong@@miramer@miwonsc.com'>China, Hong Kong</option><option value='China, Macao@@miramer@miwonsc.com'>China, Macao</option><option value='China, Taiwan@@miramer@miwonsc.com'>China, Taiwan</option><option value='Colombia@@miramer@miwonsc.com'>Colombia</option><option value='Comoros@@miramer@miwonsc.com'>Comoros</option><option value='Congo (Congo-Brazzaville)@@miramer@miwonsc.com'>Congo (Congo-Brazzaville)</option><option value='Congo (Democratic Republic of the)@@miramer@miwonsc.com'>Congo (Democratic Republic of the)</option><option value='Costa Rica@@miramer@miwonsc.com'>Costa Rica</option><option value='Côte d`Ivoire@@miramer@miwonsc.com'>Côte d`Ivoire</option><option value='Croatia@@miramer@miwonsc.com'>Croatia</option><option value='Cuba@@miramer@miwonsc.com'>Cuba</option><option value='Cyprus@@miramer@miwonsc.com'>Cyprus</option><option value='Czech Republic@@miramer@miwonsc.com'>Czech Republic</option><option value='Denmark@@miramer@miwonsc.com'>Denmark</option><option value='Djibouti@@miramer@miwonsc.com'>Djibouti</option><option value='Dominican Republic@@miramer@miwonsc.com'>Dominican Republic</option><option value='Ecuador@@miramer@miwonsc.com'>Ecuador</option><option value='Egypt@@miramer@miwonsc.com'>Egypt</option><option value='El Salvador@@miramer@miwonsc.com'>El Salvador</option><option value='Equatorial Guinea@@miramer@miwonsc.com'>Equatorial Guinea</option><option value='Eritrea@@miramer@miwonsc.com'>Eritrea</option><option value='Estonia@@miramer@miwonsc.com'>Estonia</option><option value='Ethiopia@@miramer@miwonsc.com'>Ethiopia</option><option value='Fiji@@miramer@miwonsc.com'>Fiji</option><option value='Finland@@miramer@miwonsc.com'>Finland</option><option value='France@@miramer@miwonsc.com'>France</option><option value='French Guiana@@miramer@miwonsc.com'>French Guiana</option><option value='French Polynesia@@miramer@miwonsc.com'>French Polynesia</option><option value='Gabon@@miramer@miwonsc.com'>Gabon</option><option value='Gambia@@miramer@miwonsc.com'>Gambia</option><option value='Georgia@@miramer@miwonsc.com'>Georgia</option><option value='Germany@@miramer@miwonsc.com'>Germany</option><option value='Ghana@@miramer@miwonsc.com'>Ghana</option><option value='Greece@@miramer@miwonsc.com'>Greece</option><option value='Grenada@@miramer@miwonsc.com'>Grenada</option><option value='Guadeloupe@@miramer@miwonsc.com'>Guadeloupe</option><option value='Guam@@miramer@miwonsc.com'>Guam</option><option value='Guatemala@@miramer@miwonsc.com'>Guatemala</option><option value='Guinea@@miramer@miwonsc.com'>Guinea</option><option value='Guinea-Bissau@@miramer@miwonsc.com'>Guinea-Bissau</option><option value='Guyana@@miramer@miwonsc.com'>Guyana</option><option value='Haiti@@miramer@miwonsc.com'>Haiti</option><option value='Honduras@@miramer@miwonsc.com'>Honduras</option><option value='Hungary@@miramer@miwonsc.com'>Hungary</option><option value='Iceland@@miramer@miwonsc.com'>Iceland</option><option value='India@@miramer@miwonsc.com'>India</option><option value='Indonesia@@miramer@miwonsc.com'>Indonesia</option><option value='Iran (Islamic Republic of)@@miramer@miwonsc.com'>Iran (Islamic Republic of)</option><option value='Iraq@@miramer@miwonsc.com'>Iraq</option><option value='Ireland@@miramer@miwonsc.com'>Ireland</option><option value='Israel@@miramer@miwonsc.com'>Israel</option><option value='Italy@@miramer@miwonsc.com'>Italy</option><option value='Jamaica@@miramer@miwonsc.com'>Jamaica</option><option value='Japan@@miramer@miwonsc.com'>Japan</option><option value='Jordan@@miramer@miwonsc.com'>Jordan</option><option value='Kazakhstan@@miramer@miwonsc.com'>Kazakhstan</option><option value='Kenya@@miramer@miwonsc.com'>Kenya</option><option value='Korea (Democratic People`s Republic of)@@miramer@miwonsc.com'>Korea (Democratic People`s Republic of)</option><option value='Korea (Republic of)@@miramer@miwonsc.com'>Korea (Republic of)</option><option value='Kuwait@@miramer@miwonsc.com'>Kuwait</option><option value='Kyrgyzstan@@miramer@miwonsc.com'>Kyrgyzstan</option><option value='Lao People`s Democratic Republic@@miramer@miwonsc.com'>Lao People`s Democratic Republic</option><option value='Latvia@@miramer@miwonsc.com'>Latvia</option><option value='Lebanon@@miramer@miwonsc.com'>Lebanon</option><option value='Lesotho@@miramer@miwonsc.com'>Lesotho</option><option value='Liberia@@miramer@miwonsc.com'>Liberia</option><option value='Libyan Arab Jamahiriya@@miramer@miwonsc.com'>Libyan Arab Jamahiriya</option><option value='Lithuania@@miramer@miwonsc.com'>Lithuania</option><option value='Luxembourg@@miramer@miwonsc.com'>Luxembourg</option><option value='Madagascar@@miramer@miwonsc.com'>Madagascar</option><option value='Malawi@@miramer@miwonsc.com'>Malawi</option><option value='Malaysia@@miramer@miwonsc.com'>Malaysia</option><option value='Maldives@@miramer@miwonsc.com'>Maldives</option><option value='Mali@@miramer@miwonsc.com'>Mali</option><option value='Malta@@miramer@miwonsc.com'>Malta</option><option value='Martinique@@miramer@miwonsc.com'>Martinique</option><option value='Mauritania@@miramer@miwonsc.com'>Mauritania</option><option value='Mauritius@@miramer@miwonsc.com'>Mauritius</option><option value='Mayotte@@miramer@miwonsc.com'>Mayotte</option><option value='Mexico@@miramer@miwonsc.com'>Mexico</option><option value='Micronesia (Federated States of)@@miramer@miwonsc.com'>Micronesia (Federated States of)</option><option value='Mongolia@@miramer@miwonsc.com'>Mongolia</option><option value='Montenegro@@miramer@miwonsc.com'>Montenegro</option><option value='Morocco@@miramer@miwonsc.com'>Morocco</option><option value='Mozambique@@miramer@miwonsc.com'>Mozambique</option><option value='Myanmar@@miramer@miwonsc.com'>Myanmar</option><option value='Namibia@@miramer@miwonsc.com'>Namibia</option><option value='Nepal@@miramer@miwonsc.com'>Nepal</option><option value='Netherlands@@miramer@miwonsc.com'>Netherlands</option><option value='Netherlands Antilles@@miramer@miwonsc.com'>Netherlands Antilles</option><option value='New Caledonia@@miramer@miwonsc.com'>New Caledonia</option><option value='New Zealand@@miramer@miwonsc.com'>New Zealand</option><option value='Nicaragua@@miramer@miwonsc.com'>Nicaragua</option><option value='Niger@@miramer@miwonsc.com'>Niger</option><option value='Nigeria@@miramer@miwonsc.com'>Nigeria</option><option value='North Macedonia (Republic of)@@miramer@miwonsc.com'>North Macedonia (Republic of)</option><option value='Norway@@miramer@miwonsc.com'>Norway</option><option value='Occupied Palestinian Territory@@miramer@miwonsc.com'>Occupied Palestinian Territory</option><option value='Oman@@miramer@miwonsc.com'>Oman</option><option value='Pakistan@@miramer@miwonsc.com'>Pakistan</option><option value='Panama@@miramer@miwonsc.com'>Panama</option><option value='Papua New Guinea@@miramer@miwonsc.com'>Papua New Guinea</option><option value='Paraguay@@miramer@miwonsc.com'>Paraguay</option><option value='Peru@@miramer@miwonsc.com'>Peru</option><option value='Philippines@@miramer@miwonsc.com'>Philippines</option><option value='Poland@@miramer@miwonsc.com'>Poland</option><option value='Portugal@@miramer@miwonsc.com'>Portugal</option><option value='Puerto Rico@@miramer@miwonsc.com'>Puerto Rico</option><option value='Qatar@@miramer@miwonsc.com'>Qatar</option><option value='Republic of Moldova@@miramer@miwonsc.com'>Republic of Moldova</option><option value='Réunion@@miramer@miwonsc.com'>Réunion</option><option value='Romania@@miramer@miwonsc.com'>Romania</option><option value='Russian Federation@@miramer@miwonsc.com'>Russian Federation</option><option value='Rwanda@@miramer@miwonsc.com'>Rwanda</option><option value='Saint Lucia@@miramer@miwonsc.com'>Saint Lucia</option><option value='Saint Vincent and the Grenadines@@miramer@miwonsc.com'>Saint Vincent and the Grenadines</option><option value='Samoa@@miramer@miwonsc.com'>Samoa</option><option value='Sao Tome and Principe@@miramer@miwonsc.com'>Sao Tome and Principe</option><option value='Saudi Arabia@@miramer@miwonsc.com'>Saudi Arabia</option><option value='Senegal@@miramer@miwonsc.com'>Senegal</option><option value='Serbia@@miramer@miwonsc.com'>Serbia</option><option value='Sierra Leone@@miramer@miwonsc.com'>Sierra Leone</option><option value='Singapore@@miramer@miwonsc.com'>Singapore</option><option value='Slovakia@@miramer@miwonsc.com'>Slovakia</option><option value='Slovenia@@miramer@miwonsc.com'>Slovenia</option><option value='Solomon Islands@@miramer@miwonsc.com'>Solomon Islands</option><option value='Somalia@@miramer@miwonsc.com'>Somalia</option><option value='South Africa@@miramer@miwonsc.com'>South Africa</option><option value='Spain@@miramer@miwonsc.com'>Spain</option><option value='Sri Lanka@@miramer@miwonsc.com'>Sri Lanka</option><option value='Sudan@@miramer@miwonsc.com'>Sudan</option><option value='Suriname@@miramer@miwonsc.com'>Suriname</option><option value='Swaziland@@miramer@miwonsc.com'>Swaziland</option><option value='Sweden@@miramer@miwonsc.com'>Sweden</option><option value='Switzerland@@miramer@miwonsc.com'>Switzerland</option><option value='Syrian Arab Republic@@miramer@miwonsc.com'>Syrian Arab Republic</option><option value='Tajikistan@@miramer@miwonsc.com'>Tajikistan</option><option value='Thailand@@miramer@miwonsc.com'>Thailand</option><option value='Timor-Leste@@miramer@miwonsc.com'>Timor-Leste</option><option value='Togo@@miramer@miwonsc.com'>Togo</option><option value='Tonga@@miramer@miwonsc.com'>Tonga</option><option value='Trinidad and Tobago@@miramer@miwonsc.com'>Trinidad and Tobago</option><option value='Tunisia@@miramer@miwonsc.com'>Tunisia</option><option value='Türkiye@@miramer@miwonsc.com'>Türkiye</option><option value='Turkmenistan@@miramer@miwonsc.com'>Turkmenistan</option><option value='Uganda@@miramer@miwonsc.com'>Uganda</option><option value='Ukraine@@miramer@miwonsc.com'>Ukraine</option><option value='United Arab Emirates@@miramer@miwonsc.com'>United Arab Emirates</option><option value='United Kingdom@@miramer@miwonsc.com'>United Kingdom</option><option value='United Republic of Tanzania@@miramer@miwonsc.com'>United Republic of Tanzania</option><option value='United States of America@@miramer@miwonsc.com'>United States of America</option><option value='United States Virgin Islands@@miramer@miwonsc.com'>United States Virgin Islands</option><option value='Uruguay@@miramer@miwonsc.com'>Uruguay</option><option value='Uzbekistan@@miramer@miwonsc.com'>Uzbekistan</option><option value='Vanuatu@@miramer@miwonsc.com'>Vanuatu</option><option value='Venezuela (Bolivarian Republic of)@@miramer@miwonsc.com'>Venezuela (Bolivarian Republic of)</option><option value='Vietnam@@miramer@miwonsc.com'>Vietnam</option><option value='Western Sahara@@miramer@miwonsc.com'>Western Sahara</option><option value='Yemen@@miramer@miwonsc.com'>Yemen</option><option value='Zambia@@miramer@miwonsc.com'>Zambia</option><option value='Zimbabwe@@miramer@miwonsc.com'>Zimbabwe</option>                                </select>
								<div class="select__arrow"></div>
                            </div>
                        </div>
                        <div class="small_td">
                            <div class="select-step select-style big-select">
                                <select name="category" id="Application" class="bg-transparent mb-0">
                                    <option value="">Select a category</option>
									<option value="Academia">Academia</option>
									<option value="Current Customer">Current Customer</option>
									<option value="Potential Customer">Potential Customer</option>
									<!--<option value="Industrial_coating">Industrial_coating</option>-->
									<option value="Other">Other</option>
                                </select>
								<div class="select__arrow"></div>
                            </div>
                        </div>
                        <div class="small_td">
                            <div class="select-step select-style big-select">
                                <select name="inquiry" id="Region" class="bg-transparent mb-0">
                                    <option value="">Select a Type of inquiry</option>
									<option value="Sales">Sales</option>
									<option value="Technical Support">Technical Support</option>
									<option value="Compliance">Compliance</option>
									<option value="SDS">SDS</option> 
									<option value="Technical Literature">Technical Literature</option> 
									<option value="Other">Other</option>
                                </select>
								<div class="select__arrow"></div>
                            </div>
                        </div>
                        <div class="big_td">
                            <div class="select-style big-select">
							   <input type="text" name="name1" required  placeholder="First name" class="big-input required">
                            </div>
                        </div>
                       <div class="big_td">
                            <div class="select-style big-select">
                                <input type="text" name="name2" required  placeholder="Last name" class="big-input required">
                            </div>
						</div>
                        <div class="big_td">
                            <div class="select-style big-select">
							   <input type="text" name="email" required  placeholder="E-mail" class="big-input required">
                            </div>
                        </div>
                       <div class="big_td">
                            <div class="select-style big-select">
                                <input type="text" name="phone"   placeholder="Phone" class="big-input">
                            </div>
						</div>
                        <div class="big_td">
                            <div class="select-style big-select">
							   <input type="text" name="company" required  placeholder="Company" class="big-input required">
                            </div>
                        </div>
                       <div class="big_td">
                            <div class="select-style big-select">
                                <input type="text" name="ma" required  placeholder="Market & application" class="big-input required">
                            </div>
						</div>

                        <div class="big_td_full">
						    <label class="fx_Value"><img src='/img/require.png'> Mandatory Fields.</label><br>
                            <style>
#contect_area_go {  margin-top:50px;font-size:0.9em;font-weight:600;padding-bottom:20px;margin-bottom:10px;border-bottom:1px dotted silver  }
#contect_area_go_but {  float:right;font-size:0.5em;cursor:pointer;  }
#contect_area_go_but span{  font-size:1.2em  }
#contect_area {width:100%; max-width:1200px;  margin:0px auto;font-size:0.8em; padding:20px; background:#fff }
#contect_area .btits { font-size:0.8em;padding-left:10px;  }
#contect_area .btit {  margin-top:10px;font-size:0.9em;font-weight:600;padding-bottom:20px;margin-bottom:10px;border-bottom:1px dotted silver  }
#contect_area .btit_top { margin-top:40px;font-size:0.9em;font-weight:600;padding-bottom:20px;margin-bottom:10px;border-bottom:1px dotted silver  }
#contect_area .bcon { font-size:0.8em;  }
#contect_area .bcons { font-size:0.8em;padding-left:35px;  }

</style>

<div id="contect_area_go">
Consent to collection, use and provision of personal information
<a id="contect_area_go_but"><span id='contect_area_go_plus'>+</span><span id='contect_area_go_minus' style="display:none">-</span> All</a>
</div>
<div id="contect_area" class="sub01_01" style="display:none">

<p class='btit'>Purpose for the Collection and Use of Personal Information</p>

<p class='bcon p10'>The company processes personal information for the following purposes. The personal information being processed will not be used for any purpose other than the following, and in any case where the purpose of use changes, we will take due measures, such as obtaining additional consent according to Article 18 of the Personal Information Protection Act.</p>

<p class='btits'>I.	Service Provision and Respond to Inquiry</p>
<p class='bcons'>Provision of product information, marketing, development of new products and provision of customized services, delivery of requested samples, response to product complaints, record preservation for dispute resolution, sales response, answers to inquiries from customers and civil servants, request for personal information access, correction, and suspension of processing</p>


<p class='btit_top'>Processing and Use of Personal Information and Retention Period</p>
<p class='bcon p10'>
The company processes and retains personal information within the period of retention and use of personal information in accordance with laws and regulations or within the period of retention and use of personal information agreed upon when collecting personal information from the information subject.</p>
<p class='btits'>I.	Service Provision and Respond to Inquiry: 3 Months</p>

<p class='btit_top'>Items of Personal Information Processed</p>

<p class='bcon p10'>The company collects the following personal information from the information subjects.</p>

<p class='btits'>I.	 Service Provision and Respond to Inquiry</p>
<p class='bcons'>A.	Mandatory Items: person’s name, e-mail address, company name, location</p>
<p class='bcons'>B.	Optional Items: Contact Information (Phone number)</p>

</div>

<script>
$("#contect_area_go_but").click(function() {
  
  if($('#contect_area').css('display')=="none") {
  $('#contect_area_go_plus').hide();
  $('#contect_area_go_minus').show(); 
  $('#contect_area').show(); 
  } else {
  $('#contect_area_go_minus').hide();
  $('#contect_area_go_plus').show(); 
  $('#contect_area').hide(); 
  }
});
</script>
                            <input type="checkbox" name="agree"  id="contact_agree"> 
							<label class="fx_Value">
								(Required) I agree to the collection and use of personal information in order to process and follow my inquiry.

							</label>

                        </div>
                        <div class="big_td_full">
                            <button id="project-contact-us-button" onclick='FormCheck()' class="btn btn-transparent-dark-gray btn-large margin-20px-top col_text">Send</button>
                            <button id="project-re-button" class="btn btn-transparent-dark-gray btn-large margin-20px-top col_text_no">Cancel</button>
                        </div>
                    </div></form>
	</div>
</div>
<style>
.f_box { width:100%;max-width:1200px;margin:0 auto; }
.f_box .f_half1 { width:60%;float:left; }
.f_box .f_half2 { width:40%;float:left; }
.f_box .f_half { width:50%;float:left; }
.f_box .f_half3 { width:32%;float:left; }
.f_box .f_half4 { width:68%;float:left; }
.f_box .f_gan { color:#e5e5e5;margin-right:15px; }
.f_box .full_body { width:100%;height:50px }
.qmenu { margin-left:100px;font-size:0.9rem}
.qmenu li{ line-height:160% }
.f_box .qmenu_title{ font-weight:600;font-size:1.2rem;margin-bottom:15px; }
.pl10 { padding-left:10px}
.pt10 { padding-top:10px}
.mt10 { margin-top:10px}
.mt20 { margin-top:20px}
.mt30 { margin-top:30px}
.f-height { margin-left:10px;margin-bottom:15px;display:table;width:100%; }
.f-height a { color:#e5e5e5 }
.f_bold { color:#fff;font-weight:600 }
</style> 
<script src="https://miwonsc.com/theme/basic/js/css3-animate-it.js"></script>
<!-- 하단 시작 { -->
<footer id="footer">
	<div class="wrap footer_box">
	  <div class="f_box">
	    <div class="f_half1">
		 <div class='full_body'><h1><a href="/"><img src='/img/mi_1.png?'></a></h1></div>
		 <div class='full_body pl10'>We are committed to making tomorrow better by<br>fostering innovative and sustainable solutions.</div>
		 <div class='full_body pl10 mt30'>
		 <span class='f_gan'>www.miwonsc.com</span> <span class='f_gan'>|</span> <span class='f_gan'>TEL: +82-31-479-9140</span><br>
		  20 Poeun-daero 59 beon-gil, Suji-gu, Yongin-si, Gyeonggi-do, 16864, Korea  </div>
		 </div>
	    <div class="f_half2">
		  <div class="f_half3">
             <ul>
				<li class='qmenu_title' style='text-align:left'>Stay Connected</li>
				<li style='padding-left:20px;'><A href='https://www.linkedin.com/company/83511337/admin/' target=_blank><img src='/img/linkdin.png' height=20px></a></li>
			</ul>

		  </div>
		  <div class="f_half4">
			<ul class="qmenu">
				<li class='qmenu_title' style='text-align:left'>Quick Navigation</li>
				<li>
					<div class='f-height'>
					  <A href='/eng/Company/company.html'><span class='f_half'>ABOUT US</span></a>
					  <A href='/eng/Sustainability/Sustainability.html'><span class='f_half'>Sustainability</span></a>
					</div>
					<div class='f-height'>
					  <A href='/eng/Products/search.php'><span class='f_half'>Products</span></a>
					  <A href='/bbs/board.php?bo_table=eng_news'><span class='f_half'>Info Center</span></a>
					</div>
					<div class='f-height'>
					  <A href='/eng/Market/electronics.html'><span>Market & Application</span></a>
					  <!--A href='/eng/Careers/Human.html'><span class='f_half'>인재채용</span></a-->
					</div>
				</li>
			</ul>
		  </div>
	    </div>
	  </div>
	</div>
	<div class="f_copyright">
	  <div class="f_box">
	    <div class="f_half t_left pl10"><a href='/eng/service/Privacy_Statement.html' class='f_gan f_bold'>Privacy Statement</a>  <a href='/eng/service/contact.html' class='f_gan'>CONTACT</a> </div>
        <div class="f_half t_right">© 2022 <strong>Miwon Specialty Chemical Co., Ltd.</strong> All rights reserved.</div>
	  </div>
	</div>
	<a href="javascript:" id="top_btn"><i class="fa fa-angle-up" aria-hidden="true"></i><span class="sound_only">상단으로</span> </a>
    
</footer>
<!-- } 하단 끝 -->



<!-- ie6,7에서 사이드뷰가 게시판 목록에서 아래 사이드뷰에 가려지는 현상 수정 -->
<!--[if lte IE 7]>
<script>
$(function() {
    var $sv_use = $(".sv_use");
    var count = $sv_use.length;

    $sv_use.each(function() {
        $(this).css("z-index", count);
        $(this).css("position", "relative");
        count = count - 1;
    });
});
</script>
<![endif]-->
		 <script src="/js/wow.js"></script>
		 <script>
                $(".dropdown_share").click(function(){
					var url = '/eng/index.php';
					var textarea = document.createElement("textarea");
					document.body.appendChild(textarea);
					url = window.document.location.href;
					textarea.value = url;
					textarea.select();
					document.execCommand("copy");
					document.body.removeChild(textarea);
					alert("URL이 복사되었습니다.")
				});
				$("#comment_wrkey").click(function(){
					if ($('#kw_use').css('display') === 'none') {
						$("#kw_use").show(500);
					}
				});
				$("#project-re-button").click(function(){
						$("#kw_use").hide(500);
				});
				$(".main_card li").hover(function(){
				   for(i=1; i<7; i++) {
                    if(this.id=="news"+i) {
					  $(".news"+i).show();
					  //$('#news'+i).addClass('active');
					} else {
					  $(".news"+i).hide();
					  //$('#news'+i).removeClass('active');
					  //$('#news'+i+ ' > a').removeClass('aline');
					}
				   }
				});

				wow = new WOW(
				  {
					animateClass: 'animated',
					offset:       100,
					callback:     function(box) {
					  console.log("WOW: animating <" + box.tagName.toLowerCase() + ">")
					}
				  }
				);
				wow.init();
				document.getElementById('moar').onclick = function() {
				  var section = document.createElement('section');
				  section.className = 'section--purple wow fadeInDown';
				  this.parentNode.insertBefore(section, this);
				};
			// submit 최종 폼체크
				function contactr_submit(f)
				{
                  				  if (f.agree.checked==false) {
						alert("You must agree to the Privacy Policy.");
						//f.re1.focus();
						return false;
				  }     
				  var error = "NO";
				  var message = "";
				  var link = "";
				  var params = $("form[name=q_post_content]").serialize();
					 
			  
					$.ajax({
						url: "/register_sign.php",
						method: "post",
						dataType: "json",
						async: false,
						data: params,
						success: function (data) {
						if (data.code == 1)
						{
							error = 'YES';
							message =data.message
							link =data.link;
						} else {
							error = 'NO';
							message =data.message
							link =data.link;
					   }
						}
					});
				  
					alert(message);
                    //return false;
			 

				}
		</script>
		<script>
 		$(function() {
			$("#top_btn").on("click", function() {
				$("html, body").animate({scrollTop:0}, '500');
				return false;
			});
			$("#first_nav").on("click", function() {
				$("html, body").animate({scrollTop:0}, '500');
				return false;
			});
		});
		</script>
<style>
.btn_cookie_area {
  position: fixed; /* 이 부분을 고정 */
  bottom: 0; /* 하단에 여백 없이 */
  width: 100%; /* 가로 사이즈를 브라우저에 가득 채움 */
  height: 150px;
  background:#f7f7f7;
  z-index:9999999999;
}
.btn_cookie_area .container{
  max-width:1200px;
  width:100%;
  margin:0 auto;
}
.btn_cookie_area .container > p{
  width:70%;
  float:left;
  padding-top:30px;
  font-size:1.1em 
}

.btn_cookie_area .container > p.hum  {
  width:30%;
  text-align:right;
  padding-top:50px;
}

.btn_cookie_area .container > p.hum > .Allsign {
    font-size: 0.8em;
    margin-left: 20px;
    padding: 10px;
    background: #28AFB0;
    color: #fff;
    cursor: pointer;
    border-radius: 9px;
    margin-top:30px
}
.btn_cookie_area .container > p.hum > .Close {
    width: 150px;
    font-size: 0.8em;
    margin-left: 20px;
    padding: 10px;
    background: #43536a;
    color: #fff;
    cursor: pointer;
    border-radius: 9px;
    margin-top:30px
}
@media (max-width:960px) {
.btn_cookie_area {
  position: fixed; /* 이 부분을 고정 */
  bottom: 0; /* 하단에 여백 없이 */
  width: 100%; /* 가로 사이즈를 브라우저에 가득 채움 */
  height: auto;
  background:#f7f7f7;
  z-index:9999999999;
}
.btn_cookie_area .container > p {
    width: 100%;
    float:normal;
    padding:20px;
}
.btn_cookie_area .container > p.hum  {
  width:100%;
  padding-top:10px;
}

}
</style>

<div class="btn_cookie_area" style="display:none">
    <div class="container gnormal">
	<p>We value your privacy<br>
This website uses cookies to ensure you get the best experience on our website.<br>By continuing to browse, you agree to the use of cookies to enhance your site experience. </p>

	<p class="hum"><a href="#" class="Allsign" onclick="javascript:aCookie();">Accept all cookies</a>
	<!--a href="#" class="Close" onclick="javascript:aClose();">&times;</a--></p>
    </div>
</div>    
<script>
  $(document).ready(function() {
	  var aCookie = getCookie("agreecookie");
      //alert(aCookie);
	  if(!aCookie) {
		  $('div.btn_cookie_area').show();  
	  }
	  $(".gnb_al_a_mobile").on("click", function() {
		if ( $(this).hasClass('active') ) {
            //alert(1);
			$(this).find(' > .hipup').hide();
			$(this).find(' > .hipdown').show();
			$(this).find(' > .ulo_hide').hide();
			$(this).removeClass('active');
		}
		else {
            //alert(2);
			$('.hipdown').show();
			$('.hipup').hide();
			$('.ulo_hide').hide();
			$('.gnb_al_a_mobile').removeClass('active');
			$(this).find(' > .ulo_hide').show();
			$(this).find(' > .hipdown').hide();
			$(this).find(' > .hipup').show();
			$(this).addClass('active');
		}		  
	  });
  });
  
  function aCookie() {
	  $('div.btn_cookie_area').hide();
	  setCookie("agreecookie", 'agreecookie', 365);
  }
  
  function aClose() {
	  $('div.btn_cookie_area').hide();  
  }


  function setCookie(cookie_name, value, days) {
	  var exdate = new Date();
	  exdate.setDate(exdate.getDate() + days);
	  // 설정 일수만큼 현재시간에 만료값으로 지정

	  var cookie_value = escape(value) + ((days == null) ? '' : '; path=/; expires=' + exdate.toUTCString());
	  document.cookie = cookie_name + '=' + cookie_value;
  }

  function getCookie(cookie_name) {
		var x, y;
		var val = document.cookie.split(';');
		for (var i = 0; i < val.length; i++) {
			x = val[i].substr(0, val[i].indexOf('='));
			y = val[i].substr(val[i].indexOf('=') + 1);
			x = x.replace(/^\s+|\s+$/g, '');
			// 앞과 뒤의 공백 제거하기
			if (x == cookie_name) {
				return unescape(y);
				// unescape로 디코딩 후 값 리턴
			}
		}
  }
</script>
<script>
function mcheck(a,b) {
   var dataString = 'lng=eng&get_cook=set_80981349.37.115.251&row='+ a;


   if($('#'+b).prop("checked")==false) {
   dataString = dataString + '&type=del';
   } else {
   dataString = dataString + '&type=add';
   }

   $.ajax({
    type: "POST",
    url: "/input.php",
    data: dataString,
    cache: false,
    success: function(html) {
        alert(html);
    }
   	});
}
function ccheck(a,b) {
   var dataString = 'lng=eng&get_cook=set_80981349.37.115.251&type=del&row='+ a;

   $.ajax({
    type: "POST",
    url: "/input.php",
    data: dataString,
    cache: false,
    success: function(html) {
        alert(html);
    }
   	});
    location.href='/eng/index.php';
}
</script>

</script>
</body>
</html>
